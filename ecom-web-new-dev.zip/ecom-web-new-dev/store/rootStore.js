/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 27/6/2022
 */

import { configureStore } from "@reduxjs/toolkit";
import { createWrapper } from "next-redux-wrapper";
import { apiSlice } from "./slices/apiSlice";
import categoryReducer from "./slices/categorySlice";
import itemReducer from "./slices/itemSlice";
import userReducer from "./slices/userSlice";
import orgReducer from './slices/orgSlice';
import profileReducer from './slices/profileSlice';
import sellerReducer from './slices/sellerSlice';
import brandReducer from './slices/brandSlice';
import policyReducer from './slices/policySlice';

// const reducer = (state, action) => {
//     if (action.type === HYDRATE) {
//         const nextState = {
//             ...state, // use previous state
//             ...action.payload, // apply delta from hydration
//         };
//         return nextState;
//     }
// };

export const rootStore = () => configureStore({
    reducer: {
        [apiSlice.reducerPath]: apiSlice.reducer,
        category: categoryReducer,
        item: itemReducer,
        user: userReducer,
        org: orgReducer,
        profile: profileReducer,
        seller: sellerReducer,
        brand: brandReducer,
        policy: policyReducer,
    },
    middleware: getDefaultMiddleware => getDefaultMiddleware().concat(apiSlice.middleware),
});

export const wrapper = createWrapper(rootStore, { debug: true });