import { createSlice } from '@reduxjs/toolkit';

export const itemSlice = createSlice({
  name: "item",
  initialState: {
    modalStatus: false,
    selectedItem: null
  },
  reducers: {
    openAddItemModal: (state) => {
      state.modalStatus = "add";
    },
    openViewItemModal: (state, action) => {
      state.modalStatus = "view";
      state.selectedItem = action.payload;      
    },
    openEditItemModal: (state, action) => {
      state.modalStatus = "edit";
      state.selectedItem = action.payload;
    },
    openDeleteItemModal: (state, action) => {
      state.modalStatus = "delete";
      state.selectedItem = action.payload;
    },
    closeItemModal: (state) => {
      state.modalStatus = false;
      state.selectedItem = null;
    }
  }
});

export const { 
  openAddItemModal, 
  openViewItemModal,
  openEditItemModal, 
  openDeleteItemModal, 
  closeItemModal 
} = itemSlice.actions;

export const selectItem = state => state.item;

export default itemSlice.reducer;