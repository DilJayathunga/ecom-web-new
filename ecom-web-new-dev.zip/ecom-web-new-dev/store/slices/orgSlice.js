import { createSlice } from '@reduxjs/toolkit';

export const orgSlice = createSlice({
  name: "org",
  initialState: {
    modalStatus: false,
    selectedOrganization: null
  },
  reducers: {
    openAddOrgModal: (state) => {
      state.modalStatus = "add";
    },
    openEditOrgModal: (state, action) => {
      state.modalStatus = "edit";
      state.selectedOrganization = action.payload;
    },
    openDeleteOrgModal: (state, action) => {
      state.modalStatus = "delete";
      state.selectedOrganization = action.payload;
    },
    closeOrgModal: (state) => {
      state.modalStatus = false;
      state.selectedOrganization = null;
    }
  }
});

export const { openAddOrgModal, openEditOrgModal, openDeleteOrgModal, closeOrgModal } = orgSlice.actions;

export const selectOrg = state => state.org;

export default orgSlice.reducer;