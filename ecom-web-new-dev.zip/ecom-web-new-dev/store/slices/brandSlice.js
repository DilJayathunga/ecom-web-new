/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 26/8/2022
 */


import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  brandPageOpen: false,
  status: null,
  selectedBrand: null,
};

export const BrandSlice = createSlice({
  name: "brand",
  initialState,
  reducers: {
    openBrandForm: (state, action) => {
      state.brandPageOpen = action.payload;
    },

    setStatus: (state, action) => {
        state.status = action.payload;
    },

    setSelectedBrand: (state, action) => {
        state.selectedBrand = action.payload;
    },
  },
});

export const { 
  openBrandForm, 
  setStatus, 
  setSelectedBrand 
} = BrandSlice.actions;

export default BrandSlice.reducer;