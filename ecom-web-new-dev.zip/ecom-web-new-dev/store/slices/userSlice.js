import { createSlice } from '@reduxjs/toolkit';
import { authService } from '../services/authService'

export const userSlice = createSlice({
  name: "user",
  initialState: {
    isSignedIn: false,
    isLoginDialogOpen: false,
    isRegisterDialogOpen: false,
    UserPageOpen: false,
    deletePageOpen: false,
    status: null,
    selectedUser: null,
  },
  reducers: {
    login: (state, action) => {
      const { access_token, details } = action.payload;
      sessionStorage.setItem("access_token", access_token);
      Object.assign(state, { isSignedIn: true, isLoginDialogOpen: false, details });
    },
    logout: (state) => {
      sessionStorage.removeItem("access_token");
      state.isSignedIn = false;
      delete state.details;
    },
    toggleLoginDialog: (state) => {
      state.isLoginDialogOpen = !state.isLoginDialogOpen;
    },
    toggleRegisterDialog: (state) => {
      state.isRegisterDialogOpen = !state.isRegisterDialogOpen;
    },
    openUserForm: (state, action) => {
      state.UserPageOpen = action.payload;
    },

    openDeletePage: (state, action) => {
      state.deletePageOpen = action.payload;
    },

    setStatus: (state, action) => {
      state.status = action.payload;
    },

    setSelectedUser: (state, action) => {
      state.selectedUser = action.payload;
    },
  },
  // extraReducers: (builder) => {
  //   builder.addMatcher(
  //     authService.endpoints.fetchUserDetails.matchFulfilled,
  //     (state, { payload }) => {
  //       state.user = { isSignedIn: true, details: payload }
  //     }
  //   )
  // }
});

export const {
  login,
  logout,
  toggleLoginDialog,
  toggleRegisterDialog,
  openUserForm,
  openDeletePage,
  setSelectedUser,
  setStatus,
} = userSlice.actions;

export const selectUser = state => state.user;

export default userSlice.reducer;