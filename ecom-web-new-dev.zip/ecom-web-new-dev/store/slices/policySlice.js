/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 26/8/2022
 */


import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  policyPageOpen: false,
  status: null,
  selectedPolicy: null,
};

export const PolicySlice = createSlice({
  name: "policy",
  initialState,
  reducers: {
    openPolicyForm: (state, action) => {
      state.policyPageOpen = action.payload;
    },

    setStatus: (state, action) => {
        state.status = action.payload;
    },

    setSelectedPolicy: (state, action) => {
        state.selectedPolicy = action.payload;
    },
  },
});

export const { 
  openPolicyForm, 
  setStatus, 
  setSelectedPolicy 
} = PolicySlice.actions;

export default PolicySlice.reducer;