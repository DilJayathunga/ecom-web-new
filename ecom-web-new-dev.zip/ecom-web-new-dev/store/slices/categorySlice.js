/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 4/7/2022
 */

import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  CategoryPageOpen: false,
  deletePageOpen: false,
  status: null,
  selectedCategory: null,
};

export const CategorySlice = createSlice({
  name: "category",
  initialState,
  reducers: {
    openCategoryForm: (state, action) => {
      state.CategoryPageOpen = action.payload;
    },

    openDeletePage: (state, action) => {
      state.deletePageOpen = action.payload;
    },

    setStatus: (state, action) => {
        state.status = action.payload;
    },

    setSelectedCategory: (state, action) => {
        state.selectedCategory = action.payload;
    },
  },
});

export const { 
  openCategoryForm, 
  openDeletePage,
  setStatus, 
  setSelectedCategory 
} = CategorySlice.actions;

export default CategorySlice.reducer;