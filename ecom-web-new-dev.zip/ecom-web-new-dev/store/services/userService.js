
import { apiSlice } from "../slices/apiSlice";

export const userService = apiSlice.injectEndpoints({
  endpoints: builder => ({
    getAllUser: builder.query({
      query: () => "/user-management/manage-user",
      providesTags: ['user']
    }),

    getUserById: builder.query({
      query: (userId) => `/user-management/manage-user/${userId}`
    }),

    createUser: builder.mutation({
      query: (UserDetails) => ({
        url: '/user-management/manage-user',
        method: 'POST',
        body: UserDetails
      }),
      invalidatesTags: ['user']
    }),

    updateUser: builder.mutation({
      query: (userDetails) => ({
        url: '/user-management/manage-user',  
        method: 'PUT',
        body: userDetails
      }),
      invalidatesTags: ['user']
    }),

    deleteUser: builder.mutation({
      query: (userId) => ({
          url: `/user-management/manage-user/${userId}`,
          method: 'POST',
      }),
      invalidatesTags: ['user']
    }),
  })
});

export const {
   useCreateUserMutation,
   useGetAllUserQuery,
   useGetUserByIdQuery,
   useUpdateUserMutation,
   useDeleteUserMutation
} = userService;