/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 28/7/2022
 */

import { apiSlice } from "../slices/apiSlice";

export const filterService = apiSlice.injectEndpoints({
  endpoints: builder => ({
    getFiltersByCategory: builder.query({
      query: (catId) => `/filter-management/filter-category/${catId}`
    }),
        
    getWebFilters: builder.query({
      query: () => `/webFilters-management/managed-webFilters`
    }),
  })
});

export const { 
    useLazyGetFiltersByCategoryQuery,
    useGetWebFiltersQuery,
 } = filterService;