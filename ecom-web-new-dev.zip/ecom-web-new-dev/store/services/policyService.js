/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 18/8/2022
 */

import { apiSlice } from "../slices/apiSlice";

export const policyService = apiSlice.injectEndpoints({
  endpoints: builder => ({
    getAllPoliciesWithType: builder.query({
      query: () => "/policy-management/managed-policy",
    }),

    getAllPolicies: builder.query({
      query: () => "/policy-management/getAll-policy",
      providesTags: ['policy']
    }),

    getAllPolicyTypes: builder.query({
      query: () => "/policy-management/managed-policy/policy-type",
    }),

    getPolicyById: builder.query({
      query: (policyId) => `/policy-management/managed-policy/${policyId}`,
      providesTags: ['policy']
    }),

    createPolicy: builder.mutation({
      query: (policyDetails) => ({
        url: '/policy-management/managed-policy',
        method: 'POST',
        body: policyDetails
      }),
      invalidatesTags: ['policy']
    }),

    updatePolicy: builder.mutation({
      query: (policyDetails) => ({
        url: '/policy-management/managed-policy',  
        method: 'PUT',
        body: policyDetails
      }),
      invalidatesTags: ['policy']
    }),

    deletePolicy: builder.mutation({
      query: (policyId) => ({
          url: `/policy-management/managed-policy/${policyId}`,
          method: 'POST',
      }),
      invalidatesTags: ['policy']
    }),
  })
});

// Export hooks for usage in functional components  
export const {
  useGetAllPoliciesWithTypeQuery,
  useGetAllPoliciesQuery,
  useGetAllPolicyTypesQuery,
  useGetPolicyByIdQuery,
  useCreatePolicyMutation,
  useUpdatePolicyMutation,
  useDeletePolicyMutation,
  util: { getRunningOperationPromises },
} = policyService;