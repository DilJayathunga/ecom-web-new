import { apiSlice } from "../slices/apiSlice";

export const itemService = apiSlice.injectEndpoints({
  endpoints: builder => ({
    getAllItems: builder.query({
      query: () => "/product-management/managed-product",
      providesTags: ["item"],
    }),

    getItemById: builder.query({
      query: (itemId) => `/product-management/managed-product/all-value/${itemId}`,
      providesTags: ["item"]
    }),

    createItem: builder.mutation({
      query: (itemDetails) => ({
        url: '/product-management/managed-product',
        method: 'POST',
        body: itemDetails
      }),
      invalidatesTags: ['item']
    }),

    updateItem: builder.mutation({
      query: (itemDetails) => ({
        url: '/product-management/managed-product',  
        method: 'PUT',
        body: itemDetails
      }),
      invalidatesTags: ['item']
    }),

    deleteItem: builder.mutation({
      query: (id) => ({
        url: `/product-management/managed-product/${id}`,
        method: "POST",
      }),
      invalidatesTags: ["item"]
    }),
  })
});

// Export hooks for usage in functional components  
export const {
  useGetAllItemsQuery,
  useGetItemByIdQuery,
  useCreateItemMutation,
  useUpdateItemMutation,
  useDeleteItemMutation,
  util: { getRunningOperationPromises },
} = itemService;

// export endpoints for use in SSR
export const {
  getAllItems,
  deleteItem,
} = itemService.endpoints;