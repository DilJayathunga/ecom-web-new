/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 27/6/2022
 */

import { apiSlice } from "../slices/apiSlice";

export const categoryService = apiSlice.injectEndpoints({
    endpoints: builder => ({
      getAllCategories: builder.query({
        query: () => "/category-management/managed-category",
      }),

      getAllCatWithSubCat: builder.query({
        query: () => "/filter-management/category-subcategory",
        providesTags: ['cat']
      }),

      getCategoryById: builder.query({
        query: (catId) => `/category-management/managed-category/${catId}`,
        providesTags: ['cat']
      }),

      getAllTopCategories: builder.query({
        query: () => `/category-management/managed-topcategory`
      }),

      createCategory: builder.mutation({
        query: (categoryDetails) => ({
          url: '/category-management/managed-productCategory',
          method: 'POST',
          body: categoryDetails
        }),
        invalidatesTags: ['cat']
      }),

      updateCategory: builder.mutation({
        query: (categoryDetails) => ({
          url: '/category-management/managed-category',  
          method: 'PUT',
          body: categoryDetails
        }),
        invalidatesTags: ['cat']
      }),

      deleteCategory: builder.mutation({
        query: (catId) => ({
            url: `/category-management/managed-category/${catId}`,
            method: 'POST',
        }),
        invalidatesTags: ['cat']
      }),

    })
});

// Export hooks for usage in functional components  
export const { 
    useGetAllCategoriesQuery,
    useGetAllCatWithSubCatQuery,
    useGetCategoryByIdQuery,
    useLazyGetCategoryByIdQuery,
    useGetAllTopCategoriesQuery,
    useCreateCategoryMutation,
    useUpdateCategoryMutation,
    useDeleteCategoryMutation,
    util: { getRunningOperationPromises },
} = categoryService;

// export endpoints for use in SSR
export const { 
    getAllCategories
} = categoryService.endpoints;
