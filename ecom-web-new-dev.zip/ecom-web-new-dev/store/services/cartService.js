/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 20/9/2022
 */

import { apiSlice } from "../slices/apiSlice";

export const cartService = apiSlice.injectEndpoints({
  endpoints: builder => ({
    getAllCartItems: builder.query({
      query: (cartId) => `/orderHead-management/managed-orderHead/${cartId}`,
      providesTags: ['cart']
    }),

    addToCart: builder.mutation({
      query: (cartItemDetails) => ({
        url: '/orderDet-management/managed-orderDet/guest',
        method: 'POST',
        body: cartItemDetails
      })
    }),

    updateCartQuantity: builder.mutation({
      query: (cartQty) => ({
        url: '/orderDet-management/managed-orderDet',  
        method: 'PUT',
        body: cartQty
      }),
      invalidatesTags: ['cart']
    }),

    deleteCartItem: builder.mutation({
      query: (OrderDetId) => ({
          url: `/orderDet-management/managed-orderDet/${OrderDetId}`,
          method: 'POST',
      }),
      invalidatesTags: ['cart']
    }),
  })
});

// Export hooks for usage in functional components  
export const {
  useGetAllCartItemsQuery,
  useAddToCartMutation,
  useUpdateCartQuantityMutation,
  useDeleteCartItemMutation,
  util: { getRunningOperationPromises },
} = cartService;

// export endpoints for use in SSR
export const { getAllCartItems } = cartService.endpoints;