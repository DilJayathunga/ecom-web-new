/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 4/7/2022
 */

import { apiSlice } from "../slices/apiSlice";

export const orgService = apiSlice.injectEndpoints({
  endpoints: builder => ({
    getOrganizations: builder.query({
      query: () => "/org-management/managed-org",
      providesTags: ['org']
    }),

    getOrganizationById: builder.query({
      query: (id) => `/org-management/managed-org/${id}`,
      providesTags: ['org']
    }),

    createOrganization: builder.mutation({
      query: (newOrg) => ({
        url: "/org-management/managed-org",
        method: "POST",
        body: newOrg,
      }),
      invalidatesTags: ['org']
    }),

    editOrganization: builder.mutation({
      query: (org) => ({
        url: "/org-management/managed-org",
        method: "PUT",
        body: org
      }),
    }),

    deleteOrganization: builder.mutation({
      query: (id) => ({
        url: `/org-management/managed-org/${id}?lastModifiedBy=1`,
        method: "POST",
      }),
      invalidatesTags: ['org']
    })
    
  })
});

export const {
  useGetOrganizationsQuery,
  useGetOrganizationByIdQuery,
  useCreateOrganizationMutation,
  useEditOrganizationMutation,
  useDeleteOrganizationMutation
} = orgService;