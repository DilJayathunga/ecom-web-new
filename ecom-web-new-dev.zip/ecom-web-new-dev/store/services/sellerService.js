import { apiSlice } from "../slices/apiSlice";

export const sellerService = apiSlice.injectEndpoints({
  endpoints: builder => ({
    getAllSellers: builder.query({
      query: () => "/seller-management/managed-seller",
      providesTags: ['seller']
    }),

    getSellerById: builder.query({
      query: (sellerId) => `/seller-management/managed-seller/${sellerId}`,
      providesTags: ['seller']
    }),

    createSeller: builder.mutation({
      query: (sellerDetails) => ({
        url: '/seller-management/managed-seller',
        method: 'POST',
        body: sellerDetails
      }),
      invalidatesTags: ['seller']
    }),

    updateSeller: builder.mutation({
      query: (sellerDetails) => ({
        url: '/seller-management/managed-seller',  
        method: 'PUT',
        body: sellerDetails
      }),
      invalidatesTags: ['seller']
    }),

    deleteSeller: builder.mutation({
      query: (sellerId) => ({
          url: `/seller-management/manage-seller/${sellerId}?lastModifiedBy=1`,
          method: 'POST',
      }),
      invalidatesTags: ['seller']
    }),
  })
});

// Export hooks for usage in functional components  
export const {
  useGetAllSellersQuery,
  useGetSellerByIdQuery,
  useCreateSellerMutation,
  useUpdateSellerMutation,
  useDeleteSellerMutation,
  util: { getRunningOperationPromises },
} = sellerService;

// export endpoints for use in SSR
export const { getAllSellers } = sellerService.endpoints;