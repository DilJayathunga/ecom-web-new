/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 29/8/2022
 */

import { apiSlice } from "../slices/apiSlice";

export const brandService = apiSlice.injectEndpoints({
  endpoints: builder => ({
    getAllBrands: builder.query({
      query: () => "/product-management/managed-brand",
      providesTags: ['brand']
    }),

    getBrandById: builder.query({
      query: (brandId) => `/brand-management/managed-brand/${brandId}`,
      providesTags: ['brand']
    }),

    createBrand: builder.mutation({
      query: (brandDetails) => ({
        url: '/brand-management/managed-brand',
        method: 'POST',
        body: brandDetails
      }),
      invalidatesTags: ['brand']
    }),

    updateBrand: builder.mutation({
      query: (brandDetails) => ({
        url: '/brand-management/managed-brand',  
        method: 'PUT',
        body: brandDetails
      }),
      invalidatesTags: ['brand']
    }),

    deleteBrand: builder.mutation({
      query: (brandId) => ({
          url: `/brand-management/manage-brand/${brandId}?lastModifiedBy=1`,
          method: 'POST',
      }),
      invalidatesTags: ['brand']
    }),
  })
});

// Export hooks for usage in functional components  
export const {
  useGetAllBrandsQuery,
  useGetBrandByIdQuery,
  useCreateBrandMutation,
  useUpdateBrandMutation,
  useDeleteBrandMutation,
  util: { getRunningOperationPromises },
} = brandService;

// export endpoints for use in SSR
export const { getAllBrands } = brandService.endpoints;