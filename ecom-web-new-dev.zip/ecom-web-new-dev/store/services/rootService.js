/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 27/6/2022
 */

import { fetchBaseQuery } from '@reduxjs/toolkit/query/react';

const baseQuery = fetchBaseQuery({
    // baseUrl: "http://localhost:9091",    
    baseUrl: "http://cs-1-sg.stag.n-ach.com:9091/",
  // prepareHeaders: (headers) => {
  //   const token = localStorage.getItem("access_token");
  //   if (token) {
  //     headers.set("Authorization", `Bearer ${token}`);
  //   }
  //   return headers;
  // }
});

// export const baseQueryWithReauth = async (args, api, extraOptions) => {

//   let result = await baseQuery(args, api, extraOptions);

//   if (result.error && result.error.status === 401) {
//     const refreshToken = localStorage.getItem("refresh_token");
//     if (refreshToken) {
//       // try to get a new token
//       const refreshResult = await baseQuery({ url: "/refresh", method: "POST", body: { refresh: refreshToken } }, api, extraOptions);
//       if (refreshResult.data) {
//         // store the new token
//         localStorage.setItem("access_token", refreshResult.data);
//         // retry the initial query
//         result = await baseQuery(args, api, extraOptions);
//       }
//     }
//   }

//   return result;
// }