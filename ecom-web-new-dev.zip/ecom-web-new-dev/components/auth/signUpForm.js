import { yupResolver } from "@hookform/resolvers/yup";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import {
  Button,
  Grid,
  IconButton,
  InputAdornment,
  TextField,
  Toolbar,
  Typography,
} from "@mui/material";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { object, ref, string } from "yup";
import { useRegisterMutation } from "../../store/services/authService";
import styles from "../../styles/util.module.css";
import GoogleIcon from "@mui/icons-material/Google";
import FacebookRoundedIcon from '@mui/icons-material/FacebookRounded';
import { toast } from "react-toastify";

const schema = object({
  firstName: string().trim().required("First Name is required!"),
  lastName: string().trim().required("Last Name is requied!"),
  userEmail: string()
    .trim()
    .email("Please provide a valid Email!")
    .required("Email is required!"),
  password: string()
    .min(8, "Password should be at least 8 characters long!")
    .required("Password is required!"),
  confirmPassword: string().oneOf(
    [ref("password"), null],
    "Passwords don't match!"
  ),
});

const SignUpForm = ({ onSuccess }) => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ resolver: yupResolver(schema) });
  const [showPassword, setShowPassword] = useState(false);
  const [triggerRegister, { isLoading }] = useRegisterMutation();

  const handleClickShowPassword = () => {
    setShowPassword((currentShowState) => !currentShowState);
  };

  const onSubmit = async (data) => {
    console.log(data, "sumbit data ---> ");

    // const obj =

    try {
      const result = await triggerRegister(data).unwrap();
      console.log(result);
      onSuccess();
      toast.success("You can sign in now with your provided credential");
    } catch (err) {
      console.log(err);
      toast.error("Something went wrong!");
    }
  };

  return (
    <form className={styles.formItem} onSubmit={handleSubmit(onSubmit)}>
      <Grid container spacing={2}>
        <Grid item md={6} xs={12}>
          <TextField
            {...register("firstName")}
            label="First Name"
            size="small"
            fullWidth
            error={!!errors.firstName}
            helperText={errors.firstName?.message}
          />
        </Grid>
        <Grid item md={6} xs={12}>
          <TextField
            {...register("lastName")}
            label="Last Name"
            size="small"
            fullWidth
            error={!!errors.lastName}
            helperText={errors.lastName?.message}
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            {...register("userEmail")}
            label="Email"
            size="small"
            fullWidth
            error={!!errors.userEmail}
            helperText={errors.userEmail?.message}
          />
        </Grid>
        <Grid item md={6} xs={12}>
          <TextField
            {...register("password")}
            label="Password"
            size="small"
            fullWidth
            type={showPassword ? "text" : "password"}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton onClick={handleClickShowPassword} edge="end">
                    {showPassword ? <VisibilityOff /> : <Visibility />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
            error={!!errors.password}
            helperText={errors.password?.message}
          />
        </Grid>
        <Grid item md={6} xs={12}>
          <TextField
            {...register("confirmPassword")}
            label="Confirm Password"
            size="small"
            fullWidth
            type={showPassword ? "text" : "password"}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton onClick={handleClickShowPassword} edge="end">
                    {showPassword ? <VisibilityOff /> : <Visibility />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
            error={!!errors.confirmPassword}
            helperText={errors.confirmPassword?.message}
          />
        </Grid>
        <Grid item xs={12}>
          {/* <Typography variant="body1">
            By Creating an account, you agree to our User Agreement and
            acknowledge reading our Privacy Policy.
          </Typography> */}
          <Button
            type="submit"
            variant="contained"
            fullWidth
            disabled={isLoading}
            style={{ margin: "5px 0" }}
          >
            Sign Up
          </Button>
        </Grid>
        <Grid >
    
         <div style={{textAlign:'center', display:'flex', justifyContent:"space-around",}}>
         <IconButton>
            <GoogleIcon />
          </IconButton>
          <IconButton>
            <FacebookRoundedIcon/>
          </IconButton>
          <IconButton>
            <GoogleIcon />
          </IconButton>
         </div>
        </Grid>

      </Grid>
    </form>
  );
};

export default SignUpForm;
