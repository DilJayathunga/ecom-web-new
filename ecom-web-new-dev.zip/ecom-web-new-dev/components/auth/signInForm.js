import { yupResolver } from '@hookform/resolvers/yup';
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { Button, IconButton, InputAdornment, TextField } from "@mui/material";
import { useState } from "react";
import { useForm } from 'react-hook-form';
import { useDispatch } from "react-redux";
import { object, string } from 'yup';
import { useLoginMutation } from "../../store/services/authService";
import { login } from '../../store/slices/userSlice';
import styles from '../../styles/util.module.css';
import { toast } from "react-toastify";

const schema = object({
    username: string().trim().required("Please fill out your username"),
    password: string().required("Please fill out your password")
}).required();

const SignInForm = ({ onSuccess }) => {
    const { register, handleSubmit, formState: { errors } } = useForm({ resolver: yupResolver(schema) });
    const [showPassword, setShowPassword] = useState(false);
    const [triggerLogin, { isLoading }] = useLoginMutation();
    const dispatch = useDispatch();

    const handleClickShowPassword = () => {
        setShowPassword(currentShowState => !currentShowState);
    }

    const onSubmit = async (data) => {
        console.log(data, "sumbit data--->");
        try {
            const { username, roles, access_token } = await triggerLogin(data).unwrap();
            console.log(username, roles);
            dispatch(login({ access_token, details: { username, roles } }));
            onSuccess();

            console.log("User loging--->", data);
            toast.success("User successfully login!");
        } catch (err) {
            console.log(err);
            console.error("Failed to save the user: ", err);
            toast.error("Erorr, something went wrong!");
        }

    }

    return (
        <form onSubmit={handleSubmit(onSubmit)}>
            <div className={styles.formItem}>
                <TextField {...register("username")} label="Username" size='small' fullWidth error={!!errors.username} helperText={errors.username?.message} />
            </div>
            <div className={styles.formItem}>
                <TextField
                    {...register("password")}
                    label="Password"
                    size='small'
                    fullWidth
                    type={showPassword ? "text" : "password"}
                    InputProps={{
                        endAdornment: (
                            <InputAdornment position="end">
                                <IconButton
                                    onClick={handleClickShowPassword}
                                    // onMouseDown={handleMouseDownPassword}
                                    edge="end"
                                >
                                    {showPassword ? <VisibilityOff /> : <Visibility />}
                                </IconButton>
                            </InputAdornment>
                        )
                    }}
                    error={!!errors.password}
                    helperText={errors.password?.message}
                />
            </div>
            <div className={styles.formItem}>
                <Button type="submit" variant='contained' fullWidth disabled={isLoading}>Sign In</Button>
            </div>
        </form>
    );
}

export default SignInForm;