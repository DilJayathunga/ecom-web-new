import { Button, Dialog, DialogContent, DialogTitle, Divider } from "@mui/material";
import SignInForm from "./signInForm";
import { useSelector, useDispatch } from 'react-redux';
import { selectUser, toggleLoginDialog, toggleRegisterDialog } from "../../store/slices/userSlice";
import styles from '../../styles/util.module.css';

const SignInDialog = () => {
  const { isLoginDialogOpen } = useSelector(selectUser);
  const dispatch = useDispatch();

  const handleClose = () => {
    dispatch(toggleLoginDialog());
  }

  const handleCreateAccountClick = () => {
    handleClose();
    dispatch(toggleRegisterDialog());
  }

  const handleSuccess = () => {
    console.log("Success");
  }

  return (
    <Dialog fullWidth maxWidth="xs" style={{ padding: "2rem" }} open={isLoginDialogOpen} onClose={handleClose}>
      <DialogTitle style={{ textAlign: "center" }}>
        Sign In
      </DialogTitle>
      <DialogContent>
        <SignInForm onSuccess={handleSuccess} />
        <Divider className={styles.formItem}>OR</Divider>
        <Button className={styles.formItem} color="secondary" fullWidth onClick={handleCreateAccountClick}>Create an Account</Button>
      </DialogContent>
    </Dialog>
  )
}

export default SignInDialog;