import { Button, Dialog, DialogContent, DialogTitle, Divider, useTheme } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { selectUser, toggleLoginDialog, toggleRegisterDialog } from "../../store/slices/userSlice";
import styles from '../../styles/util.module.css';
import SignUpForm from "./signUpForm";
import useMediaQuery from '@mui/material/useMediaQuery';

const SignUpDialog = () => {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('md'));

  const { isRegisterDialogOpen } = useSelector(selectUser);
  const dispatch = useDispatch();


  const handleClose = () => {
    dispatch(toggleRegisterDialog());
  }

  const handleCreateAccountClick = () => {
    handleClose();
    dispatch(toggleLoginDialog());
  }

  const handleSuccess = () => {
    console.log("Success");
    handleCreateAccountClick();
  }

  return (
    <Dialog fullScreen={fullScreen} fullWidth maxWidth="sm" style={{ padding: "3rem" }} open={isRegisterDialogOpen} onClose={handleClose}>
      <DialogTitle style={{ textAlign: "center" }}>
        Sign Up
      </DialogTitle>
      <DialogContent>
        <SignUpForm onSuccess={handleSuccess} />
        <Divider className={styles.formItem}>OR</Divider>
        <Button className={styles.formItem} color="secondary" fullWidth onClick={handleCreateAccountClick}>Already have an account?</Button>
      </DialogContent>
    </Dialog>
  )
}

export default SignUpDialog;