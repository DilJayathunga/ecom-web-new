import { Paper, Typography } from "@mui/material";
import Image from "next/image";
import cartHero from '../../public/cart/cart_hero.png';
import CartItem from "./cartItem";
import { useTheme } from '@mui/material/styles';

const CartDetails = ({ items }) => {
  const theme = useTheme();

  return (
    <>
      <Typography variant="h5" fontWeight="bold" color="primary">Cart <span style={{ color: theme.palette.secondary.main, fontSize: "1rem" }}>( {items.length} items )</span></Typography>
      <Image src={cartHero} alt="cart hero" style={{ marginTop: "1rem" }} />
      <Paper variant="outlined" square style={{ padding: "0.5rem", marginTop: "1rem" }}>
        {items.map(item => (
          <CartItem key={item.orderDetId} item={item} />
        ))}
      </Paper>
    </>
  )
}

export default CartDetails;