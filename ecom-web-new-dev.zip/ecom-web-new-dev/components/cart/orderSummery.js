import { Button, OutlinedInput, Paper, Typography } from "@mui/material";
import Image from "next/image";
import paymentImage from '../../public/payment_methods/paymentMethodImage.png';
import { useTheme } from '@mui/material/styles';
import Link from "next/link";

export const SummeryPaper = ({ items, disableCoupon = false, enableDelivery = false, orderDet }) => (
  <Paper variant="outlined" square style={{ padding: "1rem", paddingBottom: "2rem" }}>
    <Typography variant="h6" fontWeight="bold" style={{ color: "#707070" }}>Order Summery</Typography>
    <hr />
    {!disableCoupon &&
      <div style={{ display: "flex", marginBlock: "1rem" }}>
        <OutlinedInput placeholder="Coupon Code" size="small" fullWidth style={{ flexBasis: "70%", borderRadius: 0 }} />
        <Button variant="contained" style={{ flexBasis: "30%", borderRadius: 0, fontWeight: "bold" }}>Apply</Button>
      </div>
    }
    <div style={{ marginBlock: "1rem" }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "0.3rem" }}>
        <Typography fontWeight="bold" style={{ color: "#707070" }}>Subtotal ({items.length} items)</Typography>
        <Typography fontWeight="bold" style={{ color: "#707070" }}>$ {parseFloat(orderDet?.totAmt).toFixed(2)}</Typography>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <Typography fontWeight="bold" style={{ color: "#707070" }}>Shipping Details</Typography>
        <Typography fontWeight="bold" style={{ color: "#707070" }}>Free</Typography>
      </div>
    </div>
    {enableDelivery &&
      <>
        <Typography variant="h6" fontWeight="bold" style={{ color: "#707070" }}>Delivery Option</Typography>
        <hr />
        <div style={{ marginBlock: "1rem" }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "0.3rem" }}>
            <Typography fontWeight="bold" style={{ color: "#707070" }}>Get It Together</Typography>
            <Typography fontWeight="bold" style={{ color: "#707070" }}>Free</Typography>
          </div>
        </div>
      </>
    }
    <hr />
  </Paper>
)

export const Total = ({ orderDet }) => (
  <div style={{ display: "flex", justifyContent: "space-between", paddingInline: "1rem", paddingBlock: "0.5rem", backgroundColor: "lightgrey" }}>
    <Typography variant="h6" fontWeight="bold" style={{ color: "#707070" }}>TOTAL <span style={{ fontSize: "0.9rem" }}>(Inclusive of VAT)</span></Typography>
    <Typography variant="h6" fontWeight="bold" color="primary">$ {parseFloat(orderDet?.totChg).toFixed(2)}</Typography>
  </div>
)

const OrderSummery = ({ items, orderDet }) => {
  const theme = useTheme();

  return (
    <>
      <SummeryPaper items={items} orderDet={orderDet}/>
      <Total orderDet={orderDet}/>
      <Link href="/checkout">
        <Button variant="contained" fullWidth style={{ borderRadius: 0, fontWeight: "bold" }}>CHECKOUT</Button>
      </Link>
      <Paper variant="outlined" square style={{ padding: "1rem", paddingBottom: "2rem" }}>
        <hr />
        <Typography fontWeight="bold" style={{ color: "#707070", marginTop: "1rem" }}>Buy Now, Pay Later With noon EMI</Typography>
        <Typography fontStyle="italic" style={{ marginBlock: "1rem" }} color="text.secondary">
          Available when you spend AED 500 with selected cards from the banks below. <a href="#" style={{ textDecoration: "underline", color: theme.palette.primary.main }}>Find out more</a>
        </Typography>
        <Image width={250} height={35} src={paymentImage} alt="payment methods" />
      </Paper>
    </>
  )
}

export default OrderSummery;