import DeleteIcon from '@mui/icons-material/Delete';
import { Button, Checkbox, Divider, Typography } from "@mui/material";
import Image from 'next/image';
import { useState } from 'react';
import Counter from '../shared/Counter';
import { useTheme } from '@mui/material/styles';
import { useDeleteCartItemMutation, useUpdateCartQuantityMutation } from '../../store/services/cartService';
import { useCookies } from "react-cookie"
import { toast } from 'react-toastify';

const CartItem = ({ item }) => {
  const theme = useTheme();
  const [qty, setQty] = useState(item.qty);
  const [cookies, setCookie] = useCookies(["cartItems"])

  const sampleImage = "https://cdn.dribbble.com/users/1224589/screenshots/14551841/media/b2654a557839408e9ae421bb6c8bf9de.jpg?compress=1&resize=400x300"

  const [deleteCartItem] = useDeleteCartItemMutation();

  const handleItemDelete = async () => {
    const id = item.orderDetId;
    console.log('deleted cart item', id)

    try {
        const deletedItem = await deleteCartItem(id).unwrap();
        console.log('deleted category', deletedItem)
        toast.success("Cart Item successfully deleted!");
        const items = Number(cookies.cartItems)-1
        setCookie("cartItems", items, {
            path: "/",
            // maxAge: 3600, // Expires after 1hr
            maxAge: 172800, //expires in 2 days
            sameSite: true
        })
    } catch (err) {
        console.error('Failed to delete the category: ', err)
        toast.error("Erorr, something went wrong!");
    }
  }

  const [updateQty] = useUpdateCartQuantityMutation();

  const updateQuantity = async () => {
    // console.log('update qty!')
    const dataSet = {
      orderDetId: item.orderDetId,
      qty: qty
    }
    if(qty > 1){
      try {
        const updatedQty = await updateQty(dataSet).unwrap();
        console.log("add item", updatedQty);
        toast.success("Category successfully updated!");
      } catch (err) {
          console.error("Failed to save the item: ", err);
          toast.error("Erorr, something went wrong!");
      }
    }
    
  }

  const handleQtyIncrement = () => {
    setQty((currentQty) => currentQty + 1);
    updateQuantity()
  }

  const handleQtyDecrement = () => {
    setQty((currentQty) => {
      if (currentQty > 1) {
        return currentQty - 1;
      }

      return currentQty;
    });
    updateQuantity()
  }

  return (
    <div style={{ marginBottom: "1.5rem" }}>
      <div style={{ display: "flex", gap: "2rem", marginBottom: "0.5rem" }}>
        <Checkbox defaultChecked={true}/>
        <img width={160} src={item.img || sampleImage} alt="Product Image" style={{ height: "fit-content", alignSelf: "center" }} />
        <div width={1000}>
          <Typography fontWeight="bold">{item.title}</Typography>
          <Typography color="text.secondary" style={{ marginTop: "0.3rem" }}>{item.overView}</Typography>
          <ul style={{ marginTop: "1rem", paddingInlineStart: "20px" }}>
            {/* <li style={{ color: theme.palette.secondary.main }}><span style={{ color: theme.palette.text.primary }}>Free delivery by Tomorrow</span></li>
            <li style={{ color: theme.palette.secondary.main }}><span style={{ color: theme.palette.text.primary }}>1 year warrenty</span></li> */}
            {item.variants?.map((varnt) => {
              return(<li style={{ color: theme.palette.secondary.main }}><span style={{ color: theme.palette.text.primary }}>{varnt.variant}: {varnt.variantValue}</span></li>
            )})}
          </ul>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <Button onClick={() => handleItemDelete()} color="error" startIcon={<DeleteIcon />}>Remove</Button>
            <div style={{ display: "flex", justifyContent: "space-between", gap: "1rem" }}>
              <Counter value={qty} onIncrement={handleQtyIncrement} onDecrement={handleQtyDecrement} />
              <Typography variant='h6' fontStyle="italic" fontWeight="bold" color="primary"><span style={{ color: theme.palette.secondary.main }}>$</span>{parseFloat(item.amt).toFixed(2)}</Typography>
            </div>
          </div>
        </div>
      </div>
      <Divider />
    </div>
  )
}

export default CartItem;