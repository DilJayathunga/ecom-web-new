import { yupResolver } from '@hookform/resolvers/yup';
import { Button, TextField, Typography } from '@mui/material';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import { object, string } from 'yup';
import { useCreateOrganizationMutation } from '../../store/services/orgService';
import { closeOrgModal, selectOrg } from '../../store/slices/orgSlice';
import styles from '../../styles/util.module.css';
import OperationsDialog from '../shared/operationsDialog';

const schema = object().shape({
  orgName: string().required("Organization name is required!"),
  orgAddress: string().required("Organization address is required!"),
});

const AddOrgDialog = () => {
  const org = useSelector(selectOrg);
  const dispatch = useDispatch();

  const { register, handleSubmit, reset, formState: { errors } } = useForm({
    defaultValues: {
      orgName: "",
      orgAddress: "",
    },
    resolver: yupResolver(schema),
  });

  const [createOrg, { isLoading }] = useCreateOrganizationMutation();

  const submit = async (data) => {
    try {
      await createOrg(data).unwrap();
      toast.success("Organization successfully added!");
    } catch (err) {
      console.error(err);
      toast.error("Erorr, something went wrong!");
    } finally {
      dispatch(closeOrgModal());
    }
  }

  const handleClose = () => {
    reset();
    dispatch(closeOrgModal());
  }

  return (
    <OperationsDialog open={org.modalStatus === "add"} onClose={handleClose} maxWidth="sm">
      <Typography my={3} variant="h5" textAlign="center" fontWeight="bold">
        Organization Creation
      </Typography>

      <form onSubmit={handleSubmit(submit)}>
        <div className={styles.formItem}>
          <label className={styles.formLabel}>Name:</label>
          <TextField {...register("orgName")} size="small" fullWidth placeholder='Enter organization name' className={styles.formText} error={!!errors.orgName} helperText={errors.orgName?.message} />
        </div>
        <div className={styles.formItem}>
          <label className={styles.formLabel}>Address:</label>
          <TextField {...register("orgAddress")} size="small" fullWidth placeholder='Enter organization address' className={styles.formText} error={!!errors.orgAddress} helperText={errors.orgAddress?.message} />
        </div>
        <Button variant="contained" className={styles.formItem} type="submit" disabled={isLoading}>Save</Button>
      </form>
    </OperationsDialog>
  )
}

export default AddOrgDialog;