import { Delete, Edit, Visibility } from "@mui/icons-material";
import { Box, ButtonGroup, IconButton, Pagination, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material";
import { useState } from "react";
import { useDispatch } from "react-redux";
import usePagination from "../../hooks/usePagination";
import { openDeleteOrgModal, openEditOrgModal } from "../../store/slices/orgSlice";

const OrgTable = ({ orgs }) => {
  const dispatch = useDispatch();

  let [page, setPage] = useState(1);
  const PER_PAGE = 8;

  const count = Math.ceil(orgs.length / PER_PAGE);
  const _DATA = usePagination(orgs, PER_PAGE);

  const handleChange = (e, p) => {
    setPage(p);
    _DATA.jump(p);
  }

  const handleViewClick = (id) => {
    //dispatch(openItemForm(true));
  }

  const handleEditClick = (id) => {
    dispatch(openEditOrgModal(id));
  }

  const handleDeleteClick = (id) => {
    dispatch(openDeleteOrgModal(id));
  }

  return (
    <>
      <TableContainer sx={{ height: '400px' }}>
        <Table stickyHeader aria-label="simple table" sx={{ height: "max-content" }}>
          <TableHead>
            <TableRow>
              <TableCell width={50}>Organization Number</TableCell>
              <TableCell width={50}>Organization Name</TableCell>
              <TableCell align="right" width={100}>Address</TableCell>
              <TableCell align="center" width={'30%'}>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {_DATA.currentData().map((org) => (
              <TableRow sx={{ height: '30px' }} key={org.orgId}>
                <TableCell component="th" scope="row" sx={{ borderBottom: "none", fontWeight: 'bold', width: 100, height: 'auto !important' }}>
                  #{org.orgId}
                </TableCell>
                <TableCell sx={{ borderBottom: "none", width: 50, height: 'auto !important' }}>{org.orgName}</TableCell>
                <TableCell align="right" sx={{ borderBottom: "none", width: 50, height: 'auto !important' }}>{org.orgAddress}</TableCell>
                <TableCell align="center" sx={{ borderBottom: "none", width: '30%', height: 'auto !important' }}>
                  <ButtonGroup variant="text" aria-label="text button group">
                    <IconButton aria-label="view" onClick={() => { handleEditClick(org.orgId) }}>
                      <Visibility />
                    </IconButton>
                    {/* <IconButton aria-label="edit" onClick={() => { handleEditClick(org.orgId) }}>
                      <Edit />
                    </IconButton> */}
                    <IconButton aria-label="delete" onClick={() => { handleDeleteClick(org.orgId) }}>
                      <Delete />
                    </IconButton>
                  </ButtonGroup>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Box my={2} display="flex" justifyContent="center">
        <Pagination
          count={count}
          size="large"
          page={page}
          variant="outlined"
          color="primary"
          onChange={handleChange}
          style={{ justifyContent: 'center', right: 0 }}
        />
      </Box>
    </>
  )
}

export default OrgTable;