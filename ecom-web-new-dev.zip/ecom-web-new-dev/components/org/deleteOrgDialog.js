import { Button, Typography } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { toast } from "react-toastify";
import { useDeleteOrganizationMutation } from "../../store/services/orgService";
import { selectOrg, closeOrgModal } from "../../store/slices/orgSlice";
import OperationsDialog from "../shared/operationsDialog";

const DeleteOrgDialog = () => {
  const org = useSelector(selectOrg);
  const dispatch = useDispatch();

  const [deleteOrg, { isLoading }] = useDeleteOrganizationMutation();

  const handleDelete = async () => {
    const id = org.selectedOrganization;
    try {
      const res = await deleteOrg(id).unwrap();
      console.log(res);
      toast.success("Successfully deleted the organization.");
      dispatch(closeOrgModal());
    } catch (err) {
      console.log(err);
      toast.error("Something went wrong.");
      dispatch(closeOrgModal());
    }
  }

  return (
    <OperationsDialog open={org.modalStatus === "delete"} onClose={() => dispatch(closeOrgModal())} maxWidth="xs">
      <Typography my={3} variant="h5" component="div" color="text.primary" textAlign="center" fontWeight="bold">
        Delete Item?
      </Typography>
      <Typography my={3} component="div" color="text.primary" textAlign="center" fontWeight="400">
        Are you sure you want to delete this organization?
      </Typography>

      <div style={{ display: 'flex', justifyContent: 'end' }}>
        <Button onClick={() => dispatch(closeOrgModal())} style={{ margin: '0.5rem' }} variant="contained" color="error">No</Button>
        <Button onClick={handleDelete} style={{ margin: '0.5rem' }} variant="contained" disabled={isLoading}>Yes</Button>
      </div>
    </OperationsDialog>
  )
}

export default DeleteOrgDialog;