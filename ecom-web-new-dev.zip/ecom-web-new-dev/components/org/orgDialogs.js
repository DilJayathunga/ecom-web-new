import { useSelector } from "react-redux";
import { selectOrg } from "../../store/slices/orgSlice";
import AddOrgDialog from "./addOrgDialog";
import DeleteOrgDialog from "./deleteOrgDialog";
import EditOrgDialog from "./editOrgDialog";

const OrgDialogs = () => {
  const org = useSelector(selectOrg);

  switch (org.modalStatus) {
    case "add":
      return <AddOrgDialog />
    case "edit":
      return <EditOrgDialog />
    case "delete":
      return <DeleteOrgDialog />
    default:
      return null;
  }
}

export default OrgDialogs;