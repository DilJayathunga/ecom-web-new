import { Dialog, DialogContent } from "@mui/material";

const OperationsDialog = ({ open, onClose, children, maxWidth = "md" }) => {
  return (
    <Dialog fullWidth maxWidth={maxWidth} open={open} onClose={onClose}>
      <DialogContent>{children}</DialogContent>
    </Dialog>
  )
}

export default OperationsDialog;