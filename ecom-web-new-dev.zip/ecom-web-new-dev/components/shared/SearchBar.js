/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 5/7/2022
 */

import { Grid, IconButton, InputBase, Paper } from "@mui/material";
import { useEffect, useState } from "react";
import SearchIcon from '@mui/icons-material/Search';

const SearchBar = (props) => {

    const { data, setSearchData, text, search } = props;

    const [searchTerm, setSearchTerm] = useState("");

    const handleChange = (e) => {
        setSearchTerm(e.target.value);
    };

    useEffect(() => {
        let results;
        if (search === "title") {
            results = data.filter(d =>
                d.title?.toLowerCase().includes(searchTerm)
            );
        }

        if (search === "name") {
            results = data.filter(d =>
                d.catDisplayName?.toLowerCase().includes(searchTerm)
            );
        }

        if (search === "org_name") {
            results = data.filter(d =>
                d.orgName?.toLowerCase().includes(searchTerm)
            );
        }

        if (search === "seller") {
            results = data.filter(d =>
                d.sellerName?.toLowerCase().includes(searchTerm)
            );
        }

        if (search === "brand") {
            results = data.filter(d =>
                d.brandName?.toLowerCase().includes(searchTerm)
            );
        }

        if (search === "policy") {
            results = data.filter(d =>
                d.policy?.toLowerCase().includes(searchTerm)
            );
        }

        setSearchData(results);
    }, [searchTerm, data, setSearchData, search]);

    return (
        <div>
            <div style={{ display: "flex", padding: "40px 0px 40px 0", width: '100%' }}>
                <div
                    style={{
                        width: "60px",
                        height: "40px",
                        backgroundColor: "#03a5b2",
                        textAlign: "center",
                        borderRadius: "5px 0 0 5px",
                    }}
                >
                    <IconButton>
                        <SearchIcon style={{ color: "white" }} />
                    </IconButton>
                </div>
                <InputBase
                    value={searchTerm}
                    onChange={handleChange}
                    placeholder={text}
                    style={{
                        width: "100%",
                        border: 'solid 1px #757575',
                        padding: '0 0 0 10px'
                    }}
                />
            </div>
        </div>
    );
}

export default SearchBar;