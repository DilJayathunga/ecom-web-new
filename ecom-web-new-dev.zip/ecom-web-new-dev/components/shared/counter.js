import { Button, ButtonGroup } from "@mui/material";

const Counter = ({ value, onIncrement, onDecrement, size = "small" }) => {
  return (
    <ButtonGroup size={size}>
      <Button onClick={onDecrement}>-</Button>
      <Button disableFocusRipple disableRipple disableTouchRipple disableElevation>{value}</Button>
      <Button onClick={onIncrement}>+</Button>
    </ButtonGroup>
  );
}

export default Counter;