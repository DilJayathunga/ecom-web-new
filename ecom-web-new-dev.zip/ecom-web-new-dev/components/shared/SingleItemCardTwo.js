/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 20/01/2020
 */

import { Favorite } from "@mui/icons-material";
import { Box, Card, CardContent, CardMedia, Grid, IconButton, Rating, Typography } from "@mui/material";
import Link from "next/link";

const SingleItemCardTwo = (props) => {
  const { itemData } = props;

  return (
    <Grid item xs={12} sm={12} md={12} lg={12} xl={12}>
      <Link href={`/product/${itemData.prodDefId || itemData.prod_def_id}`}>
        <Card sx={{ display: "flex", cursor: "pointer" }}>
          <CardMedia
            component="img"
            sx={{ width: 150 }}
            image="https://5.imimg.com/data5/CF/YD/BL/SELLER-24989634/nike-air-max-270-sports-shoes-500x500.jpg"
            alt="Live from space album cover"
          />

          <Box sx={{ flex: 1 }}>
            <CardContent sx={{ flex: "1 0 auto" }}>
              <Typography component="div" variant="h6">
                {itemData.title} - {itemData.prodDefId || itemData.prod_def_id}
              </Typography>

              <Typography variant="subtitle1" color="text.secondary">
                {itemData.overview}
              </Typography>

              <Typography variant="body2" color="text.secondary">
                LKR {itemData.price} - stock {itemData.quantity}
              </Typography>
            </CardContent>
          </Box>

          <Box sx={{ pl: 1, pb: 1 }}>
            <Rating
              name="simple-controlled"
              value={3}
              readOnly
              style={{ zIndex: 0 }}
            />
            <Typography variant="body2" color="text.secondary">
              Free Shippning
            </Typography>
          </Box>

          <Box sx={{}}>
            <IconButton aria-label="add to favorites">
              <Favorite />
            </IconButton>
          </Box>
        </Card>
      </Link>
    </Grid>
  );
};
export default SingleItemCardTwo;
