/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 26/8/2022
 */

import { useDispatch, useSelector } from "react-redux";
import { Dialog, DialogContent } from "@mui/material";
import { openSellerForm } from "../../store/slices/sellerSlice";
import AddSeller from "./addSeller";
import EditSeller from "./editSeller";
import DeleteSeller from "./deleteSeller";

const SellerDialog = () => {
    const dispatch = useDispatch();
    const seller = useSelector((state) => state.seller);
    
    let content;
    const deleteView = false
  
    if (seller.status === "add") {
      content = <AddSeller/>;
    // } else if (seller.status === "view") {
    // //   content = <ViewSeller/>;
    } else if (seller.status === "edit") {
      content = <EditSeller/>;
    } else if (seller.status === "delete") {
      deleteView = true
      content = <DeleteSeller/>;
    } 
  
    return (
        <>
            <Dialog
                fullWidth={true}
                maxWidth={deleteView ? "xs" : "sm"}
                open={seller.sellerPageOpen}
                onClose={() => dispatch(openSellerForm(false))}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogContent>{content}</DialogContent>
            </Dialog>
        </>
    );
};
  
export default SellerDialog;