/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 29/8/2022
 */

import { Button, Container, Typography } from "@mui/material";
import { useSelector, useDispatch } from "react-redux";
import { toast } from "react-toastify";
import { openSellerForm } from "../../store/slices/sellerSlice";
import { useDeleteSellerMutation } from "../../store/services/sellerService";

const DeleteSeller = () => {

    const dispatch = useDispatch();
    const seller = useSelector((state) => state.seller);

    const [deleteSeller, { isLoading }] = useDeleteSellerMutation();

    const onDeleteConfirm = async () => {
        console.log('Deleted...', seller.selectedSeller);
        const id = seller.selectedSeller;
        try {
            const deletedCat = await deleteSeller(id).unwrap();
            console.log('deleted seller', deletedCat)
            toast.success("Seller successfully deleted!");
        } catch (err) {
            console.error('Failed to delete the seller: ', err)
            toast.error("Erorr, something went wrong!");
        }
        dispatch(openSellerForm(false));
    }

    return ( 
        <Container maxWidth="md">

            <Typography my={3} variant="h5" component="div" color="text.primary" textAlign="center" fontWeight="bold">
                Delete Seller?
            </Typography>

            <Typography my={3} component="div" color="text.primary" textAlign="center" fontWeight="400">
                Are you sure you want to delete this seller?
            </Typography>

            <div style={{ display: 'flex', justifyContent: 'center', marginTop: "1rem" }}>
                <Button onClick={() => dispatch(openSellerForm(false))} style={{margin: '0.5rem', width: "10rem"}} fullWidth variant="contained">No</Button>
                <Button onClick={onDeleteConfirm} style={{margin: '0.5rem', width: "10rem"}} fullWidth variant="contained">Yes</Button>
            </div>
        
        </Container>
    );
}

export default DeleteSeller;