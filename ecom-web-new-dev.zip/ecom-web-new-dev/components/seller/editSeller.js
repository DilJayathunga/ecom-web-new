/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 29/8/2022
 */


import { yupResolver } from '@hookform/resolvers/yup';
import { Backdrop, Button, CircularProgress, TextField, Typography } from '@mui/material';
import { useEffect, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import { object, string } from 'yup';
import { useGetSellerByIdQuery, useUpdateSellerMutation } from '../../store/services/sellerService';
import { openSellerForm } from '../../store/slices/sellerSlice';
import styles from '../../styles/util.module.css';

const schema = object().shape({
  sellerName: string().required(),
});

const EditSeller = () => {

    const dispatch = useDispatch();
    const seller = useSelector((state) => state.seller);

    let sellerData = useMemo(() => {
        return({sellerName: ''})
    }, []);  

    const { register, handleSubmit, reset, formState: { errors } } = useForm({
        resolver: yupResolver(schema),
    });

    const { data, isSuccess, isLoading } = useGetSellerByIdQuery(seller.selectedSeller);
    if(isSuccess){
        sellerData = data.list[0];
    }

    useEffect(() => {
        reset({
            sellerName: sellerData.sellerName,
        });
    }, [sellerData, reset]);
    
    const [ editSeller ] = useUpdateSellerMutation();

    const submit = async (data) => {
        const dataSet = {
            sellerId: sellerData.sellerId,
            ...data
        }
        try {
            await editSeller(dataSet).unwrap();
            toast.success("Seller successfully updated!");
        } catch (err) {
            console.error(err);
            toast.error("Erorr, something went wrong!");
        } finally {
            dispatch(openSellerForm(false));
        }
    }

    return (
        <>
            <Typography my={3} variant="h5" textAlign="center" fontWeight="bold">
                Update Seller
            </Typography>

            {isLoading && (
                <Backdrop
                    sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
                    open={isLoading}
                >
                    <CircularProgress color="inherit" />
                </Backdrop>
            )}
            <form onSubmit={handleSubmit(submit)}>
                <div className={styles.formItem}>
                    <label className={styles.formLabel}>Name:</label>
                    {errors.sellerName && errors.sellerName.type === "required" && <span style={{color: 'red'}}> *</span>}
                    <TextField defaultValue={sellerData.sellerName} {...register("sellerName")} size="small" fullWidth className={styles.formText} />
                </div>
                {/* Submit Button */}
                <div style={{ marginTop: "2rem", marginBottom: '1rem', display: 'flex', justifyContent: 'center' }}>
                    <Button type="submit" style={{width: "10rem"}} variant="contained">Update</Button>
                </div>
            </form>
        </>
    )
}

export default EditSeller;