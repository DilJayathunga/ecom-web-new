/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 26/8/2022
 */

import { yupResolver } from '@hookform/resolvers/yup';
import { Button, TextField, Typography } from '@mui/material';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import { object, string } from 'yup';
import { useCreateSellerMutation } from '../../store/services/sellerService';
import { openSellerForm } from '../../store/slices/sellerSlice';
import styles from '../../styles/util.module.css';

const schema = object().shape({
  sellerName: string().required("Seller name is required!"),
});

const AddSeller = () => {

    const dispatch = useDispatch();

    const { register, handleSubmit, reset, formState: { errors } } = useForm({
        defaultValues: {
            sellerName: "",
        },
        resolver: yupResolver(schema),
    });

    const [createSeller] = useCreateSellerMutation();

    const submit = async (data) => {
        try {
            await createSeller(data).unwrap();
            toast.success("Seller successfully added!");
        } catch (err) {
            console.error(err);
            toast.error("Erorr, something went wrong!");
        } finally {
            dispatch(openSellerForm(false));
        }
    }

    return (
        <>
            <Typography my={3} variant="h5" textAlign="center" fontWeight="bold">
                Seller Creation
            </Typography>

            <form onSubmit={handleSubmit(submit)}>
                <div className={styles.formItem}>
                    <label className={styles.formLabel}>Name:</label>
                    {errors.sellerName && errors.sellerName.type === "required" && <span style={{color: 'red'}}> *</span>}
                    <TextField {...register("sellerName")} size="small" fullWidth placeholder='Enter seller name' className={styles.formText} />
                </div>
                {/* Submit Button */}
                <div style={{ marginTop: "2rem", marginBottom: '1rem', display: 'flex', justifyContent: 'center' }}>
                    <Button type="submit" style={{width: "10rem"}} variant="contained">Save</Button>
                </div>
            </form>
        </>
    )
}

export default AddSeller;