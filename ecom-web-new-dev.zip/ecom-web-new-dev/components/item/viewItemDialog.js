/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 19/8/2022
 */

import { Autocomplete, Backdrop, Button, Chip, CircularProgress, Container, Dialog, DialogContent, Grid, OutlinedInput, Table, TableBody, TableCell, TableHead, TableRow, TextField, Typography } from "@mui/material";
import OperationsDialog from "../shared/operationsDialog";
import { useDispatch, useSelector } from "react-redux";
import { closeItemModal, selectItem } from "../../store/slices/itemSlice";
import styles from '../../styles/util.module.css';
import { useEffect, useState } from "react";
import parse from 'html-react-parser';
import ImageUploader from "./ImageUploader";
import { useGetItemByIdQuery } from "../../store/services/itemService";

const ViewItemDialog = () => {

    const item = useSelector(selectItem);
    const dispatch = useDispatch();

    const [open, setOpen] = useState(false)
    const [images, setImages] = useState([])

    let itemDetails = {keywords: ""};
    const { data, isSuccess, isLoading } = useGetItemByIdQuery(item.selectedItem);
    if(isSuccess){
        console.log('data/////////////',data)
        itemDetails = data;
    }

    return (  
        <OperationsDialog open={item.modalStatus === "view"} onClose={() => dispatch(closeItemModal())} maxWidth="xl">
            <Typography my={3} variant="h5" textAlign="center" fontWeight="bold">
                Item Details
            </Typography>

            {isLoading && (
                <Backdrop
                    sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
                    open={isLoading}
                >
                    <CircularProgress color="inherit" />
                </Backdrop>
            )}

            <Grid container columnSpacing={2} rowSpacing={1}>
                <Grid item xs={12} md={6}>
                    <label className={styles.formLabel}>Title:</label>
                    <OutlinedInput value={itemDetails.title} size="small" fullWidth className={styles.formText} disabled />
                </Grid>
                <Grid item xs={12} md={6}>
                    <label className={styles.formLabel}>Model Number:</label>
                    <OutlinedInput value={itemDetails.modelNumber} size="small" fullWidth className={styles.formText} disabled />
                </Grid>
                <Grid item xs={12} md={6}>
                    <label className={styles.formLabel}>Overview:</label>
                    <OutlinedInput value={itemDetails.overview} style={{marginBottom: '10px'}} size="small" fullWidth className={styles.formText} multiline rows={5} disabled />
                    <label className={styles.formLabel}>Description:</label>
                    <OutlinedInput value={itemDetails.description} size="small" fullWidth className={styles.formText} multiline rows={4} disabled />
                    <div style={{ marginTop: "0.5rem", display: 'flex', justifyContent: 'right' }}>
                        <Button color="secondary" variant="contained" onClick={() => setOpen(true)}>View HTML Description</Button>
                        <Dialog fullWidth={true} maxWidth={"lg"} open={open} onClose={() => setOpen(false)}>
                            <DialogContent>
                                <Container>
                                    {parse(itemDetails.description || 'This is HTML description')}
                                </Container>
                            </DialogContent>
                        </Dialog>
                    </div>            
                </Grid>
                <Grid item xs={12} md={6}>
                    
                    <label className={styles.formLabel}>Images:</label>
                    <ImageUploader images={images} setImages={setImages} from="view" />
                </Grid>
                <Grid item xs={12} md={6}>
                    <label className={styles.formLabel}>Category:</label>
                    <OutlinedInput value={itemDetails.catName} size="small" fullWidth className={styles.formText} disabled />
                </Grid>
                <Grid item xs={12} md={6}>
                    <label className={styles.formLabel}>Brand:</label>
                    <OutlinedInput value={itemDetails.brandName} size="small" fullWidth className={styles.formText} disabled />
                </Grid>
                <Grid item xs={12} md={6}>
                    <label className={styles.formLabel}>Seller:</label>
                    <OutlinedInput value={itemDetails.sellerName} size="small" fullWidth className={styles.formText} disabled />
                </Grid>
                <Grid item xs={12} md={6}>
                    <label className={styles.formLabel}>Organization:</label>
                    <OutlinedInput value={itemDetails.orgName} size="small" fullWidth className={styles.formText} disabled />
                </Grid>
                <Grid item xs={12} md={6}>
                    <label className={styles.formLabel}>Return Policy:</label>
                    <OutlinedInput value={itemDetails.returnPolicyName} size="small" fullWidth className={styles.formText} disabled />
                </Grid>
                <Grid item xs={12} md={6}>
                    <label className={styles.formLabel}>Exchange Policy:</label>
                    <OutlinedInput value={itemDetails.exchangePolicyName} size="small" fullWidth className={styles.formText} disabled />
                </Grid><Grid item xs={12} md={4}>
                    <label className={styles.formLabel}>Quantity:</label>
                    <OutlinedInput value={itemDetails.quantity} size="small" fullWidth className={styles.formText} disabled/>
                </Grid>
                <Grid item xs={12} md={4}>
                    <label className={styles.formLabel}>Price:</label>
                    <OutlinedInput value={itemDetails.price} size="small" fullWidth className={styles.formText} disabled />
                </Grid>
                <Grid item xs={12} md={4}>
                    <label className={styles.formLabel}>Discount (%):</label>
                    <OutlinedInput value={itemDetails.discount} size="small" fullWidth className={styles.formText} disabled />
                </Grid>
                <Grid item xs={12} md={4}>
                    <label className={styles.formLabel}>Days to deliver:</label>
                    <OutlinedInput value={itemDetails.dayToDelivery} size="small" fullWidth className={styles.formText} disabled />
                </Grid>
                <Grid item xs={12} md={4}>
                    <label className={styles.formLabel}>Points:</label>
                    <OutlinedInput value={itemDetails.points} size="small" fullWidth className={styles.formText} disabled />
                </Grid>
                <Grid item xs={12} md={4}>
                    <label className={styles.formLabel}>Warranty Period (Months):</label>
                    <OutlinedInput value={itemDetails.warrantyPeriodMonths} size="small" fullWidth className={styles.formText} disabled />
                </Grid>
                <Grid item xs={12}>
                    <label className={styles.formLabel}>Keywords:</label>
                    {/* <OutlinedInput value={itemDetails.keyWords} size="small" fullWidth className={styles.formText} disabled /> */}
                    <Autocomplete
                        disabled
                        defaultValue={itemDetails.keyWords?.split(",")}
                        // onChange={(_, newKeyword) => {
                        //     setValue("keyWords", newKeyword);
                        // }}
                        size="small"
                        placeholder="Enter Keywords"
                        multiple
                        options={[]}
                        freeSolo
                        renderTags={(value) =>
                            value?.map((option) => (
                            <Chip key={option} size="small" variant="outlined" label={option} />
                            ))
                        }
                        renderInput={(params) => (
                            <TextField
                                {...params}
                            />
                        )}
                    />
                </Grid>
                <Grid item xs={12} md={6}>  
                    {itemDetails.attributes &&   
                        <fieldset>
                            <legend>Attributes</legend>
                            {itemDetails.attributes && itemDetails.attributes?.map((attr) => (
                            <div key={attr.attributeValueId} style={{ display: "flex", gap: "2rem", marginBlock: "1rem", justifyContent: "space-between" }}>
                                <Typography fontWeight="bold">{attr.attributeName}:</Typography>
                                <OutlinedInput value={attr.values} size="small" fullWidth style={{ flexBasis: "60%" }} disabled />
                            </div>
                            ))}
                        </fieldset>
                    } 
                </Grid>
            </Grid>
            <fieldset className={styles.formItem}>
              <legend>Variants</legend>
                <Table>
                    <TableHead>
                        {itemDetails.variants && itemDetails.variants[0]?.combo?.map((combo) => {
                            return(
                                <TableCell key={combo.id} align="center" width="20%" >{combo.variant}</TableCell>
                            );
                        })}
                        <TableCell align="center" width={160}>Quantity</TableCell>
                        <TableCell align="center" width={160}>Price</TableCell>
                        <TableCell align="center" width={160}>Discount (%)</TableCell>
                    </TableHead>
                    <TableBody>
                        {itemDetails.variants && itemDetails.variants?.map((variant) => {
                            return(
                                <>
                                    <TableRow>
                                        {variant.combo?.map((combo) => {
                                            return(
                                                <TableCell key={combo.id} align="center">{combo.value}</TableCell>
                                            );
                                        })}
                                        <TableCell align="center">{variant.qty}</TableCell>
                                        <TableCell align="center">{variant.price}</TableCell>
                                        <TableCell align="center">{variant.discount}</TableCell>
                                    </TableRow>
                                </>
                            );
                        })}
                    </TableBody>
                </Table>
            </fieldset>

        </OperationsDialog>
    );
}

export default ViewItemDialog;

// const itemDetails = {
//     productId: 119,
//     title: "T-Shirt",
//     modelNumber: "10",
//     overview: "This is overview",
//     description: "<p>This is the product description!</p>",
//     imgList: ["1.jpg", "2.jpg"],
//     prodCatId: 15,
//     catName: 'Boys',
//     brandId: 3,
//     brandName: 'test',
//     sellerId: 2,
//     sellerName: 'test',
//     orgId: 1,
//     orgName: 'test',
//     returnPolicyId: 2,
//     returnPolicyName: 'test',
//     exchangePolicyId: 1,
//     exchangePolicyName: 'test',
//     quantity: '200',
//     price: '25',
//     discount: '5',
//     dayToDeliver: "5",
//     points: "10",
//     warrantyPeriodMonths: "1",
//     keyWords: ['boy', 'shirt', 'cute'],
//     attributes: [
//         {
//             attributeValueId: 110,
//             attributeId: 282,
//             attributeName: 'color',
//             value: "blue, red, green, white, purple"
//         }
//     ],
//     variants: [
//         {
//             combo: [
//                 {
//                     variantId: 85,
//                     variant: 'Color',
//                     valueId: 190,
//                     value: 'red'
//                 },
//                 {
//                     variantId: 86,
//                     variant: 'Size',
//                     valueId: 193,
//                     value: 'Small'
//                 },
//                 {
//                     variantId: 87,
//                     variant: 'Material',
//                     valueId: 198,
//                     value: 'Cotton'
//                 },
    
//             ],
//             qty: "50",
//             price: "65",
//             discount: "5"
//         },
//         {
//             combo: [
//                 {
//                     variantId: 85,
//                     variant: 'Color',
//                     valueId: 190,
//                     value: 'red'
//                 },
//                 {
//                     variantId: 86,
//                     variant: 'Size',
//                     valueId: 193,
//                     value: 'Medium'
//                 },
//                 {
//                     variantId: 87,
//                     variant: 'Material',
//                     valueId: 198,
//                     value: 'Cotton'
//                 },
    
//             ],
//             qty: "60",
//             price: "65",
//             discount: ""
//         },
//     ]
// }
