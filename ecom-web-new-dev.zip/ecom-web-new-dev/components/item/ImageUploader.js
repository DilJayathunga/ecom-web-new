/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 15/8/2022
 */

import { Button, IconButton, ImageList, ImageListItem, ImageListItemBar } from "@mui/material";
import { HighlightOff } from "@mui/icons-material";
import { useState } from "react";


const ImageUploader = (props) => {

    const {images, setImages, from } = props;
    // let {urlList} = props;

    // if(images.length > 0){
    //   urlList = images;
    //   set
    // }

    const onImageUpload = (e) => {
      setImages([...images, e.target.files[0]])
      // urlList = [...urlList, URL.createObjectURL(e.target.files[0])]
    }

    const handleDeleteImage = (e) => {
        const s = images.filter((item, index) => index !== e);
        setImages(s);
        console.log(s);
      };
  
    return (
        <div style={{ borderStyle: 'solid', borderColor: '#c4c4c4', borderWidth: '1px', marginTop: '5px', borderRadius: '4px'}}>
                <ImageList sx={{ width: 580, height: 250, marginLeft: '15px', overflowY: 'inherit' }} gap={10} cols={5} rowHeight={100}>
                  {images.length > 0 &&
                    images.map((img, index) => (
                    <div key={index} sx={{width: 10, height: 10, borderStyle: 'solid'}}>
                    <ImageListItem>
                      <img src={URL.createObjectURL(img)} alt="" style={{borderStyle: 'solid', borderColor: 'black', borderWidth: '1px'}}/>
                      <ImageListItemBar
                        sx={{
                          background:
                            'linear-gradient(to bottom, rgba(0,0,0,0.7) 0%, ' +
                            'rgba(0,0,0,0.3) 0%, rgba(0,0,0,0) 0%)',
                        }}
                        position="top"
                        actionIcon={
                          <IconButton
                            sx={{ color: 'white', background: 'black', height: '2px', width: '2px',padding: '10px'}}
                            onClick={() => handleDeleteImage(index)}
                          >
                            <HighlightOff/>
                          </IconButton>
                        }
                        actionPosition="right"
                      />
                    </ImageListItem>
                    </div>
                  ))}
                </ImageList> 
                <div>
                    <label htmlFor="contained-button-file">
                      <div style={{display: "flex", justifyContent:'right', margin: '0 5px 5px 0'}}>    
                        {from === "view" ? null :                    
                          <Button color="secondary" variant="contained" component="span">
                            Upload
                            <input  
                              onChange={onImageUpload}
                              sx={{"&": {marginTop: "0px"}, justifyContent: 'right'}} 
                              fullWidth 
                              accept="image/*" 
                              id="contained-button-file" 
                              type="file" 
                              hidden
                            />
                          </Button>
                        }
                      </div>
                    </label>
                </div>            
                               
              </div>
    );
  }
  
  export default ImageUploader;