/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 15/8/2022
 */

import { Button, Container, Dialog, DialogContent } from '@mui/material';
import { Editor, EditorTools, EditorUtils } from '@progress/kendo-react-editor';
import '@progress/kendo-theme-material/dist/all.css';
import { useRef, useState } from 'react';

const {
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Subscript,
  Superscript,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  Indent,
  Outdent,
  OrderedList,
  UnorderedList,
  Undo,
  Redo,
  FontSize,
  FontName,
  FormatBlock,
  Link,
  Unlink,
  InsertImage,
  ViewHtml,
  InsertTable,
  AddRowBefore,
  AddRowAfter,
  AddColumnBefore,
  AddColumnAfter,
  DeleteRow,
  DeleteColumn,
  DeleteTable,
  MergeCells,
  SplitCell
} = EditorTools;

const HtmlEditor = (props) => {

    const {from, open, setOpen, description, setDescription} = props;

    const editor = useRef();
    // const [description, setDescription] = useState()
    const getHtml = () => {
        if (editor.current) {
            const view = editor.current.view;
            if (view) {
                setDescription(EditorUtils.getHtml(view.state))
                           
            }
            console.log('view', description)  
        }
        setOpen(false)
    };

    return (
        <>
            <Dialog
                fullWidth={true}
                maxWidth={"lg"}
                open={open}
                onClose={() => setOpen(false)}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogContent>
                    <Container>
                        <div>
                            <Editor 
                                tools={[
                                    [Bold, Italic, Underline, Strikethrough], 
                                    [Subscript, Superscript], 
                                    [AlignLeft, AlignCenter, AlignRight, AlignJustify], 
                                    [Indent, Outdent], 
                                    [OrderedList, UnorderedList], 
                                    FontSize, 
                                    FontName, 
                                    FormatBlock, 
                                    [Undo, Redo], 
                                    [Link, Unlink, InsertImage, ViewHtml], 
                                    [InsertTable], 
                                    [AddRowBefore, AddRowAfter, AddColumnBefore, AddColumnAfter], 
                                    [DeleteRow, DeleteColumn, DeleteTable], 
                                    [MergeCells, SplitCell]
                                ]} 
                                contentStyle={{
                                    height: 320
                                }} 
                                // defaultContent={description} 
                                defaultContent={from=="edit" ? description : '<p>Edit your product description here!</p>'} 
                                ref={editor}
                            />
                        </div>
                        <div style={{ marginTop: "2rem", marginBottom: '1rem', display: 'flex', justifyContent: 'right' }}>
                            <Button 
                                variant='contained' 
                                onClick={getHtml}
                            >
                                Save Description
                            </Button>
                        </div>
                            
                    </Container>
                </DialogContent>
            </Dialog>
        </>
    );
};

export default HtmlEditor;