import { Button, Typography } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { useDeleteItemMutation } from "../../store/services/itemService";
import { closeItemModal, selectItem } from "../../store/slices/itemSlice";
import OperationsDialog from "../shared/operationsDialog";
import { toast } from 'react-toastify';

const DeleteItemDialog = () => {
  const item = useSelector(selectItem);
  const dispatch = useDispatch();

  const [deleteItem, { isLoading }] = useDeleteItemMutation();

  const handleDelete = async () => {
    const id = item.selectedItem;
    try {
      const res = await deleteItem(id).unwrap();
      console.log(res);
      toast.success("Successfully deleted the item.");
      dispatch(closeItemModal());
    } catch (err) {
      console.log(err);
      toast.error("Something went wrong.");
      dispatch(closeItemModal());
    }
  }

  return (
    <OperationsDialog open={item.modalStatus === "delete"} onClose={() => dispatch(closeItemModal())} maxWidth="xs">
      <Typography my={3} variant="h5" component="div" color="text.primary" textAlign="center" fontWeight="bold">
        Delete Item?
      </Typography>
      <Typography my={3} component="div" color="text.primary" textAlign="center" fontWeight="400">
        Are you sure you want to delete this item?
      </Typography>

      <div style={{ display: 'flex', justifyContent: 'center' }}>
        <Button onClick={() => dispatch(closeItemModal())} style={{ margin: '0.5rem', width: "10rem" }} variant="contained">No</Button>
        <Button onClick={handleDelete} style={{ margin: '0.5rem', width: "10rem" }} variant="contained" disabled={isLoading}>Yes</Button>
      </div>
    </OperationsDialog>
  )
}

export default DeleteItemDialog;