/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 24/8/2022
 */

import { Button, IconButton, MenuItem, OutlinedInput, Select, Table, TableBody, TableCell, TableHead, TableRow } from "@mui/material";
import { useFieldArray, useFormContext } from "react-hook-form";
import AddIcon from '@mui/icons-material/Add';
import { Delete } from "@mui/icons-material";

const VariantsCombination = (props) =>  {

    const { from, catVariants, deletedValues, setDeletedValues } = props

    const { register, control, formState: { errors } } = useFormContext();

    const { fields: variantFields, append, remove } = useFieldArray({
        // control,
        name: "variants"
    });

    console.log('fields....', catVariants)
  
    const deleteVariantCombo = (item, index) => {
        if (from === "edit") {
            let variant = item.variantHeaderId
            if(variant !== undefined){
                setDeletedValues([...deletedValues, variant])
            }            
        }  
        remove(index)
    }   

    return (  
        <>
        <Table>
            {(variantFields.length !== 0)?
                (
                <TableHead>
                    {
                    // from==="edit" ? (
                    //     variantFields[0].combo.map((varHead) => {
                    //         return (
                    //             <TableCell align="center" width="20%" >{varHead.variant}</TableCell>
                    //         );
                    //     })
                    // ) : (
                        catVariants?.map((variant) => {
                            return (
                                <TableCell key={variant.id} align="center" width={250} >{variant.variant}</TableCell>
                            );
                        })
                    // )
                    }
                    <TableCell align="center" width="10%" >Quantity</TableCell>
                    <TableCell align="center" width="10%" >Price</TableCell>
                    <TableCell align="center" width="10%" >Discount (%)</TableCell>
                    <TableCell align="center" width="10%">
                        <Button type="button" variant="contained" color="secondary" onClick={() => append({ combo: [], qty: "", price: "", discount: "" })}><AddIcon/></Button>
                    </TableCell>
                </TableHead>
                ):(              
                    <div style={{borderBottom: "none", display: 'flex', justifyContent: 'right'}}>
                        <Button type="button" variant="contained" color="secondary" onClick={() => append({ combo: [], qty: "", price: "", discount: "" })}><AddIcon/></Button>
                    </div>
            )}
            

            <TableBody>
                {variantFields?.map((variant, index) => {
                    return(
                        <>
                            <TableRow key={variant.id}>
                                {from==="edit" ? (
                                    catVariants?.map((catVar, idx) => {
                                        return (
                                            <>
                                            <TableCell align="center" >
                                                {/* <OutlinedInput 
                                                    {...register(`variants.${index}.combo.${idx}.variantId`)}
                                                    value={catVar.id}
                                                    hidden
                                                /> */}
                                                {errors.variants?.[index]?.combo?.[idx]?.valueId && <span style={{color: 'red'}}> * </span>}
                                                <Select 
                                                    // defaultValue="init" 
                                                    defaultValue={variant.combo[idx]?.valueId || "init"}
                                                    size="small" 
                                                    fullWidth 
                                                    {...register(`variants.${index}.combo.${idx}.valueId`)}
                                                >
                                                    <MenuItem value="init">Select {catVar.variant}</MenuItem>
                                                    {catVar.values.map((value) => {
                                                        return(   
                                                            <MenuItem key={value.id} value={value.id}>{value.value}</MenuItem>
                                                        )
                                                    })}
                                                </Select>
                                            </TableCell></>
                                        );
                                    })
                                ) : (
                                    catVariants?.map((catVar, idx) => {
                                        return (
                                            <>
                                            <TableCell align="center" >
                                                {/* <OutlinedInput 
                                                    {...register(`variants.${index}.combo.${idx}.variantId`)}
                                                    value={catVar.id}
                                                    hidden
                                                /> */}
                                                {errors.variants?.[index]?.combo?.[idx]?.valueId && <span style={{color: 'red'}}> * </span>}
                                                <Select 
                                                    defaultValue="init" 
                                                    // defaultValue={variant.combo.valueId}
                                                    size="small" 
                                                    fullWidth 
                                                    {...register(`variants.${index}.combo.${idx}.valueId`)}
                                                >
                                                    <MenuItem value="init">Select {catVar.variant}</MenuItem>
                                                    {catVar.values?.map((value) => {
                                                        return(   
                                                            <MenuItem key={value.id} value={value.id}>{value.value}</MenuItem>
                                                        )
                                                    })}
                                                </Select>
                                            </TableCell></>
                                        );
                                    }) 
                                 )}
                                <TableCell align="center">
                                    {errors.variants?.[index]?.qty && <span style={{color: 'red'}}> * </span>}
                                    <OutlinedInput
                                        {...register(`variants.${index}.qty`)}
                                        placeholder="Quantity"
                                        // defaultValue={variant.catVar}
                                        size="small"
                                    />
                                </TableCell>
                                <TableCell align="center">
                                    {errors.variants?.[index]?.price && <span style={{color: 'red'}}> * </span>}
                                    <OutlinedInput
                                        {...register(`variants.${index}.price`)}
                                        placeholder="Price"
                                        // defaultValue={variant.catVar}
                                        size="small"
                                    />
                                </TableCell>
                                <TableCell align="center">
                                    <OutlinedInput
                                        {...register(`variants.${index}.discount`)}
                                        placeholder="Discount"
                                        // defaultValue={variant.catVar}
                                        size="small"
                                    />
                                </TableCell>
                                <TableCell align="center" >
                                    <IconButton size="small" onClick={() => deleteVariantCombo(variant, index)}>
                                        <Delete />
                                    </IconButton>
                                </TableCell>
                            </TableRow>
                        </>
                    );
                })}
            </TableBody>
            
        </Table></>
    );
}

export default VariantsCombination;