/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 22/8/2022
 */

import { Autocomplete, Backdrop, Button, Chip, CircularProgress, Grid, MenuItem, OutlinedInput, Select, TextField, Typography } from "@mui/material";
import { useFieldArray, useForm, FormProvider } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { closeItemModal, selectItem } from "../../store/slices/itemSlice";
import OperationsDialog from "../shared/operationsDialog";
import styles from '../../styles/util.module.css';
import { toast } from "react-toastify";
import HtmlEditor from "./htmlEditor";
import { useEffect, useMemo, useState } from "react";
import ImageUploader from "./ImageUploader";
import { useGetAllCategoriesQuery, useLazyGetCategoryByIdQuery } from "../../store/services/categoryService";
import { useGetAllBrandsQuery } from "../../store/services/brandService";
import { useGetAllSellersQuery } from "../../store/services/sellerService";
import { useGetOrganizationsQuery } from "../../store/services/orgService";
import { useGetAllPoliciesWithTypeQuery } from "../../store/services/policyService";
import VariantsCombination from "./variantsCombination";
import { useGetItemByIdQuery, useUpdateItemMutation } from "../../store/services/itemService";
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';

const schema = yup.object().shape({
  title: yup.string().required(),
  modelNumber: yup.string().required(),
  overview: yup.string().required(),
  prodCatId: yup.string().required(),
  brandId: yup.string().required(),
  sellerId: yup.string().required(),
  orgId: yup.string().required(),
  returnPolicy: yup.string().required(),
  exchangePolicy: yup.string().required(),
  quantity: yup.string().required(),
  price: yup.string().required(),
  dayToDeliver: yup.string().required(),
  points: yup.string().required(),
  warrantyPeriodMonths: yup.string().required(),
  attributes: yup.array().of(
    yup.object().shape({
      attributeValue: yup.string().required(),
    }).required()
  ),
  variants: yup.array().of(
    yup.object().shape({
      qty: yup.string().required(),
      price: yup.string().required(),
      combo: yup.array().of(
        yup.object().shape({
          valueId: yup.string().required(),
        }).required()
      ).required()
    }).required()
  )
}).required()

const EditItemDialog = () => {

  const item = useSelector(selectItem);
  const dispatch = useDispatch();

  let itemDetails = useMemo(() => {
    return({description: '', prodCatId:''})
  }, []);
  const [open, setOpen] = useState(false);
  const [description, setDescription] = useState(itemDetails.prodDesc);
  const [images, setImages] = useState([]);
  const [attributes, setAttributes] = useState([])
  const [variants, setVariants] = useState([])
  const [deletedValues, setDeletedValues] = useState([])

  const { data, isSuccess, isLoading } = useGetItemByIdQuery(item.selectedItem);
  if(isSuccess){
      console.log('data/////////////',data)
      itemDetails = data;
  }

  const { data: categoryData } = useGetAllCategoriesQuery();
  const categories = categoryData?.list?.map(category => (
    <MenuItem key={category.catId} value={category.catId}>{category.catDisplayName}</MenuItem>
  ));

  const { data: brandData } = useGetAllBrandsQuery();
  const brands = brandData?.list?.map(brand => (
    <MenuItem key={brand.brandId} value={brand.brandId}>{brand.brandName}</MenuItem>
  ));

  const { data: sellerData } = useGetAllSellersQuery();
  const sellers = sellerData?.list?.map(seller => (
    <MenuItem key={seller.sellerId} value={seller.sellerId}>{seller.sellerName}</MenuItem>
  ))

  const { data: orgData } = useGetOrganizationsQuery();
  const orgs = orgData?.list?.map(org => (
    <MenuItem key={org.orgId} value={org.orgId}>{org.orgName}</MenuItem>
  ));

  const { data: policyData } = useGetAllPoliciesWithTypeQuery();
  const returnPolicy = policyData?.returnPolicy?.map(pol => (
    <MenuItem key={pol.policyId} value={pol.policyId}>{pol.policy}</MenuItem>
  ));
  const exchangePolicy = policyData?.exchange?.map(pol => (
    <MenuItem key={pol.policyId} value={pol.policyId}>{pol.policy}</MenuItem>
  ));

  const [getCatById] = useLazyGetCategoryByIdQuery();

  const methods = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      title: itemDetails.title,
      // prodCatId: itemDetails.prodCatId,
      // brandId: itemDetails.brandId,
      // sellerId: itemDetails.sellerId,
      // orgId: itemDetails.orgId,
      overview: itemDetails.overview,
      modelNumber: itemDetails.modelNumber,
      quantity: itemDetails.quantity,
      price: itemDetails.price,
      discount: itemDetails.discount,
      dayToDeliver: itemDetails.dayToDelivery,
      points: itemDetails.points,
      warrantyPeriodMonths: itemDetails.warrantyPeriodMonths,
      returnPolicy: itemDetails.returnPolicy,
      exchangePolicy: itemDetails.exchangePolicy,
      attributes: itemDetails.attributes,
      variants:itemDetails.variants,
      // keywordArray: itemDetails.keywords?.split(","),
    }
  });

  const register = methods.register;
  const control = methods.control;


  const { fields: attributFields, replace: replaceAttributes } = useFieldArray({
    control,
    name: "attributes",
  });

  const handleSetVariants = (catData) => {
    let selectedVars = []
    catData?.variants.map((variant) => {
      let valuesArr = [];
      variant.variantValues?.map((val) => {
        valuesArr = [...valuesArr, {value: val.variantValue, id: val.variantValId}]
      })  
        selectedVars = [...selectedVars, {
          id: variant.variantId, 
          variant: variant.catVar, 
          values: valuesArr,
        }]
    })    
    // replaceVariants(selectedVars);
    if(selectedVars.length!== 0){
      // setViewVar(true)
      // console.log(selectedVars)
      setVariants(selectedVars)
    }
    // console.log("selected........", variants)
  }

  useEffect(() => {
    const handleFetchData = async () => {
      const catDetails = await getCatById(itemDetails.prodCatId)
      const catData = await catDetails.data?.category

      handleSetVariants(catData)
      setDescription(itemDetails.prodDesc)
    }
    if(itemDetails.prodCatId){
        // console.log(category)
        handleFetchData(itemDetails.prodCatId)                     
    }        
}, [getCatById, itemDetails])

  const handleCategoryChange = async (e) => {
    methods.setValue('prodCatId', e.target.value, { shouldValidate: true })
    methods.reset({variants: []});

    const catDetails = await getCatById(e.target.value)
    const catData = await catDetails.data.category

    // set attributes
    let selectedAttrs = []
    catData.attributes.map((attr) => { 
      selectedAttrs = [...selectedAttrs, {
        // id: attr.attributeIndex, 
        attributeValueId: attr.attributeId, 
        // categoryAttributesId: attr.attributeId,
        attributeName: attr.attributeName
      }]
    })
    replaceAttributes(selectedAttrs);
    if(selectedAttrs.length!== 0){
      setAttributes(selectedAttrs)
    }    
    
    // set variants
    handleSetVariants(catData)
    // console.log(selectedAttrs);
    // console.log(selectedVars);
  }

  const handleClose = () => {
    methods.reset();
    dispatch(closeItemModal());
    setDescription('');
    setImages([]);
    setVariants([])
    setDeletedValues([])
  }

  useEffect(() => {
    methods.reset({
      title: itemDetails.title,
      // prodCatId: itemDetails.prodCatId,
      // brandId: itemDetails.brandId,
      // sellerId: itemDetails.sellerId,
      // orgId: itemDetails.orgId,
      overview: itemDetails.overview,
      modelNumber: itemDetails.modelNumber,
      quantity: itemDetails.quantity,
      price: itemDetails.price,
      discount: itemDetails.discount,
      dayToDeliver: itemDetails.dayToDelivery,
      points: itemDetails.points,
      warrantyPeriodMonths: itemDetails.warrantyPeriodMonths,
      returnPolicy: itemDetails.returnPolicy,
      exchangePolicy: itemDetails.exchangePolicy,
      attributes: itemDetails.attributes,
      variants:itemDetails.variants,
      // keywordArray: itemDetails.keywords?.split(","),
    });
}, [itemDetails, methods]);

  const [ updateItem ] = useUpdateItemMutation();

  const onItemSubmit = async (data) => {
    const key = data.keywordArray?.length == 0 ? "" : data.keywordArray?.toString()
    const dataSet = {
      prodDefId: itemDetails.prodDefId,
      ...data,      
      prodDesc: description,
      keywords: key,
      imageList: "",
      deleted: {
        variantHeaders: deletedValues,
      }
    }
    console.log('item form data: ', dataSet)
    console.log('item form data: ', JSON.stringify(dataSet))
    try {
      const updatedItem = await updateItem(dataSet).unwrap();
      console.log('add item', updatedItem)
      toast.success("Item successfully updated!");
    } catch (err) {
      console.error('Failed to save the item: ', err)
      toast.error("Erorr, something went wrong!");
    }
    handleClose();
  }

  return (  
    <OperationsDialog open={item.modalStatus === "edit"} onClose={handleClose} maxWidth="xl">
      <Typography my={3} variant="h5" textAlign="center" fontWeight="bold">
        Edit Item Details
      </Typography>

      {isLoading && (
          <Backdrop
              sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
              open={isLoading}
          >
              <CircularProgress color="inherit" />
          </Backdrop>
      )}

      <FormProvider {...methods}>
        <form onSubmit={methods.handleSubmit(onItemSubmit)}>
          <Grid container columnSpacing={2} rowSpacing={1}>
            <Grid item xs={12} md={6}>
              <label className={styles.formLabel}>Title:</label>
              {methods.formState.errors.title && methods.formState.errors.title.type === "required" && <span style={{color: 'red'}}> *</span>}
              <OutlinedInput {...register("title")} size="small" fullWidth defaultValue={itemDetails.title} className={styles.formText} placeholder="Enter Title" />
            </Grid>
            <Grid item xs={12} md={6}>
              <label className={styles.formLabel}>Model Number:</label>
              {methods.formState.errors.modelNumber && methods.formState.errors.modelNumber.type === "required" && <span style={{color: 'red'}}> *</span>}
              <OutlinedInput {...register("modelNumber")} size="small" fullWidth className={styles.formText} placeholder="Enter Model Number" />
            </Grid>
            <Grid item xs={12} md={6}>
              <label className={styles.formLabel}>Overview:</label>
              {methods.formState.errors.overview && methods.formState.errors.overview.type === "required" && <span style={{color: 'red'}}> *</span>}
              <OutlinedInput {...register("overview")} style={{marginBottom: '10px'}} size="small" fullWidth className={styles.formText} multiline rows={5} placeholder="Enter Overview"/>
              <label className={styles.formLabel}>Description:</label>
              <OutlinedInput size="small" fullWidth className={styles.formText} defaultValue={description} value={description} multiline rows={4} />
              <div style={{ marginTop: "0.5rem", display: 'flex', justifyContent: 'right' }}>
                <Button color="secondary" variant="contained" onClick={() => setOpen(true)}>Add HTML Description</Button>
                <HtmlEditor from="edit" open={open} setOpen={setOpen} description={description} setDescription={setDescription} />
              </div>            
            </Grid>
            <Grid item xs={12} md={6}>
              
              <label className={styles.formLabel}>Images:</label>
              <ImageUploader images={images} setImages={setImages} />
            </Grid>
          {!isLoading && (
            <>
            <Grid item xs={12} md={6}>
              <label className={styles.formLabel}>Category:</label>
              {methods.formState.errors.prodCatId && methods.formState.errors.prodCatId.type === "required" && <span style={{color: 'red'}}> *</span>}
              <Select defaultValue={itemDetails.prodCatId} {...register("prodCatId", { onChange: handleCategoryChange })} size="small" fullWidth className={styles.formText}>
                {categories}
              </Select>
            </Grid>
            <Grid item xs={12} md={6}>
              <label className={styles.formLabel}>Brand:</label>
              {methods.formState.errors.brandId && methods.formState.errors.brandId.type === "required" && <span style={{color: 'red'}}> *</span>}
              <Select defaultValue={itemDetails.brandId} {...register("brandId")} size="small" fullWidth className={styles.formText}>
                {brands}
              </Select>
            </Grid>
            <Grid item xs={12} md={6}>
              <label className={styles.formLabel}>Seller:</label>
              {methods.formState.errors.sellerId && methods.formState.errors.sellerId.type === "required" && <span style={{color: 'red'}}> *</span>}
              <Select defaultValue={itemDetails.sellerId} {...register("sellerId")} size="small" fullWidth className={styles.formText}>
                {sellers}
              </Select>
            </Grid>
            <Grid item xs={12} md={6}>
              <label className={styles.formLabel}>Organization:</label>
              {methods.formState.errors.orgId && methods.formState.errors.orgId.type === "required" && <span style={{color: 'red'}}> *</span>}
              <Select defaultValue={itemDetails.orgId} {...register("orgId")} size="small" fullWidth className={styles.formText}>
                {orgs}
              </Select>
            </Grid>
            <Grid item xs={12} md={6}>
              <label className={styles.formLabel}>Return Policy:</label>
              {methods.formState.errors.returnPolicy && methods.formState.errors.returnPolicy.type === "required" && <span style={{color: 'red'}}> *</span>}
              <Select defaultValue={itemDetails.returnPolicy} {...register("returnPolicy")} size="small" fullWidth className={styles.formText}>
                {returnPolicy}
              </Select>
            </Grid>
            <Grid item xs={12} md={6}>
              <label className={styles.formLabel}>Exchange Policy:</label>
              {methods.formState.errors.exchangePolicy && methods.formState.errors.exchangePolicy.type === "required" && <span style={{color: 'red'}}> *</span>}
              <Select defaultValue={itemDetails.exchangePolicy} {...register("exchangePolicy")} size="small" fullWidth className={styles.formText}>
                {exchangePolicy}
              </Select>
            </Grid>
            </>)}
            <Grid item xs={12} md={4}>
              <label className={styles.formLabel}>Quantity:</label>
              {methods.formState.errors.quantity && methods.formState.errors.quantity.type === "required" && <span style={{color: 'red'}}> *</span>}
              <OutlinedInput {...register("quantity")} size="small" fullWidth className={styles.formText} placeholder="Enter Quantity"/>
            </Grid>
            <Grid item xs={12} md={4}>
              <label className={styles.formLabel}>Price:</label>
              {methods.formState.errors.price && methods.formState.errors.price.type === "required" && <span style={{color: 'red'}}> *</span>}
              <OutlinedInput {...register("price")} size="small" fullWidth className={styles.formText} placeholder="Enter Price" />
            </Grid>
            <Grid item xs={12} md={4}>
              <label className={styles.formLabel}>Discount (%):</label>
              <OutlinedInput {...register("discount")} size="small" fullWidth className={styles.formText} placeholder="Enter Discount" />
            </Grid>
            <Grid item xs={12} md={4}>
              <label className={styles.formLabel}>Days to deliver:</label>
              {methods.formState.errors.dayToDeliver && methods.formState.errors.dayToDeliver.type === "required" && <span style={{color: 'red'}}> *</span>}
              <OutlinedInput {...register("dayToDeliver")} size="small" fullWidth className={styles.formText} placeholder="Enter Days to deliver" />
            </Grid>
            <Grid item xs={12} md={4}>
              <label className={styles.formLabel}>Points:</label>
              {methods.formState.errors.points && methods.formState.errors.points.type === "required" && <span style={{color: 'red'}}> *</span>}
              <OutlinedInput {...register("points")} size="small" fullWidth className={styles.formText} placeholder="Enter Points" />
            </Grid>
            <Grid item xs={12} md={4}>
              <label className={styles.formLabel}>Warranty Period (Months):</label>
              {methods.formState.errors.warrantyPeriodMonths && methods.formState.errors.warrantyPeriodMonths.type === "required" && <span style={{color: 'red'}}> *</span>}
              <OutlinedInput {...register("warrantyPeriodMonths")} size="small" fullWidth className={styles.formText}  placeholder="Enter Warranty period"/>
            </Grid>
            {!isLoading && (
            <Grid item xs={12}>
              <label className={styles.formLabel}>Keywords:</label>
              {/* <OutlinedInput {...register("keywords")} size="small" fullWidth className={styles.formText} /> */}
              <Autocomplete
                defaultValue={itemDetails.keywords == "" ? "" : itemDetails.keywords?.split(",")}
                onChange={(_, newKeyword) => {
                  methods.setValue("keywordArray", newKeyword);
                }}
                size="small"
                placeholder="Enter Keywords"
                multiple
                options={[]}
                freeSolo
                renderTags={(value, getTagProps) =>
                  value.map((option, index) => (
                    <Chip key={option} size="small" variant="outlined" label={option} {...getTagProps({ index })} />
                  ))
                }
                renderInput={(params) => (
                  <TextField
                    {...params}
                  />
                )}
              />
            </Grid>
            )}
            <Grid item xs={12} md={6}>          
              <fieldset>
                <legend>Attributes</legend>
                {attributFields.map((field, index) => (
                  <div key={field.id} style={{ display: "flex", gap: "2rem", marginBlock: "1rem", justifyContent: "space-between" }}>
                    <Typography fontWeight="bold">{field.attributeName || attributes[index].attributeName}:</Typography>
                    {methods.formState.errors.attributes?.[index]?.attributeValue && <span style={{color: 'red'}}> * </span>}
                    <OutlinedInput {...register(`attributes.${index}.attributeValue`)} size="small" fullWidth style={{ flexBasis: "60%" }} />
                  </div>
                ))}
              </fieldset>
            </Grid>
          </Grid>
          <fieldset className={styles.formItem}>
            <legend>Variants</legend>
            <VariantsCombination from="edit" catVariants={variants} deletedValues={deletedValues} setDeletedValues={setDeletedValues} />
          </fieldset>
          <div style={{ marginTop: "2rem", marginBottom: '1rem', display: 'flex', justifyContent: 'center' }}>
            <Button variant="contained" style={{width: "10rem"}} type="submit">Save</Button>
          </div>
        </form>
      </FormProvider>

    </OperationsDialog>
  );
}

export default EditItemDialog;
