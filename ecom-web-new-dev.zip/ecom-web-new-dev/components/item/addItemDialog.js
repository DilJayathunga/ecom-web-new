import { closeItemModal, selectItem } from "../../store/slices/itemSlice";
import OperationsDialog from "../shared/operationsDialog";
import { useSelector, useDispatch } from 'react-redux';
import { Button, Grid, MenuItem, Select, Typography, OutlinedInput, Chip, Autocomplete, TextField, FormControl, InputLabel } from "@mui/material";
import styles from '../../styles/util.module.css';
import { useForm, useFieldArray, FormProvider } from 'react-hook-form';
import { useGetAllCategoriesQuery, useLazyGetCategoryByIdQuery } from "../../store/services/categoryService";
import { useGetOrganizationsQuery } from "../../store/services/orgService";
import { useGetAllBrandsQuery } from "../../store/services/brandService";
import { useGetAllSellersQuery } from "../../store/services/sellerService";
import HtmlEditor from "./htmlEditor";
import { useState } from "react";
import ImageUploader from "./ImageUploader";
import { toast } from "react-toastify";
import { useGetAllPoliciesWithTypeQuery } from "../../store/services/policyService";
import VariantsCombination from "./variantsCombination";
import { useCreateItemMutation } from "../../store/services/itemService";
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';

const schema = yup.object().shape({
  title: yup.string().required(),
  modelNumber: yup.string().required(),
  overview: yup.string().required(),
  prodCatId: yup.string().required(),
  brandId: yup.string().required(),
  sellerId: yup.string().required(),
  orgId: yup.string().required(),
  returnPolicy: yup.string().required(),
  exchangePolicy: yup.string().required(),
  quantity: yup.string().required(),
  price: yup.string().required(),
  dayToDeliver: yup.string().required(),
  points: yup.string().required(),
  warrantyPeriodMonths: yup.string().required(),
  attributes: yup.array().of(
    yup.object().shape({
      attributeValue: yup.string().required(),
    }).required()
  ),
  variants: yup.array().of(
    yup.object().shape({
      qty: yup.string().required(),
      price: yup.string().required(),
      combo: yup.array().of(
        yup.object().shape({
          valueId: yup.string().required(),
        }).required()
      ).required()
    }).required()
  )
}).required()

const AddItemDialog = () => {
  const item = useSelector(selectItem);
  const dispatch = useDispatch();

  const [open, setOpen] = useState(false);
  const [description, setDescription] = useState();
  const [images, setImages] = useState([]);
  const [viewAttr, setViewAttr] = useState(false)
  const [viewVar, setViewVar] = useState(false)
  const [attributes, setAttributes] = useState([])
  const [variants, setVariants] = useState([])
  
  const { data: categoryData } = useGetAllCategoriesQuery();
  const categories = categoryData?.list?.map(category => (
    <MenuItem key={category.catId} value={category.catId}>{category.catDisplayName}</MenuItem>
  ));

  const { data: brandData } = useGetAllBrandsQuery();
  const brands = brandData?.list?.map(brand => (
    <MenuItem key={brand.brandId} value={brand.brandId}>{brand.brandName}</MenuItem>
  ));

  const { data: sellerData } = useGetAllSellersQuery();
  const sellers = sellerData?.list?.map(seller => (
    <MenuItem key={seller.sellerId} value={seller.sellerId}>{seller.sellerName}</MenuItem>
  ))

  const { data: orgData } = useGetOrganizationsQuery();
  const orgs = orgData?.list?.map(org => (
    <MenuItem key={org.orgId} value={org.orgId}>{org.orgName}</MenuItem>
  ));

  const { data: policyData } = useGetAllPoliciesWithTypeQuery();
  const returnPolicy = policyData?.returnPolicy?.map(pol => (
    <MenuItem key={pol.policyId} value={pol.policyId}>{pol.policy}</MenuItem>
  ));
  const exchangePolicy = policyData?.exchange?.map(pol => (
    <MenuItem key={pol.policyId} value={pol.policyId}>{pol.policy}</MenuItem>
  ));

  const [getCatById] = useLazyGetCategoryByIdQuery();

  const methods = useForm({
    mode: "onChange",
    resolver: yupResolver(schema),
  });

  const register = methods.register;
  const control = methods.control;


  const { fields: attributFields, replace: replaceAttributes } = useFieldArray({
    control,
    name: "attributes",
  });

  const handleCategoryChange = async (e) => {

    // methods.reset({variants});

    const catDetails = await getCatById(e.target.value)
    const catData = await catDetails.data.category

    // set attributes
    let selectedAttrs = []
    catData.attributes.map((attr) => { 
      selectedAttrs = [...selectedAttrs, {
        attributeValueId: attr.attributeId, 
        attributeName: attr.attributeName
      }]
    })
    // console.log('attrrrrrrrrr',catData.attributes)
    replaceAttributes(selectedAttrs);
    if(selectedAttrs.length!== 0){
      setViewAttr(true)
      setAttributes(selectedAttrs)
    }    
    
    // set variants
    let selectedVars = []
    catData.variants.map((variant) => {
      let valuesArr = [];
      variant.variantValues?.map((val) => {
        valuesArr = [...valuesArr, {value: val.variantValue, id: val.variantValId}]
      })  
      selectedVars = [...selectedVars, {
        id: variant.variantId, 
        variant: variant.catVar, 
        values: valuesArr,
      }]
    })    
    // replaceVariants(selectedVars);
    if(selectedVars.length!== 0){
      setViewVar(true)
      setVariants(selectedVars)
    }
    // console.log(selectedAttrs);
    // console.log(selectedVars);
  }

  const handleClose = () => {
    methods.reset();
    dispatch(closeItemModal());
    setDescription('');
    setImages([]);
    setViewAttr(false);
    setViewVar(false)
  }

  const [ createItem ] = useCreateItemMutation();

  const onItemSubmit = async (data) => {
    const key = data.keywordArray.length == 0 ? "" : data.keywordArray.toString()
    const dataSet = {
      ...data,      
      prodDesc: description,
      imageList: "",
      keywords: key,
    }
    console.log('item form data: ', JSON.stringify(dataSet))
    console.log('item form data: ', dataSet)
    try {
        const addItem = await createItem(dataSet).unwrap();
        console.log('add item', addItem)
        toast.success("Item successfully added!");
    } catch (err) {
        console.error('Failed to save the item: ', err)
        toast.error("Erorr, something went wrong!");
    }
    handleClose();
}
console.log(methods.getValues('sellerId'))
  return (
    <OperationsDialog open={item.modalStatus === "add"} onClose={handleClose} maxWidth="xl">
      <Typography my={3} variant="h5" textAlign="center" fontWeight="bold">
        Item Creation
      </Typography>

      <FormProvider {...methods}>
        <form onSubmit={methods.handleSubmit(onItemSubmit)}>
          <Grid container columnSpacing={2} rowSpacing={1}>
            <Grid item xs={12} md={6}>
              <label className={styles.formLabel}>Title:</label>
              {methods.formState.errors.title && methods.formState.errors.title.type === "required" && <span style={{color: 'red'}}> *</span>}
              <OutlinedInput {...register("title")} size="small" fullWidth className={styles.formText} placeholder="Enter Title" />
            </Grid>
            <Grid item xs={12} md={6}>
              <label className={styles.formLabel}>Model Number:</label>
              {methods.formState.errors.modelNumber && methods.formState.errors.modelNumber.type === "required" && <span style={{color: 'red'}}> *</span>}
              <OutlinedInput {...register("modelNumber")} size="small" fullWidth className={styles.formText} placeholder="Enter Model Number" />
            </Grid>
            <Grid item xs={12} md={6}>
              <label className={styles.formLabel}>Overview:</label>
              {methods.formState.errors.overview && methods.formState.errors.overview.type === "required" && <span style={{color: 'red'}}> *</span>}
              <OutlinedInput {...register("overview")} style={{marginBottom: '10px'}} size="small" fullWidth className={styles.formText} multiline rows={5} placeholder="Enter Overview"/>
              <label className={styles.formLabel}>Description:</label>
              <OutlinedInput size="small" fullWidth className={styles.formText} value={description} multiline rows={4}  placeholder="Enter Description"/>
              <div style={{ marginTop: "0.5rem", display: 'flex', justifyContent: 'right' }}>
                <Button color="secondary" variant="contained" onClick={() => setOpen(true)}>Add HTML Description</Button>
                <HtmlEditor open={open} setOpen={setOpen} description={description} setDescription={setDescription} />
              </div>            
            </Grid>
            <Grid item xs={12} md={6}>
              
              <label className={styles.formLabel}>Images:</label>
              <ImageUploader images={images} setImages={setImages} />
            </Grid>
            <Grid item xs={12} md={6}>
              <label className={styles.formLabel}>Category:</label>
              {methods.formState.errors.prodCatId && methods.formState.errors.prodCatId.type === "required" && <span style={{color: 'red'}}> *</span>}
              <Select defaultValue="init" {...register("prodCatId", { onChange: handleCategoryChange })} size="small" fullWidth className={styles.formText}>
                <MenuItem value="init" disabled>Select a Category</MenuItem>
                {categories}
              </Select>
            </Grid>
            <Grid item xs={12} md={6}>
              <div>
              <label className={styles.formLabel}>Brand:</label>
              {methods.formState.errors.brandId && methods.formState.errors.brandId.type === "required" && <span style={{color: 'red'}}> *</span>}
              <FormControl fullWidth>
                {/* {methods.getValues('brandId')!== undefined ? <InputLabel> </InputLabel> : <InputLabel shrink={false}>Select a Brand</InputLabel>} */}
              <InputLabel shrink={false}>{(methods.getValues('brandId')) !== undefined ? '' : 'Select a Brand' }</InputLabel>
              <Select 
                onChange={(e) => methods.setValue('brandId', e.target.value, { shouldValidate: true })}
                // defaultValue="null" 
                defaultValue="" 
                {...register("brandId")} size="small" fullWidth className={styles.formText}>
                {/* <MenuItem value="null" disabled>Select a Brand</MenuItem> */}
                {brands}
              </Select>
              </FormControl></div>
            </Grid>
            <Grid item xs={12} md={6}>
              <label className={styles.formLabel}>Seller:</label>
              {methods.formState.errors.sellerId && methods.formState.errors.sellerId.type === "required" && <span style={{color: 'red'}}> *</span>}
              <Select defaultValue="init" {...register("sellerId")} size="small" fullWidth className={styles.formText}>
                <MenuItem value="init" disabled>Select a Seller</MenuItem>
                {sellers}
              </Select>
            </Grid>
            <Grid item xs={12} md={6}>
              <label className={styles.formLabel}>Organization:</label>
              {methods.formState.errors.orgId && methods.formState.errors.orgId.type === "required" && <span style={{color: 'red'}}> *</span>}
              <Select defaultValue="init" {...register("orgId")} size="small" fullWidth className={styles.formText}>
                <MenuItem value="init" disabled>Select an Organization</MenuItem>
                {orgs}
              </Select>
            </Grid>
            <Grid item xs={12} md={6}>
              <label className={styles.formLabel}>Return Policy:</label>
              {methods.formState.errors.returnPolicy && methods.formState.errors.returnPolicy.type === "required" && <span style={{color: 'red'}}> *</span>}
              <Select defaultValue="init" {...register("returnPolicy")} size="small" fullWidth className={styles.formText}>
                <MenuItem value="init" disabled>Select a return policy</MenuItem>
                {returnPolicy}
              </Select>
            </Grid>
            <Grid item xs={12} md={6}>
              <label className={styles.formLabel}>Exchange Policy:</label>
              {methods.formState.errors.exchangePolicy && methods.formState.errors.exchangePolicy.type === "required" && <span style={{color: 'red'}}> *</span>}
              <Select defaultValue="init" {...register("exchangePolicy")} size="small" fullWidth className={styles.formText}>
                <MenuItem value="init" disabled>Select an exchange policy</MenuItem>
                {exchangePolicy}
              </Select>
            </Grid>
            <Grid item xs={12} md={4}>
              <label className={styles.formLabel}>Quantity:</label>
              {methods.formState.errors.quantity && methods.formState.errors.quantity.type === "required" && <span style={{color: 'red'}}> *</span>}
              <OutlinedInput {...register("quantity")} size="small" fullWidth className={styles.formText} placeholder="Enter Quantity"/>
            </Grid>
            <Grid item xs={12} md={4}>
              <label className={styles.formLabel}>Price:</label>
              {methods.formState.errors.price && methods.formState.errors.price.type === "required" && <span style={{color: 'red'}}> *</span>}
              <OutlinedInput {...register("price")} size="small" fullWidth className={styles.formText} placeholder="Enter Price" />
            </Grid>
            <Grid item xs={12} md={4}>
              <label className={styles.formLabel}>Discount (%):</label>
              <OutlinedInput {...register("discount")} size="small" fullWidth className={styles.formText} placeholder="Enter Discount" />
            </Grid>
            <Grid item xs={12} md={4}>
              <label className={styles.formLabel}>Days to deliver:</label>
              {methods.formState.errors.dayToDeliver && methods.formState.errors.dayToDeliver.type === "required" && <span style={{color: 'red'}}> *</span>}
              <OutlinedInput {...register("dayToDeliver")} size="small" fullWidth className={styles.formText} placeholder="Enter Days to deliver" />
            </Grid>
            <Grid item xs={12} md={4}>
              <label className={styles.formLabel}>Points:</label>
              {methods.formState.errors.points && methods.formState.errors.points.type === "required" && <span style={{color: 'red'}}> *</span>}
              <OutlinedInput {...register("points")} size="small" fullWidth className={styles.formText} placeholder="Enter Points" />
            </Grid>
            <Grid item xs={12} md={4}>
              <label className={styles.formLabel}>Warranty Period (Months):</label>
              {methods.formState.errors.warrantyPeriodMonths && methods.formState.errors.warrantyPeriodMonths.type === "required" && <span style={{color: 'red'}}> *</span>}
              <OutlinedInput {...register("warrantyPeriodMonths")} size="small" fullWidth className={styles.formText}  placeholder="Enter Warranty period"/>
            </Grid>
            <Grid item xs={12}>
              <label className={styles.formLabel}>Keywords:</label>
              {/* <OutlinedInput {...register("keywords")} size="small" fullWidth className={styles.formText} /> */}
              <Autocomplete
                onChange={(_, newKeyword) => {
                  methods.setValue("keywordArray", newKeyword);
                }}
                size="small"                
                multiple
                options={[]}
                freeSolo
                renderTags={(value, getTagProps) =>
                  value.map((option, index) => (
                    <Chip key={option} size="small" variant="outlined" label={option} {...getTagProps({ index })} />
                  ))
                }
                renderInput={(params) => (
                  <TextField
                    placeholder="Enter Keywords"
                    {...params}
                  />
                )}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              {viewAttr &&(            
                <fieldset>
                  <legend>Attributes</legend>
                  {attributFields.map((field, index) => (
                    <div key={field.id} style={{ display: "flex", gap: "2rem", marginBlock: "1rem", justifyContent: "space-between" }}>
                      <Typography fontWeight="bold">{attributes[index].attributeName}:</Typography>
                      {methods.formState.errors.attributes?.[index]?.attributeValue && <span style={{color: 'red'}}> * </span>}
                      <OutlinedInput {...register(`attributes.${index}.attributeValue`)} size="small" fullWidth style={{ flexBasis: "60%" }} />
                    </div>
                  ))}
                </fieldset>
              )}
            </Grid>
          </Grid>
          {viewVar &&( 
            <fieldset className={styles.formItem}>
              <legend>Variants</legend>
                <VariantsCombination catVariants={variants} />
            </fieldset>
          )}
          <div style={{ marginTop: "2rem", marginBottom: '1rem', display: 'flex', justifyContent: 'center' }}>
            <Button variant="contained" style={{width: "10rem"}} type="submit">Save</Button>
          </div>
        </form>
      </FormProvider>
    </OperationsDialog>
  )
}

export default AddItemDialog;
