/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 29/8/2022
 */


import { yupResolver } from '@hookform/resolvers/yup';
import { Backdrop, Button, CircularProgress, TextField, Typography } from '@mui/material';
import { useEffect, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import { object, string } from 'yup';
import { useGetBrandByIdQuery, useUpdateBrandMutation } from '../../store/services/brandService';
import { openBrandForm } from '../../store/slices/brandSlice';
import styles from '../../styles/util.module.css';

const schema = object().shape({
  brandName: string().required(),
});

const EditBrand = () => {

    const dispatch = useDispatch();
    const brand = useSelector((state) => state.brand);

    let brandData = useMemo(() => {
        return({brandName: ''})
    }, []);  

    const { register, handleSubmit, reset, formState: { errors } } = useForm({

        resolver: yupResolver(schema),
    });

    const { data, isSuccess, isLoading } = useGetBrandByIdQuery(brand.selectedBrand);
    if(isSuccess){
        brandData = data.list[0];
    }

    useEffect(() => {
        reset({
            brandName: brandData.brandName,
        });
    }, [brandData, reset]);
    
    const [ editBrand ] = useUpdateBrandMutation();

    const submit = async (data) => {
        const dataSet = {
            brandId: brandData.brandId,
            ...data
        }
        try {
            await editBrand(dataSet).unwrap();
            toast.success("Brand successfully updated!");
        } catch (err) {
            console.error(err);
            toast.error("Erorr, something went wrong!");
        } finally {
            dispatch(openBrandForm(false));
        }
    }

    return (
        <>
            <Typography my={3} variant="h5" textAlign="center" fontWeight="bold">
                Update Brand
            </Typography>

            {isLoading && (
                <Backdrop
                    sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
                    open={isLoading}
                >
                    <CircularProgress color="inherit" />
                </Backdrop>
            )}

            <form onSubmit={handleSubmit(submit)}>
                <div className={styles.formItem}>
                    <label className={styles.formLabel}>Name:</label>
                    {errors.brandName && errors.brandName.type === "required" && <span style={{color: 'red'}}> *</span>}
                    <TextField defaultValue={brandData.brandName} {...register("brandName")} size="small" fullWidth className={styles.formText} />

                </div>
                {/* Submit Button */}
                <div style={{ marginTop: "2rem", marginBottom: '1rem', display: 'flex', justifyContent: 'center' }}>
                    <Button type="submit" style={{width: "10rem"}} variant="contained">Update</Button>
                </div>
            </form>
        </>
    )
}

export default EditBrand;