/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 29/8/2022
 */

import { Button, Container, Typography } from "@mui/material";
import { useSelector, useDispatch } from "react-redux";
import { toast } from "react-toastify";
import { openBrandForm } from "../../store/slices/brandSlice";
import { useDeleteBrandMutation } from "../../store/services/brandService";

const DeleteBrand = () => {

    const dispatch = useDispatch();
    const brand = useSelector((state) => state.brand);

    const [deleteBrand, { isLoading }] = useDeleteBrandMutation();

    const onDeleteConfirm = async () => {
        console.log('Deleted...', brand.selectedBrand);
        const id = brand.selectedBrand;
        try {
            const deletedCat = await deleteBrand(id).unwrap();
            console.log('deleted brand', deletedCat)
            toast.success("Brand successfully deleted!");
        } catch (err) {
            console.error('Failed to delete the brand: ', err)
            toast.error("Erorr, something went wrong!");
        }
        dispatch(openBrandForm(false));
    }

    return ( 
        <Container maxWidth="md">

            <Typography my={3} variant="h5" component="div" color="text.primary" textAlign="center" fontWeight="bold">
                Delete Brand?
            </Typography>

            <Typography my={3} component="div" color="text.primary" textAlign="center" fontWeight="400">
                Are you sure you want to delete this brand?
            </Typography>

            <div style={{ display: 'flex', justifyContent: 'center', marginTop: "1rem" }}>
                <Button onClick={() => dispatch(openBrandForm(false))} style={{margin: '0.5rem', width: "10rem"}} fullWidth variant="contained">No</Button>
                <Button onClick={onDeleteConfirm} style={{margin: '0.5rem', width: "10rem"}} fullWidth variant="contained">Yes</Button>
            </div>
        
        </Container>
    );
}

export default DeleteBrand;