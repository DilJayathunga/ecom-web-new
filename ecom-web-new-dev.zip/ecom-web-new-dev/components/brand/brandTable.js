/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 26/8/2022
 */

import { Delete, Edit, Visibility } from "@mui/icons-material";
import { Box, ButtonGroup, IconButton, Pagination, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material";
import { useState } from "react";
import { useDispatch } from "react-redux";
import usePagination from "../../hooks/usePagination";
import { openBrandForm, setSelectedBrand, setStatus } from "../../store/slices/brandSlice";

const BrandTable = ({ brands }) => {
    
    const dispatch = useDispatch();

    let [page, setPage] = useState(1);
    const PER_PAGE = 8;

    const count = Math.ceil(brands.length / PER_PAGE);
    const _DATA = usePagination(brands, PER_PAGE);

    const handleChange = (e, p) => {
        setPage(p);
        _DATA.jump(p);
    }

    // const handleViewClick = (id) => {
    //     dispatch(openBrandForm(true)); 
    //     dispatch(setSelectedBrand(id)); 
    //     dispatch(setStatus('view'))
    // };

    const handleEditClick = (id) => {
        dispatch(openBrandForm(true)); 
        dispatch(setSelectedBrand(id)); 
        dispatch(setStatus('edit'))
    };

    const handleDeleteClick = (id) => {
        dispatch(openBrandForm(true)); 
        dispatch(setSelectedBrand(id)); 
        dispatch(setStatus('delete'))
    };

    return (  
        <>
            <TableContainer sx={{ height: '400px' }}>
                <Table stickyHeader aria-label="simple table" sx={{ height: "max-content" }}>
                    <TableHead>
                        <TableRow>
                            <TableCell width={50}>Brand Number</TableCell>
                            <TableCell width={50}>Brand Name</TableCell>
                            <TableCell align="center" width={'30%'}>Action</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {_DATA.currentData().map((brand) => (
                            <TableRow sx={{ height: '30px' }} key={brand.brandId}>
                                <TableCell component="th" scope="row" sx={{ borderBottom: "none", fontWeight: 'bold', width: 100, height: 'auto !important' }}>
                                    #{brand.brandId}
                                </TableCell>
                                <TableCell sx={{ borderBottom: "none", width: 50, height: 'auto !important' }}>{brand.brandName}</TableCell>
                                <TableCell align="center" sx={{ borderBottom: "none", width: '30%', height: 'auto !important' }}>
                                    <ButtonGroup variant="text" aria-label="text button group">
                                        {/* <IconButton aria-label="view" onClick={() => { handleViewClick(brand.brandId) }}>
                                            <Visibility />
                                        </IconButton> */}
                                        <IconButton aria-label="edit" onClick={() => { handleEditClick(brand.brandId) }}>
                                            <Edit />
                                        </IconButton>
                                        <IconButton aria-label="delete" onClick={() => { handleDeleteClick(brand.brandId) }}>
                                            <Delete />
                                        </IconButton>
                                    </ButtonGroup>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
            <Box my={2} display="flex" justifyContent="center">
                <Pagination
                    count={count}
                    size="large"
                    page={page}
                    variant="outlined"
                    color="primary"
                    onChange={handleChange}
                    style={{ justifyContent: 'center', right: 0 }}
                />
            </Box>
        </>
    );
}

export default BrandTable;