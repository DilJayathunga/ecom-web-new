/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 26/8/2022
 */

import { useDispatch, useSelector } from "react-redux";
import { Dialog, DialogContent } from "@mui/material";
import { openBrandForm } from "../../store/slices/brandSlice";
import AddBrand from "./addBrand";
import EditBrand from "./editBrand";
import DeleteBrand from "./deleteBrand";

const BrandDialog = () => {
    const dispatch = useDispatch();
    const brand = useSelector((state) => state.brand);
    
    let content;
    const deleteView = false
  
    if (brand.status === "add") {
      content = <AddBrand/>;
    // } else if (brand.status === "view") {
    //   content = <ViewBrand/>;
    } else if (brand.status === "edit") {
      content = <EditBrand/>;
    } else if (brand.status === "delete") {
      deleteView = true
      content = <DeleteBrand/>;
    } 
  
    return (
        <>
            <Dialog
                fullWidth={true}
                maxWidth={deleteView ? "xs" : "sm"}
                open={brand.brandPageOpen}
                onClose={() => dispatch(openBrandForm(false))}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogContent>{content}</DialogContent>
            </Dialog>
        </>
    );
};
  
export default BrandDialog;