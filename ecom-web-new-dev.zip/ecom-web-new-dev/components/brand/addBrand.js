/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 26/8/2022
 */

import { yupResolver } from '@hookform/resolvers/yup';
import { Button, TextField, Typography } from '@mui/material';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import * as yup from 'yup';
import { useCreateBrandMutation } from '../../store/services/brandService';
import { openBrandForm } from '../../store/slices/brandSlice';
import styles from '../../styles/util.module.css';

const schema = yup.object().shape({
  brandName: yup.string().required(),
});

const AddBrand = () => {

    const dispatch = useDispatch();

    const { register, handleSubmit, reset, formState: { errors } } = useForm({
        resolver: yupResolver(schema),
    });

    const [createBrand, { isLoading }] = useCreateBrandMutation();

    const submit = async (data) => {
        try {
            await createBrand(data).unwrap();
            toast.success("Brand successfully added!");
        } catch (err) {
            console.error(err);
            toast.error("Erorr, something went wrong!");
        } finally {
            dispatch(openBrandForm(false));
        }
    }

    return (
        <>
            <Typography my={3} variant="h5" textAlign="center" fontWeight="bold">
                Brand Creation
            </Typography>

            <form onSubmit={handleSubmit(submit)}>
                <div className={styles.formItem}>
                    <label className={styles.formLabel}>Name:</label>
                    {errors.brandName && errors.brandName.type === "required" && <span style={{color: 'red'}}> *</span>}
                    <TextField {...register("brandName")} size="small" fullWidth placeholder='Enter brand name' className={styles.formText} />
                </div>
                {/* Submit Button */}
                <div style={{ marginTop: "2rem", marginBottom: '1rem', display: 'flex', justifyContent: 'center' }}>
                    <Button type="submit" style={{width: "10rem"}} variant="contained">Save</Button>
                </div>
            </form>
        </>
    )
}

export default AddBrand;