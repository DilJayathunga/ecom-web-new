import {
  Typography,
  Grid,
  TextField,
  Divider,
  Button,
  Select,
  MenuItem,
} from "@mui/material";
import { useForm } from "react-hook-form";
import { useSelector, useDispatch } from "react-redux";
import { toast } from "react-toastify";

import { useUpdateUserMutation } from "../../store/services/userService";

function EditUser() {
  const item = useSelector((state) => state.user);

  // console.log(item, "item->")
  const { register, handleSubmit } = useForm();

  const [userUpdateResponse] = useUpdateUserMutation();
  console.log(item.selectedUser, "selectedUser");
  const onSubmit = async (data) => {
    const UserDetails = {
      userId: item.selectedUser,
      orgId: 1,
      userProPic: "www.lklkyghg.lk",
      userIncorrectAttempts: 1,
      deleteUserRoleId: [11, 17],
      userRoleId: [1],
      ...data,
    };
    console.log(UserDetails, "userDetails");

    try {
      const updateUser = await userUpdateResponse(UserDetails).unwrap();
      console.log("update user", updateUser);
      toast.success("User successfully update!");
    } catch (err) {
      console.error("Failed to save the user: ", err);
      toast.error("Erorr, something went wrong!");
    }
  };

  return (
    <>
      <Typography
        variant="h6"
        fontWeight={600}
        style={{ textAlign: "center", padding: 10 }}
      >
        {" "}
        Edit User
      </Typography>
      <Grid container>
        <Grid
          xs={10}
          style={{
            padding: "0 40px 0 40px",
            display: "flex",
            justifyContent: "flex-end",
          }}
        >
          <form onSubmit={handleSubmit(onSubmit)}>
            <div>
              {/* first name */}
              <div style={{ padding: "10px 0 10px 0" }}>
                <Typography variant="body1" style={{ fontWeight: 500 }}>
                  First Name
                </Typography>
                <TextField
                  {...register("userFirstName", {
                    required: true,
                    maxLength: 20,
                  })}
                  id="first-name"
                  variant="outlined"
                  size="small"
                  placeholder={`Firest Name`}
                  style={{ width: "500px", backgroundColor: "white" }}
                  backgroundColor="white"
                />
              </div>

              {/* Last name */}
              <div style={{ padding: "10px 0 10px 0" }}>
                <Typography variant="body1" style={{ fontWeight: 500 }}>
                  Last Name
                </Typography>
                <TextField
                  {...register("userLastName", { pattern: /^[A-Za-z]+$/i })}
                  id="first-name"
                  variant="outlined"
                  size="small"
                  placeholder={`Last Name`}
                  style={{ width: "500px", backgroundColor: "white" }}
                  backgroundColor="white"
                />
              </div>

              {/* user name */}
              {/* <div style={{ padding: "10px 0 10px 0" }}>
                <Typography variant="body1" style={{ fontWeight: 500 }}>
                  User Name
                </Typography>
                <TextField
                  {...register("userName", { required: true, maxLength: 20 })}
                  id="first-name"
                  variant="outlined"
                  size="small"
                  placeholder={`User Name`}
                  style={{ width: "500px", backgroundColor: "white" }}
                  backgroundColor="white"
                />
              </div> */}

              <div style={{ padding: "10px 0 10px 0" }}>
                <Typography variant="body1" style={{ fontWeight: 500 }}>
                  Telephone Number
                </Typography>
                <TextField
                  {...register("userTelephone", { length: 10 })}
                  type="number"
                  id="first-name"
                  variant="outlined"
                  size="small"
                  placeholder={`Telephone`}
                  style={{ width: "500px", backgroundColor: "white" }}
                  backgroundColor="white"
                />
              </div>

              {/* Mobile */}
              <div style={{ padding: "10px 0 10px 0" }}>
                <Typography variant="body1" style={{ fontWeight: 500 }}>
                  Mobile Number
                </Typography>
                <TextField
                  {...register("userMobile", { length: 10 })}
                  type="number"
                  id="first-name"
                  variant="outlined"
                  size="small"
                  placeholder={`Mobile`}
                  style={{ width: "500px", backgroundColor: "white" }}
                  backgroundColor="white"
                />
              </div>
              {/* password */}
              <div style={{ padding: "10px 0 10px 0" }}>
                <Typography variant="body1" style={{ fontWeight: 500 }}>
                  Password
                </Typography>
                <TextField
                  {...register("userPsw", { minLength: 8 })}
                  id="first-name"
                  type={"password"}
                  variant="outlined"
                  size="small"
                  placeholder="Enter Password"
                  style={{ width: "500px", backgroundColor: "white" }}
                  backgroundColor="white"
                />
              </div>
              <br />
              <Divider width={500} />

              <div style={{ padding: "10px 0 10px 0" }}>
                <Typography variant="body1" style={{ fontWeight: 500 }}>
                  User Role
                </Typography>

                <Select
                  id="demo-select-small"
                  // value={userRole}
                  // onChange={handleChange}
                  sx={{ minWidth: 500 }}
                  size="small"
                >
                  <MenuItem value="init" disabled>
                    Select Role
                  </MenuItem>
                  {/* {userRoleMenus} */}
                </Select>

                <div
                  style={{
                    margin: "30px 0 30px 0",
                    display: "flex",
                    justifyContent: "center",
                    textAlign: "center",
                  }}
                >
                  <Button
                    type="submit"
                    variant="outlined"
                    style={{
                      margin: "0 10px 0 10px",
                      textTransform: "none",
                      backgroundColor: "green",
                      color: "white",
                    }}
                  >
                    Save
                  </Button>
                </div>
              </div>
            </div>
          </form>
        </Grid>
      </Grid>
    </>
  );
}

export default EditUser;
