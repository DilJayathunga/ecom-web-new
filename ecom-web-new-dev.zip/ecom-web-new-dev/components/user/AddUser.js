import {
  Typography,
  Grid,
  TextField,
  Divider,
  Button,
  MenuItem,
  Select,
} from "@mui/material";
import { useForm } from "react-hook-form";
import { toast } from "react-toastify";

import { useCreateUserMutation } from "../../store/services/userService";

function AddUser() {
  const { register, handleSubmit } = useForm();

  const [createUserResponse] = useCreateUserMutation();

  const onSubmit = async (data) => {
    const UserDetails = {
      data: {
        orgId: 1,
        userProPic: "www.lklk.lk",
        userRoleId: 1,
        ...data,
      },
    };
    console.log(data,"data")
    console.log(UserDetails, " object");

    try {
      const createUserWithBr = await createUserResponse(UserDetails).unwrap();
      console.log("create user", createUserWithBr);
      toast.success("User successfully create!");
    } catch (err) {
      console.error("Failed to save the user: ", err);
      toast.error("Erorr, something went wrong!");
    }
  };
  return (
    <>
      <Typography
        variant="h6"
        fontWeight={600}
        style={{ textAlign: "center", padding: 10 }}
      >
        Add New User
      </Typography>
      <Grid container>
        <Grid
          xs={10}
          spacing={2}
          style={{
            padding: "0 40px ",
            display: "flex",
            justifyContent: "flex-end",
          }}
        >
          <form onSubmit={handleSubmit(onSubmit)}>
            <div style={{ aliganContane: "start", flexWrap: "wrap" }}>

              {/* first name */}
              <div style={{ alignContent: "flex-start" }}>
                <Typography variant="body1" style={{ fontWeight: 500 }}>
                  First Name
                </Typography>
                <TextField
                  {...register("userFirstName", {
                    required: true,
                    maxLength: 20,
                  })}
                  id="first-name"
                  variant="outlined"
                  size="small"
                  placeholder="Enter User ID"
                  style={{ width: "500px", backgroundColor: "white" }}
                  backgroundColor="white"
                />
              </div>

              {/* Last name */}
              <div style={{ padding: "10px 0 10px 0" }}>
                <Typography variant="body1" style={{ fontWeight: 500 }}>
                  Last Name
                </Typography>
                <TextField
                  {...register("userLastName", { pattern: /^[A-Za-z]+$/i })}
                  id="first-name"
                  variant="outlined"
                  size="small"
                  placeholder="Enter User Name"
                  style={{ width: "500px", backgroundColor: "white" }}
                  backgroundColor="white"
                />
              </div>

              {/* user name */}
              <div style={{ padding: "10px 0 10px 0" }}>
                <Typography variant="body1" style={{ fontWeight: 500 }}>
                  User Name
                </Typography>
                <TextField
                  {...register("userName", { required: true, maxLength: 20 })}
                  id="first-name"
                  variant="outlined"
                  size="small"
                  placeholder="Enter User Name"
                  style={{ width: "500px", backgroundColor: "white" }}
                  backgroundColor="white"
                />
              </div>
              {/* userEmail */}
              <div style={{ padding: "10px 0 10px 0" }}>
                <Typography variant="body1" style={{ fontWeight: 500 }}>
                  Email Address
                </Typography>
                <TextField
                  {...register("userEmail")}
                  type="email"
                  id="first-name"
                  variant="outlined"
                  size="small"
                  placeholder="Enter Email Address"
                  style={{ width: "500px", backgroundColor: "white" }}
                  backgroundColor="white"
                />
              </div>

              {/* userTeliphone */}
              <div style={{ padding: "10px 0 10px 0" }}>
                <Typography variant="body1" style={{ fontWeight: 500 }}>
                  Telephone Number
                </Typography>
                <TextField
                  {...register("userTelephone", { length: 10 })}
                  type="number"
                  id="first-name"
                  variant="outlined"
                  size="small"
                  placeholder="Enter Phone Number"
                  style={{ width: "500px", backgroundColor: "white" }}
                  backgroundColor="white"
                />
              </div>

              {/* Mobile */}
              <div style={{ padding: "10px 0 10px 0" }}>
                <Typography variant="body1" style={{ fontWeight: 500 }}>
                  Mobile Number
                </Typography>
                <TextField
                  {...register("userMobile", { length: 10 })}
                  type="number"
                  id="first-name"
                  variant="outlined"
                  size="small"
                  placeholder="Enter Password"
                  style={{ width: "500px", backgroundColor: "white" }}
                  backgroundColor="white"
                />
              </div>
              {/* password */}
              <div style={{ padding: "10px 0 10px 0" }}>
                <Typography variant="body1" style={{ fontWeight: 500 }}>
                  Password
                </Typography>
                <TextField
                  {...register("userPsw", { length: 10 })}
                  type="password"
                  id="password"
                  variant="outlined"
                  size="small"
                  placeholder="Enter Password"
                  style={{ width: "500px", backgroundColor: "white" }}
                  backgroundColor="white"
                />
              </div>
              <br />
              <Divider width={500} />

              <div style={{ padding: "10px 0 10px 0" }}>
                <Typography variant="body1" style={{ fontWeight: 500 }}>
                  User Role
                </Typography>

                <Select
                  id="demo-select-small"
                  // value={userRole}
                  // onChange={handleChange}
                  sx={{ minWidth: 500 }}
                  size="small"
                >
                  <MenuItem value="init" disabled>
                    Select Role
                  </MenuItem>
                  {/* {userRoleMenus} */}
                </Select>
                <div style={{ textAlign: "center" }}>
                  <Button
                    type="submit"
                    variant="outlined"
                    style={{
                      margin: " 20px",
                      textTransform: "none",
                      backgroundColor: "green",
                      color: "white",
                    }}
                  >
                    Save
                  </Button>
                </div>
              </div>
            </div>
          </form>
        </Grid>
      </Grid>
    </>
  );
}

export default AddUser;
