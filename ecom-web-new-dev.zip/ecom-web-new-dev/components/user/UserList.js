import {
  Typography,
  Paper,
  ButtonGroup,
  IconButton,
  Pagination,
  Box,
} from "@mui/material";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import DeleteIcon from "@mui/icons-material/Delete";
import Edit from "@mui/icons-material/Edit";
import Visibility from "@mui/icons-material/Visibility";
import { useState } from "react";

import { useSelector, useDispatch } from "react-redux";
import {
  openUserForm,
  setSelectedUser,
  setStatus,
} from "../../store/slices/userSlice";
import usePagination from "../../hooks/usePagination";

function UserList(searchData) {
  const dispatch = useDispatch();

  let [page, setPage] = useState(1);
  const PER_PAGE = 6;
  let users = searchData.items;
  const count = Math.ceil(users.length / PER_PAGE);
  const _DATA = usePagination(users, PER_PAGE);

  const handleChange = (e, p) => {
    setPage(p);
    _DATA.jump(p);
  };
console.log(users, "users")

  const handleViewClick = (Id) => {
    dispatch(openUserForm(true));
    dispatch(setSelectedUser(Id));
    console.log(Id, "id")
    dispatch(setStatus("viewUser"));
  };

  const handleEditClick = (Id) => {
    dispatch(openUserForm(true));
    dispatch(setSelectedUser(Id));
    dispatch(setStatus("editUser"));
    console.log(Id, "id")
  };

  const handleDeleteClick = (userId) => {
    dispatch(openUserForm(true));
    dispatch(setSelectedUser(userId));
    dispatch(setStatus("deleteUser"));
  };

  return (
    <>
      <Paper>
        {_DATA.currentData().map((item) => (
          <>
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                margin: "5px 0",
                backgroundColor: "#EDEDED",
                boxShadow: "none",
              }}
            >
              <div style={{ display: "flex" }}>
                <AccountCircleIcon
                  sx={{
                    height: 60,
                    width: 60,
                    maxHeight: { xs: 70, md: 80 },
                    maxWidth: { xs: 70, md: 80 },
                  }}
                />
                <div style={{ paddingLeft: 10 }}>
                  <Typography style={{ fontWeight: 600, fontSize: 18 }}>
                    {item.userName}
                  </Typography>
                  <Typography style={{ fontWeight: 400, fontSize: 14 }}>
                    {item.userName}
                  </Typography>
                </div>
              </div>

              <div style={{ padding: "10px 5px 0 0" }}>
                <ButtonGroup variant="text" aria-label="text button group">
                  <IconButton
                    aria-label="view"
                    onClick={() => {
                      handleViewClick(item.userId);
                      console.log(item.userId)
                    }}
                  >
                    <Visibility />
                  </IconButton>
                  <IconButton
                    aria-label="edit"
                    onClick={() => {
                      handleEditClick(item.userId);
                    }}
                  >
                    <Edit />
                  </IconButton>
                  <IconButton
                    aria-label="delete"
                    onClick={() => {
                      handleDeleteClick(item.userId);
                    }}
                  >
                    <DeleteIcon />
                  </IconButton>
                </ButtonGroup>
              </div>
            </div>
          </>
        ))}
      </Paper>
      <Box my={2} display="flex" justifyContent="center">
        <Pagination
          count={count}
          size="smal"
          page={page}
          variant="outlined"
          color="primary"
          onChange={handleChange}
          style={{ justifyContent: "center", right: 0 }}
        />
      </Box>
    </>
  );
}

export default UserList;
