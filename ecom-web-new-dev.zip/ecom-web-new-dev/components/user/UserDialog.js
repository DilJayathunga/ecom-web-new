/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 4/7/2022
 */

import { useDispatch, useSelector } from "react-redux";
import { openUserForm } from "../../store/slices/userSlice";
import { Dialog, DialogContent } from "@mui/material";
import AddUser from "./AddUser";
import ViewUser from "./ViewUser";
import EditUser from "./EditUser";
import DeleteUser from "./DeleteUser";


const UserDialog = () => {
    const dispatch = useDispatch();
    const user = useSelector((state) => state.user);
    
    console.log(user, "user")
    let content;
    const deleteView = false
    
    if (user.status === "addUser") {
      content = <AddUser/>;
    }
     else if (user.status === "viewUser") {
      content = <ViewUser/>;
    } else if (user.status === "editUser") {
      content = <EditUser/>;
    } else if (user.status === "deleteUser") {
      deleteView = true
      content = <DeleteUser/>;
    } 
  
    return (
      <>
        <Dialog
          fullWidth={true}
          maxWidth={deleteView ? "sm" : "md"}
          open={user.UserPageOpen}
          onClose={() => dispatch(openUserForm(false))}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogContent>{content}</DialogContent>
        </Dialog>
      </>
    );
  };
  
  export default UserDialog;