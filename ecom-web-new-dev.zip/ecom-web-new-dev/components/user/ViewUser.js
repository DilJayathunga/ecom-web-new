import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import { TableBody, TableCell, TableRow, Typography } from "@mui/material";
import { useSelector, useDispatch } from "react-redux";
import { useGetUserByIdQuery } from "../../store/services/userService";

function ViewUser() {
  const item = useSelector((state) => state.user.selectedUser);
  console.log(item, "view item-->");

  const { data: userResponse, isSuccess: userSuccess } =
    useGetUserByIdQuery(item);
  console.log(userResponse, "userResponse -->")

  return (
    <>
      {userResponse?.user?.map((item) => (
        <>
          <div>
            <div style={{ textAlign: "center" }}>
              <AccountCircleIcon
                sx={{
                  height: 100,
                  width: 100,
                  maxHeight: { xs: 100, md: 80 },
                  maxWidth: { xs: 100, md: 80 },
                }}
              />
              <Typography fontWeight={700}>{item.userName}</Typography>
              <Typography>{item.userEmail}</Typography>
            </div>
            <>
              <br />
              <div style={{ backgroundColor: "#EDEDED", margin: "40px" }}>
                <TableBody>
                  <TableRow>
                    <TableCell>Name </TableCell>
                    <TableCell>
                      {item.userFirstName} {item.userLastName}
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Mobile number </TableCell>
                    <TableCell>
                      {item.userTelephone}, {item.userMobile}
                     
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>Address </TableCell>
                    <TableCell>
                      <div>address1,</div>
                      <div>address2,</div>
                      <div>address3,</div>
                      <div>address4.</div>
                    </TableCell>
                  </TableRow>
                </TableBody>{" "}
              </div>
            </>
          </div>
        </>
      ))}
    </>
  );
}

export default ViewUser;
