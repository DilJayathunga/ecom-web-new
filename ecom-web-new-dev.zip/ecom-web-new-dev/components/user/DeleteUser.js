/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Sasindu Werapitiya
 * @Date 12/05/2022
 */
import { Typography, Button, Container } from "@mui/material";

import { useSelector, useDispatch } from "react-redux";
import { openUserForm } from "../../store/slices/userSlice";

import { useDeleteUserMutation } from "../../store/services/userService";

function DeleteUser(userId) {
  const [useDeleteResponse] = useDeleteUserMutation();

  const dispatch = useDispatch();
  const user = useSelector((state) => state.user);
  console.log(userId);

  const onDeleteConfirm = async () => {
    console.log("Deleted...", user.selectedCategory);
    const id = category.selectedCategory;
    // try {
    //   const deletedCat = await useDeleteResponse(id).unwrap();
    //   console.log("deleted item", deletedCat);
    //   toast.success("Category successfully deleted!");
    // } catch (err) {
    //   console.error("Failed to save the item: ", err);
    //   toast.error("Erorr, something went wrong!");
    // }
    // dispatch(openUserForm(false));
  };

  return (
    <>
      <Container maxWidth="md">
        <Typography
          my={3}
          variant="h5"
          component="div"
          color="text.primary"
          textAlign="center"
          fontWeight="bold"
        >
          Delete Post?
        </Typography>

        <Typography
          // className={styles.formLabel}
          my={3}
          component="div"
          color="text.primary"
          textAlign="center"
          fontWeight="400"
        >
          Are you sure you want to delete this user?
        </Typography>

        <div
          // className={styles.formItem}
          style={{ display: "flex", justifyContent: "center" }}
        >
          <Button
            onClick={() => dispatch(openItemForm(false))}
            // className={styles.button}
            style={{ margin: "0.5rem" }}
            // fullWidth={match}
            variant="contained"
          >
            No
          </Button>
          <Button
            onClick={onDeleteConfirm}
            // className={styles.button}
            style={{ margin: "0.5rem" }}
            // fullWidth={match}
            variant="contained"
          >
            Yes
          </Button>
        </div>
      </Container>
    </>
  );
}

export default DeleteUser;
