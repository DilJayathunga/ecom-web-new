/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 17/02/2020
 */

import { CheckBox } from "@mui/icons-material";
import { Box, Button, List, ListItem, ListItemButton, ListItemText, Typography } from "@mui/material";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";


const WebFilterCheckList = (props) => {
  const { filter, submitFilters } = props;

  //get query parameters
  const { query } = useRouter();
  const [checked, setChecked] = useState([]);
  const [showAll, setShowAll] = useState(false);
  const [showList, setShowList] = useState(
    showAll == false ? filter.refValues.slice(0, 5) : filter.refValues
  );

  const handleToggle = (value) => {
    const currentIndex = checked.indexOf(value.id);
    const newChecked = [...checked];

    if (currentIndex === -1) {
      newChecked.push(value.id);
    } else {
      newChecked.splice(currentIndex, 1);
    }
    setChecked(newChecked);
    submitFilters(newChecked);
  };

  const showAllToggle = () => {
    setShowAll((prevState) => !prevState);
  };

  useEffect((filter) => {
    for (let key in query) {
      if (key == `Web${filter.filterName}`) {
        if (Array.isArray(query[key])) {
          const selectedKey = query[key].map(Number);
          setChecked(selectedKey);
        } else {
          setChecked([parseInt(query[key])]);
        }
      }
    }
  }, [query]);

  useEffect((filter) => {
    setShowList(
      showAll == false ? filter.refValues.slice(0, 5) : filter.refValues
    );
  }, [showAll]);

  return (
    <>
      <Typography variant="h5" gutterBottom component="div">
        {filter.filterName}
      </Typography>
      <List
        dense
        sx={{ width: "100%", maxWidth: 360, bgcolor: "background.paper" }}
      >
        {showList == "undefined"
          ? null
          : showList.map((option, index) => {
              const labelId = `checkbox-list-secondary-label-${option.id}`;
              return (
                <ListItem
                  key={index}
                  secondaryAction={
                    <CheckBox
                      edge="end"
                      onChange={() => handleToggle(option)}
                      checked={checked.indexOf(option.id) !== -1}
                      inputProps={{ "aria-labelledby": labelId }}
                    />
                  }
                  disablePadding
                >
                  <ListItemButton onClick={() => handleToggle(option)}>
                    <ListItemText id={labelId} primary={option.displayName} />
                  </ListItemButton>
                </ListItem>
              );
            })}
      </List>

      {filter?.refValues?.length > 5 && (
        <Box>
          {showAll == false ? (
            <Button onClick={showAllToggle}>{"View More"}</Button>
          ) : (
            <Button onClick={showAllToggle}> {"View Less"}</Button>
          )}
        </Box>
      )}
    </>
  );
};
export default WebFilterCheckList;
