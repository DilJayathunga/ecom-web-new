/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 24/02/2020
 */

import { Toolbar } from "@mui/material";
import SortToggle from "./SortToggle";
import ViewToggle from "./ViewToggle";


const SearchTitleBar = (props) => {
  const { viewBy, handleViewBy } = props;

  return (
    <>
      <Toolbar
        style={{
          display: "flex",
          backgroundColor: "#f3f3f3",
          minHeight: 25,
          padding: "0 0",
          position:'unset',
        }}
        sx={{ boxShadow: 1}}
      >
        <div style={{ paddingLeft:50}}>200 items result</div>
        <div style={{ marginLeft: "auto" }}>
          <SortToggle viewBy={viewBy} handleViewBy={handleViewBy} />
        </div>
        <div style={{ marginLeft: "20px" }}>
          <ViewToggle viewBy={viewBy} handleViewBy={handleViewBy} />
        </div>
      </Toolbar>
    </>
  );
};
export default SearchTitleBar;
