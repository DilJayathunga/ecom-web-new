/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 28/7/2022
 */

import WebFilterCheckList from "./WebFilterCheckList";
import WebFilterMinMax from "./WebFilterMinMax";
import WebFilterSingleCheck from "./webFilterSingleCheck";

const WebFilters = (props) => {

    const { webFilters, setQueryPara } = props;
    // console.log('web', webFilters)

    const submitWebFilterMinMax = (filterName, minVal, maxVal) => {
        setQueryPara((prevState) => ({
          ...prevState,
          [`${filterName}Min`]: minVal,
          [`${filterName}Max`]: maxVal,
        }));
    };

    const submitWebFilterSingleCheck = (filterName, val) => {
        setQueryPara((prevState) => ({
          ...prevState,
          [filterName]: val,
        }));
    };

    const submitWebFilterCheckList = (filterName, val) => {
        setQueryPara((prevState) => ({
          ...prevState,
          [`Web${filterName}`]: val,
        }));
    };

    return (  
        <>
            {webFilters &&
            webFilters.map((filter, index) => {
                // console.log("web filter options --- ", filter);
                switch (filter.filterName) {
                case "Price":
                    // console.log('minmax........',filter)
                    return (
                    <WebFilterMinMax
                        key={index}
                        filter={filter}
                        submitFilters={(minVal, maxVal) =>
                        submitWebFilterMinMax(filter.filterName, minVal, maxVal)
                        }
                    />
                    );
                case "Shipping":
                    return (
                    <WebFilterSingleCheck
                        key={index}
                        filter={filter}
                        submitFilters={(val) =>
                        submitWebFilterSingleCheck(filter.filterName, val)
                        }
                    />
                    );

                // case "Category":
                //     return (
                //     <WebFilterCheckList
                //         key={index}
                //         filter={filter}
                //         submitFilters={(val) =>
                //         submitWebFilterCheckList(filter.filterName, val)
                //         }
                //     />
                //     );

                // case "Seller":
                //     return (
                //     <WebFilterCheckList
                //         key={index}
                //         filter={filter}
                //         submitFilters={(val) =>
                //         submitWebFilterCheckList(filter.filterName, val)
                //         }
                //     />
                //     );

                default:
                    // return <p>Other web filters ... !</p>;
                    null
                }
            })}
        </>
    );
}

export default WebFilters;