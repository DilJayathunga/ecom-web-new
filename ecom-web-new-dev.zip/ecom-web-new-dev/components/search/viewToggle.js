/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 24/02/2020
 */

import { Apps, ViewList } from "@mui/icons-material";
import { IconButton } from "@mui/material";


const ViewToggle = (props) => {
  const { viewBy, handleViewBy } = props;

  // const [viewBy, setViewBy] = useState("list");

  const handleShowBy = (viewType) => {
    handleViewBy(viewType);
  };

  return (
    <div style={{ display: "flex", alignItems: "center" }}>
      <div style={{ flex: 2, fontSize:13 }}>View :</div>

      <IconButton
        aria-label="list"
        style={{ flex: 1 }}
        onClick={() => handleShowBy("list")}
      >
        <ViewList
          style={{color: (viewBy == "list") ? '#ff8000' : '#414141'}}
        />
      </IconButton>

      <IconButton
        aria-label="delete"
        style={{ flex: 1 }}
        onClick={() => handleShowBy("grid")}
      >
        <Apps
          style={{color: (viewBy == "grid") ? '#ff8000' : '#414141'}}
        />
      </IconButton>
    </div>
  );
};
export default ViewToggle;
