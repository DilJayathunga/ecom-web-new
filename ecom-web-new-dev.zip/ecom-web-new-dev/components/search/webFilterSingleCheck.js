/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 31/01/2020
 */

import { Checkbox, FormControlLabel, Typography } from "@mui/material";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";

const WebFilterSingleCheck = (props) => {
  const { filter, submitFilters } = props;

  //get query parameters
  const { query } = useRouter();
  const [filterCheck, setFilterCheck] = useState(false);

  const handleFilterCheck = (e) => {
    setFilterCheck(e.target.checked)
    // submitFilters(filterCheck);
  }
  
  useEffect(() => {
    for (let key in query) {
      if (key == filter.filterName) {
        setFilterCheck(query[key] == 'true' ? true : false);
      }
    }
  }, [filter.filterName, query]);

  useEffect(() => {
    submitFilters(filterCheck);
  }, [filterCheck, submitFilters]);

  return (
    <>
      <Typography variant="h5" gutterBottom component="div">
        {filter.filterName}
      </Typography>

      <FormControlLabel
          control={<Checkbox checked={filterCheck}  onChange={(e) => handleFilterCheck(e)} />}
          label= {filter.filterDisplayName}
        />
    </>
  );
};
export default WebFilterSingleCheck;
