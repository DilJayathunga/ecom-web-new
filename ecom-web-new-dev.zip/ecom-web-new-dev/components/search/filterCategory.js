/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 31/01/2020
 */

import { ChevronRight, ExpandMore } from "@mui/icons-material";
import { TreeItem, TreeView } from "@mui/lab";
import { useGetAllCatWithSubCatQuery } from "../../store/services/categoryService";


const FilterCategory = (props) => {
  const { selectCategory } = props;

  const { data: catList, isSuccess: catSuccess} = useGetAllCatWithSubCatQuery();

  // if(catSuccess){
  //    console.log('cat list........',catList)
  // }
 
  const handleSelect = (event, nodeIds) => {
    selectCategory(nodeIds);
  };

  const handleToggle = (event, nodeIds) => {
    // console.log("tree view toggle", nodeIds);
  };

  const renderSubNode = (nodes) => {
    return (
      <TreeItem
        key={nodes.catId}
        nodeId={nodes.catId.toString()}
        label={nodes.catDisplayName}
      >
        {nodes.subCategoryList && Array.isArray(nodes.subCategoryList)
          ? nodes.subCategoryList.map((node) => renderSubNode(node))
          : null}
      </TreeItem>
    );
  };

  return (
    <TreeView
      aria-label="file system navigator"
      defaultCollapseIcon={<ExpandMore />}
      defaultExpandIcon={<ChevronRight />}
      onNodeToggle={handleToggle}
      onNodeSelect={handleSelect}
      sx={{ flexGrow: 1, maxWidth: 400, overflowY: "auto" }}
    >
      {catList?.list[0].map((item, key) => renderSubNode(item, key))}
    </TreeView>
  );
};

export default FilterCategory;
