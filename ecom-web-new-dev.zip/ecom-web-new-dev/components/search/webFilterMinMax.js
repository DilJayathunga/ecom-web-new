/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 31/01/2020
 */

import { TextField, Typography } from "@mui/material";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";



const WebFilterMinMax = (props) => {
  const { filter, submitFilters } = props;

  //get query parameters
  const { query } = useRouter();
  const [minValue, setMinValue] = useState();
  const [maxValue, setMaxValue] = useState();

  const handleChangeMinValue = (e) => {
    const value = e.target.value.replace(/\D/g, "");
    setMinValue(value);
    // submitFilters(minValue ? minValue : 0, maxValue ? maxValue : 0);
  };

  const handleChangeMaxValue = (e) => {
    const value = e.target.value.replace(/\D/g, "");
    setMaxValue(value);
    // submitFilters(minValue ? minValue : 0, maxValue ? maxValue : 0);
  };

  // useEffect(() => {
  //   for (let key in query) {
  //     if (key == `${filter.filterName}Min`) {
  //       setMinValue(query[key]);
  //     }
  //     if (key == `${filter.filterName}Max`) {
  //       setMaxValue(query[key]);
  //     }
  //   }
  // }, [query, filter]);

  useEffect(() => {
    submitFilters(minValue ? minValue : 0, maxValue ? maxValue : 0);
  }, [minValue, maxValue, submitFilters]);

  return (
    <>
      <Typography variant="h5" gutterBottom component="div">
        {filter.filterDisplayName}
      </Typography>

      <div style={{ display: "flex" }}>
        <div style={{ flex: 1 }}>
          <TextField
            id="minVal"
            variant="outlined"
            size="small"
            placeholder="Min"
            value={minValue || ""}
            onChange={(e) => handleChangeMinValue(e)}
          />
        </div>
        <div style={{ flex: 1 }}>
          <TextField
            id="maxVal"
            variant="outlined"
            size="small"
            placeholder="Max"
            value={maxValue || ""}
            onChange={(e) => handleChangeMaxValue(e)}
          />
        </div>
      </div>
    </>
  );
};
export default WebFilterMinMax;
