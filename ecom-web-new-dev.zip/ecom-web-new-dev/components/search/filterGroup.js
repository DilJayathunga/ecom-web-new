/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 31/01/2020
 */

import { Box, Button, Checkbox, List, ListItem, ListItemButton, ListItemText, ListSubheader, Typography } from "@mui/material";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";

const FilterGroup = (props) => {

    const { filter, ckeckedOption } = props;

    const { query } = useRouter();
    const [checked, setChecked] = useState([]);
    const [showAll, setShowAll] = useState(false);
    const [showList, setShowList] = useState(
        showAll == false ? filter.FilterOption.slice(0, 5) : filter.FilterOption
    );
    
    const handleToggle = (value) => {
        console.log("handleToggle - 01", value);
        console.log("handleToggle - 02", checked);
    
        // const currentIndex = checked.findIndex((x) => x.ID === value.ID);
        const currentIndex = checked.indexOf(value.ID);
    
        const newChecked = [...checked];
    
        if (currentIndex === -1) {
            newChecked.push(value.ID);
        } else {
            newChecked.splice(currentIndex, 1);
        }
        setChecked(newChecked);
        ckeckedOption(newChecked);
        console.log('check',checked)
    };
    

    const showAllToggle = () => {
        console.log(" showAllToggle 01 ", showAll);
        setShowAll(!showAll);
        (showAll == false) ? filter.FilterOption.slice(0, 5) : filter.FilterOption
    };
    // console.log('qry...', query)

    useEffect((filter) => {
        for (let key in query) {
            // console.log(key)
            if (key == filter?.FilterName) {
                if (Array.isArray(query[key])) {
                    const selectedKey = query[key].map(Number);
                    // console.log('key',selectedKey)
                    setChecked(selectedKey);
                } else{
                    setChecked([parseInt(query[key])]);
                }
            }
        }
    }, [query]);
    
    useEffect(() => {
        setShowList(
            showAll == false ? filter.FilterOption.slice(0, 5) : filter.FilterOption
        );
    }, [filter, showAll]);

    return (
        <>
            <Typography variant="h5" gutterBottom component="div">
                {filter.FilterName}
            </Typography>

            <List
                dense
                sx={{ width: "100%", maxWidth: 360, bgcolor: "background.paper" }}
                // subheader={<ListSubheader>{filter.FilterName}</ListSubheader>}
            >
                {showList == "undefined"
                    ? null
                    : showList.map((option, index) => {
                        return (
                            <ListItem
                                key={index}
                                secondaryAction={
                                    <Checkbox
                                        edge="end"
                                        onChange={() => handleToggle(option)}
                                        checked={checked.indexOf(option.ID) !== -1}
                                        inputProps={{ "aria-labelledby": option.ID }}
                                    />
                                }
                                disablePadding
                            >
                                <ListItemButton onClick={() => handleToggle(option)}>
                                    <ListItemText id={option.ID} primary={option.Value} />
                                </ListItemButton>
                            </ListItem>
                        );
                    })
                }
            </List>

            {filter.FilterOption.length > 5 && (
                <Box>
                    <Button onClick={showAllToggle}>
                        { showAll == false ? "View More" : "View Less" }
                    </Button>
                </Box>
            )}
        </>
    );
}

export default FilterGroup;