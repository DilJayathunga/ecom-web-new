/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 25/02/2020
 */

import { MenuItem, Select } from "@mui/material";
import Router, { useRouter } from "next/router";
import { useState } from "react";



const SortToggle = (props) => {
  const { viewBy, handleViewBy } = props;
  let { query } = useRouter();

  const sortOptions = [
    { id: "default", name: "Best Match" },
    { id: "orders", name: "Orders" },
    { id: "newest", name: "Newest" },
    { id: "price", name: "Price" },
    { id: "rate", name: "Review Rate" },
  ];

  const sortTypes = [
    { id: "asc", name: "A-Z" },
    { id: "desc", name: "Z-A" },
  ];
  const [queryPara, setQueryPara] = useState({});
  const [sortOption, setSortOption] = useState("default");
  const [sortType, setSortType] = useState("asc");

  const handleChangeSortOption = (event) => {
    setSortOption(event.target.value);

    query = {
      ...query,
      ["sortOption"]: event.target.value,
      ["sortType"]: sortType,
    };

    console.log("change sort option xx", query);
    Router.push({
      pathname: "/search",
      query: query,
    });
  };

  const handleChangeSortType = (event) => {
    setSortType(event.target.value);
    query = {
      ...query,
      ["sortOption"]: sortOption,
      ["sortType"]: event.target.value,
    };

    console.log("change sort option xx", query);
    Router.push({
      pathname: "/search",
      query: query,
    });
  };

  return (
    <div style={{ minWidth: "120px", display: "flex", alignItems: "center" }}>
      <div style={{ flex: 3, fontWeight:'bold',fontSize:12  }}>Sort By :</div>

      <Select
        labelId="select-sort-option"
        id="select-sort-option"
        value={sortOption}
        variant="standard"
        disableUnderline={true}
        onChange={handleChangeSortOption}
        style={{ maxWidth: "200px",fontSize:13 }}
      >
        {sortOptions.map((item) => (
          <MenuItem key={item.id} value={item.id}>
            {item.name}
          </MenuItem>
        ))}
      </Select>

      <Select
        labelId="select-sort-type"
        id="select-sort-type"
        value={sortType}
        variant="standard"
              disableUnderline={true}
        onChange={handleChangeSortType}
        style={{ maxWidth: "200px", fontSize:13, paddingLeft:20 }}
      >
        {sortTypes.map((item) => (
          <MenuItem key={item.id} value={item.id}>
            {item.name}
          </MenuItem>
        ))}
      </Select>
    </div>
  );
};
export default SortToggle;
