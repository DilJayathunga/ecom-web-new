/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 15/02/2020
 */

import { Backdrop, Box, Button, Card, CircularProgress } from "@mui/material";
import { skipToken } from "@reduxjs/toolkit/dist/query";
import Router, { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { useLazyGetFiltersByCategoryQuery, useGetWebFiltersQuery } from "../../store/services/filterService";
import FilterCategory from "./FilterCategory";
import FilterGroup from "./filterGroup";
import WebFilters from "./webFilters";

const FilterPanel = (props) => {

    const { category } = props;
    const { query } = useRouter();

    const [categoryId, setCategoryId] = useState();
    const [queryPara, setQueryPara] = useState({});
    const [catFilters, setCatFilters] = useState([]);

    const {data: webFilters, isSuccess: isWebFilterSuccess, isLoading: isWebFilterLoading} = useGetWebFiltersQuery();
    
    const [fetchCatData,{ isLoading: isCatLoading, isSuccess: isCatSuccess}] = useLazyGetFiltersByCategoryQuery()
    
    useEffect(() => {
        const handleFetchData = async () => {
            const cats = await fetchCatData(category ? category : skipToken);
            await setCatFilters(cats?.data?.list[0])
        }
        if(category){
            // console.log(category)
            handleFetchData(category)                     
        }        
    }, [category, fetchCatData])

    const handleSelectFilterCategory = async (catId) => {
        setCategoryId(catId);
        setQueryPara((prevState) => ({
          ...prevState,
          Category: catId,
        }));
        const cats = await fetchCatData(catId ? catId : skipToken);
        await setCatFilters(cats?.data?.list[0])
    };

    const handleClickSearchFilterBtn = () => {
        let paraObj = {};
    
        for (let key in queryPara) {
          if (queryPara.hasOwnProperty(key)) {
            if (queryPara[key] != 0) {
              paraObj = { ...paraObj, [key]: queryPara[key] };
            }
          }
        }
    
        Router.push({
          pathname: "/search",
          query: paraObj,
        });
    };

    const checkFilterOption = (filterName, val) => {
        setQueryPara((prevState) => ({
          ...prevState,
          [filterName]: val,
        }));
    };

    // useEffect(() => {
    //     setQueryPara(query);
    // }, [query]);

    return (
        <>
            {isCatLoading || isWebFilterLoading && (
                <Backdrop
                    sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
                    open={isCatLoading || isWebFilterLoading}
                >
                    <CircularProgress color="inherit" />
                </Backdrop>
            )}
            <Card style={{
                padding:15,
                marginBottom:10,
                marginLeft:10,
                boxShadow: "rgb(158 158 158) 1px 1px 15px 1px", 
            }}>
                <Box>
                    <FilterCategory selectCategory={(catId) => handleSelectFilterCategory(catId)} />
                    <Button
                        style={{width:'100%', marginLeft:'5px',}}
                        sx={{ mt: "10px" }}
                        variant="outlined"
                        onClick={handleClickSearchFilterBtn}
                    >
                        Search Filter
                    </Button>

                    {/* web filters ----------------- */}
                        {/* {isWebFilterSuccess &&
                        <WebFilters webFilters={webFilters?.list|| []} setQueryPara={setQueryPara} />} */}
                    

                    {/* category filters ---------------- */}
                    {catFilters?.map((filter, index) => (
                        <FilterGroup
                            filter={filter}
                            key={index}
                            ckeckedOption={(valx) => checkFilterOption(filter.FilterName, valx)}
                        />
                    ))}

                    <Button 
                        style={{width:'100%', marginLeft:'5px',}}
                        variant="outlined"
                        onClick={handleClickSearchFilterBtn}
                    >
                        Search Filter
                    </Button>
                </Box>
            </Card>
        </>
    );
}

export default FilterPanel;