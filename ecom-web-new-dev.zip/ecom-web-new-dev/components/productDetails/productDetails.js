/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 20/01/2020
 */

import { Typography } from "@mui/material";
import { countBy } from "lodash";
import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { useAddToCartMutation } from "../../store/services/cartService";
import ButtonSet from "./buttonSet";
import ProductBrands from "./productBrands";
import ProductPricing from "./productPricing";
import ProductRating from "./productRating";
import QuantityPicker from "./quentityPicker";
import VariantPicker from "./variantPicker";
import { useCookies } from "react-cookie"

const ProductDetails = (props) => {

    const {prodDet} = props;

    console.log('proddet...............',prodDet.quantity)

    const [cookies, setCookie] = useCookies(["cartId", "cartItems"])

    const [itemPrice, setItemPrice] = useState(0);
    const [currency, setCurrency] = useState("USD");
    const [discount, setDiscount] = useState();
    const [defaultImg, setDefaultImg] = useState();
    const [selectedVariants, setSelectedVariants] = useState("");
    const [itemStock, setItemStock] = useState();
    const [selectedQty, setSelectedQty] = useState(1)
    const [subTot, setSubTot] = useState();
    const [validationMsg, setValidationMsg] = useState("");
    const [variantCombo, setVariantCombo] = useState([])
    const [variantComboId, setVariantComboId] = useState()
    const [isAllVariantsSelected, setIsAllVariantsSelected] = useState(false)

    useEffect(() => {
      setItemPrice(prodDet.price);
      setDiscount(prodDet.discount);
      setItemStock(prodDet.quantity);
    }, [prodDet])

    console.log('stock',itemStock)

    const handlePickVariant = (variant, variantVal, pickerType) => {
        pickerType == "image" ? setDefaultImg(variantVal) : null;

        setSelectedVariants((prevState) => ({
            ...prevState,
            [variant]: variantVal,
        }));
        setValidationMsg("");
    };

    useEffect(() => {
        var num = Object.keys(selectedVariants).length
        if(num === prodDet.variants?.length){
            setVariantCombo([])
            let combo = []
            for (const [key, value] of Object.entries(selectedVariants)) {
                combo = [...combo, {variant: key, value: value}]
            }
            setVariantCombo(combo)
            setIsAllVariantsSelected(true)            
        }
    }, [selectedVariants, prodDet])

    useEffect(() => {

        let comboQty = prodDet.variantCombo.find(variant => JSON.stringify(variant.combo) == JSON.stringify(variantCombo))?.qty || 0
        let comboPrice = prodDet.variantCombo.find(variant => JSON.stringify(variant.combo) == JSON.stringify(variantCombo))?.price
        let comboDiscount = prodDet.variantCombo.find(variant => JSON.stringify(variant.combo) == JSON.stringify(variantCombo))?.discount
        let variantHeader = prodDet.variantCombo.find(variant => JSON.stringify(variant.combo) == JSON.stringify(variantCombo))?.variantHeaderId

        if(comboQty!= 0){
            setItemStock(comboQty)
            setItemPrice(comboPrice);
            setDiscount(comboDiscount);
            setVariantComboId(variantHeader)
        }else if(comboQty == 0){
            if(Object.keys(selectedVariants).length === prodDet.variants?.length){
                setItemStock(0)
            }else{
                setItemStock(prodDet.quantity)
            }            
        }
        

    }, [variantCombo, prodDet, selectedVariants])
    
    const handlePickQuantity = (qty) => {
        setSelectedQty(qty);
        setSubTot(itemPrice * qty);
    };

    const isNotSelectAllvariants = () => {
        // let isNotAllSelectVariants = false;
        // productDetail.productVariant?.map((pVariant) => {
        //   if (selectedVariants[pVariant.catVar] == undefined) {
        //     isNotAllSelectVariants = true;
        //     return;
        //   }
        // });
        // return isNotAllSelectVariants;
    };
    
    const handleBuyNow = () => {
        if (isNotSelectAllvariants()) {
            setValidationMsg("Please select all product variation");
        } else if (itemStock == 0) {
            setValidationMsg("Out of stock");
        } else {
            setValidationMsg("");
        }
    };

    const [addToCart] = useAddToCartMutation();
        
    const handleAddToCart = async () => {
        console.log("handle Add To Cart .. !");
        const dataSet = {
            prodDefId: prodDet.prodDefId,
            prodHeaderId: variantComboId,
            qty: selectedQty,
            orderHeadId: cookies.cartId == undefined ? 0 : cookies.cartId            
        }
        console.log('Cart data..........',dataSet)
        if (itemStock == 0) {
            setValidationMsg("Out of stock");
        } else {
            try {
                const userCartId = await addToCart(dataSet).unwrap();
                // const userCartId = prodDet.prodDefId;            
                console.log('cart item', userCartId.result)
                setCookie("cartId", userCartId.result, {
                    path: "/",
                    // maxAge: 3600, // Expires after 1hr
                    maxAge: 172800, //expires in 2 days
                    sameSite: true
                })
                const items = cookies.cartItems == undefined ? 1 : Number(cookies.cartItems)+1
                setCookie("cartItems", items, {
                    path: "/",
                    // maxAge: 3600, // Expires after 1hr
                    maxAge: 172800, //expires in 2 days
                    sameSite: true
                })
                toast.success("Item successfully added to the cart!");
            } catch (err) {
                console.error('Failed to save the item: ', err)
                toast.error("Erorr, something went wrong!");
            }
        }             
    };
    
    const handleAddToWishList = () => {
        console.log("handle Add To Wish-List .. !");
    };

    return(
        <div>
            {/* product title */}
            <Typography variant="h6" gutterBottom component="div">
                {prodDet.title}
            </Typography>

            {/* product pricing */}
            <ProductPricing 
                itemPrice = {itemPrice}
                currency={currency}
                discount={discount}
            />

            {/* product brands */}
            <ProductBrands 
                brand = {prodDet.brandName}
            />

            {/* product rating */}
            <ProductRating 
                rating = {prodDet.rating}
            />

            {/* variants pick*/}
            {prodDet.variants?.map((variant, index) => (
                <VariantPicker
                    key={index}
                    variantTitle={`${variant.catVar}`}
                    variantValues={variant.productVariants}
                    pickerType={variant.pickerType}
                    pickVariant={(variant, variantVal, pickerType) =>
                        handlePickVariant(variant, variantVal, pickerType)
                }
                />
            ))}

            {/* quantity pick*/}
            <QuantityPicker
                stock={itemStock}
                qtyMsg={ itemStock == 0 ? `Currently out of stock` : `${itemStock} Pieces available` }
                pickQuantity={handlePickQuantity}
            />

            {/* Shipping details */}
            <div style={{ display: "flex", marginTop: "10px" }}>
                <Typography variant="body1" display="block" gutterBottom>
                    Price :
                </Typography>
                <div style={{ display: "flex", paddingLeft: '55px' }}>
                    <Typography variant="body2" gutterBottom>
                        {`${currency} `}
                        {subTot}
                    </Typography>
                </div>
            </div>

            <div>
                {validationMsg && (
                    <Typography
                    variant="body2"
                    gutterBottom
                    color="#ff0000"
                    >
                    {`${validationMsg}`}
                    </Typography>
                )}
            </div>

            {/* buy now , add to cart, add to wish list Buttons*/}
            <ButtonSet 
                handleBuyNow={handleBuyNow}
                handleAddToCart={handleAddToCart}
                handleAddToWishList={handleAddToWishList}
                isAllVariantsSelected={isAllVariantsSelected}
            />

        </div>
    );
}

export default ProductDetails;