/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 05/03/2020
 */

import { useEffect, useState } from "react";

const VariantPicker = (props) => {
  // variantValues = array, variant option list
  // variantTitle = string, name of variant
  // pickerTyper = string , color | text| image
  // pickVariant = function, return picked value
  const { variantTitle, variantValues, pickerType, pickVariant } = props;

  const [selectedVariant, setSelectedVariant] = useState();

  const handlePickVariant = (option, pickerType) => {
    setSelectedVariant(option)
    pickVariant(variantTitle, option, pickerType)
    console.log(selectedVariant)
  }

  return (
    <>
      <div style={{ display: "flex", marginTop: "10px" }}>
        <div style={{ width: "100px" }}>{variantTitle}:</div>
        <div style={{ display: "flex", flexWrap: "wrap" }}>
          {variantValues?.map((option, index) => {
            switch (pickerType) {
              case "color":
                return (
                  <div
                    key={index}
                    onClick={() => handlePickVariant(option.catVar, pickerType)}
                    style={{
                      width: "30px",
                      height: "30px",
                      borderRadius: "2px",
                      marginRight: "3px",
                      marginTop: "3px",
                      backgroundColor: `${option.catVar}`,
                      cursor: "pointer",
                      border: (selectedVariant == option.catVar) ?  '2px solid #03a5b2' : null,
                    }}
                  />
                );

              case "text":
                return (
                  <div
                    key={index}
                    onClick={() => handlePickVariant(option.catVar, pickerType)}
                    style={{
                      // width: "50px",
                      height: "30px",
                      border: (selectedVariant == option.catVar) ?  '2px solid #03a5b2' : "1px solid #000",
                      borderRadius: "5px",
                      padding: "0 10px",
                      marginRight: "3px",
                      marginTop: "3px",
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                      cursor: "pointer",
                    }}
                  >
                    {option.catVar}
                  </div>
                );

              case "image":
                return (
                  <div
                    key={index}
                    onClick={() => handlePickVariant(option.catVar, pickerType)}
                    style={{
                      width: "52px",
                      height: "52px",
                      border: (selectedVariant == option.catVar) ?  '2px solid #03a5b2' : "1px solid #000",
                      borderRadius: "2px",
                      marginRight: "3px",
                      marginTop: "3px",
                      display: "flex",
                      justifyContent: "center",
                      alignItems: "center",
                      cursor: "pointer",
                    }}
                  >
                    <img
                      alt="variant_image"
                      style={{ width: "50px", height: "50px" }}
                      src={option.catVar}
                    />
                  </div>
                );

              default:
                return <p>No picker type</p>;
            }
          })}
        </div>
      </div>
    </>
  );
};
export default VariantPicker;
