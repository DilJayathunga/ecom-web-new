/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 27/7/2022
 */

import { Grid, Typography } from "@mui/material";
import TabPanel from "./tabPanel";

const SpecificationPanel = (props) => {

    const { tabIndex, catAttribute } = props;

    return (  
        <TabPanel value={tabIndex} index={1}>
            <div>
                {/* section title */}
                <div>
                    <Typography variant="h6" gutterBottom component="div">
                        {`Specifications`}
                    </Typography>
                </div>

                {/* Specification section */}
                <div style={{marginTop: '50px', marginLeft: '50px'}}>
                    <Grid container spacing={5}>
                        {catAttribute?.map((item, index) => (
                            <Grid item container xs={6} spacing={5} key={index}>
                                <Grid item xs={6}>
                                    <Typography 
                                        style={{
                                            marginLeft: "5px",
                                            textTransform: "unset",
                                        }} 
                                        variant="overline"
                                    >
                                        {item.attributeName} :
                                    </Typography>
                                </Grid>
                                <Grid item xs={6}>
                                    <Typography 
                                        style={{
                                            marginLeft: "5px",
                                            textTransform: "unset",
                                        }} 
                                        variant="overline"
                                    >
                                        {item.attributeValue}
                                    </Typography>
                                </Grid>
                            </Grid>
                        ))}
                    </Grid>
                </div>
            </div>
        </TabPanel>
    );
}

export default SpecificationPanel;