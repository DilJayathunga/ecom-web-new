/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 26/7/2022
 */

import { Typography } from "@mui/material";

const ProductPricing = (props) => {

    const { itemPrice, currency, discount } = props;

    return (
        <div style={{ display: "flex", alignItems: "end" }}>
            <Typography
                variant="h3"
                gutterBottom
                component="div"
                style={{ margin: "0 0" }}
            >
                $ {itemPrice} 
            </Typography>

            <Typography
                variant="h6"
                gutterBottom
                component="del"
                style={{ margin: "0 0 5px 10px" }}
            >
                {`${currency} `}
                {itemPrice + discount}
            </Typography>
        </div>
    );
}

export default ProductPricing;