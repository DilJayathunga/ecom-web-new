/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 26/7/2022
 */

import { Rating } from "@mui/material";

const ProductRating = (props) => {

    const { rating } = props;

    return ( 
        <div style={{ display: "flex", marginTop: "10px" }}>
            <Rating
                name="simple-controlled"
                value={
                    rating
                    ? rating?.rating
                    : 0
                }
                readOnly
                size="small"
            />
            <div style={{ margin: "0px 0px 0px 5px" }}>
            {`${
                rating
                ? rating?.rating
                : 0
            } ratings`}
            </div>
            <span
            style={{
                width: "1px",
                backgroundColor: "#000000",
                margin: "2px 5px",
                height: "15px",
            }}
            />
            <div>{`${
            rating
                ? rating?.rating
                : 0
            } reviews`}</div>
            <span
            style={{
                width: "1px",
                backgroundColor: "#000000",
                margin: "2px 5px",
                height: "15px",
            }}
            />
            <div>{`${
            rating
                ? rating?.rating
                : 0
            } orders`}</div>
        </div>
    );
}

export default ProductRating;