/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 9/8/2022
 */

import { NavigateBefore, NavigateNext } from "@mui/icons-material";
import { Grid, IconButton } from "@mui/material";
import { useEffect, useRef, useState } from "react";
import { Swiper, SwiperSlide } from "swiper/react";

import "swiper/css";
import "swiper/css/free-mode";
import "swiper/css/navigation";
import "swiper/css/thumbs";

import { Navigation } from "swiper";

const ImageCarousel = (props) => {
    const { images } = props

    const [selectedImage, setSelectedImage] = useState(images[0])
    const [selectedImageIndex, setSelectedImageIndex] = useState(0)

    useEffect(() => {
        if (images && images[0]) {
            setSelectedImage(images[0]);
            setSelectedImageIndex(0);
        }
        
    }, [images])    

    const handleSelectedImageChange = (newIdx) => {
        if (images && images.length > 0) {
            setSelectedImage(images[newIdx]);
            setSelectedImageIndex(newIdx);
        }
    };

    const handlePreviousClick = () => {
        if (images && images.length > 0) {
            let newIdx = selectedImageIndex - 1;
            if (newIdx < 0) {
                newIdx = images.length - 1;
            }
            handleSelectedImageChange(newIdx);
        }
    };
    
    const handleNextClick = () => {        
        if (images && images.length > 0) {
            let newIdx = selectedImageIndex + 1;
            if (newIdx >= images.length) {
                newIdx = 0;
            }
            handleSelectedImageChange(newIdx);
        }
    };

    return (  
        <div style={{margin: '2px', width: '325px'}}>
            <div
                style={{ 
                    backgroundImage: `url(${selectedImage?.url})`, 
                    width: "100%", 
                    height: "300px",
                    marginBottom: '8px',
                    marginTop: '10px',
                    backgroundPosition: 'center center',
                    backgroundRepeat: 'no-repeat',
                    backgroundSize: 'cover',
                }}
            >
            </div>
            <div style={{position: 'relative'}}>
                {/* <Grid container>
                    <Grid item xs={1.5}>
                        <IconButton style={{position: 'absolute', top: '20%', left: '1px'}} onClick={handlePreviousClick}>
                            <NavigateBefore style={{ color: '#03a5b2'}} />
                        </IconButton>
                    </Grid>
                    <Grid item xs={9.5}> */}
                        <div style={{display: 'flex', maxWidth: "100%",  overflowX: 'hidden'}}>
                            <Swiper
                                slidesPerView={4}
                                // watchSlidesProgress={true}
                                // freeMode={true}
                                slidesPerGroup={4}
                                navigation={true}
                                modules={[Navigation]}
                                className="mySwiper"
                            >
                                {images && images.map((image, idx) => (
                                    <SwiperSlide key={image.id}>
                                        <div
                                            onClick={() => handleSelectedImageChange(idx)}
                                            style={{ 
                                                backgroundImage: `url(${image.url})` ,
                                                height: '70px',
                                                minWidth: '70px',
                                                border: selectedImageIndex === idx ? '2px solid #03a5b2' : '3px solid #ffa70000',
                                                backgroundPosition: 'center center',
                                                backgroundRepeat: 'no-repeat',
                                                backgroundSize: 'cover',
                                            }}
                                            key={image.id}
                                        />
                                    </SwiperSlide>
                                ))}
                            </Swiper>
                        </div>
                    {/* </Grid>
                    <Grid item xs={1}>
                        <IconButton style={{position: 'absolute', top: '20%'}} onClick={handleNextClick}>
                            <NavigateNext style={{ color: '#03a5b2'}} />
                        </IconButton>
                    </Grid>
                </Grid> */}
            </div>
        </div>
    );
}

export default ImageCarousel;
