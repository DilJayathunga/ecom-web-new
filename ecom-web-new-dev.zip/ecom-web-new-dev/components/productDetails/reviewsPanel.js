/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 27/7/2022
 */

import { Button, Grid, Rating, Typography } from "@mui/material";
import { useState } from "react";
import DetailRating from "./detailRating";
import ReviewDetailCard from "./ReviewDetailCard";
import TabPanel from "./tabPanel";

const ReviewsPanel = (props) => {

    const { tabIndex, rating } = props;

    const [showReview, setShowReview] = useState(false);

    const handleShowReviews = (stars) => {
        console.log("handl eShow Reviews", stars);
        stars == "all" ? setShowReview(!showReview) : setShowReview(true);
    };

    const handleIsReViewUseFull = (usefull) => {
        console.log("handle Is ReView UseFull ", usefull);
    };

    return (  
        <TabPanel value={tabIndex} index={2}>
            <div>
                {/* section title */}
                <div>
                    <Typography variant="h6" gutterBottom component="div">
                        {`Customer Reviews (${30})`}
                    </Typography>
                </div>

                {/* ratings summery */}
                <div>
                    <Grid container spacing={10}>
                        <Grid item xs={4} sm={4} md={4} lg={4} xl={4}>
                            {rating?.average.map(
                                (item, index) => (
                                    <DetailRating
                                        key={index}
                                        title={Object.keys(item)[0]}
                                        rate={Object.values(item)[0]}
                                        onShowReview={(title) => handleShowReviews(title)}
                                    />
                                )
                            )}
                        </Grid>
                        <Grid item xs={8} sm={8} md={8} lg={8} xl={8}>
                            <div
                                style={{
                                    display: "flex",
                                    height: "100%",
                                    alignItems: "center",
                                }}
                            >
                                <Typography
                                    variant="p"
                                    gutterBottom
                                    component="div"
                                    style={{ width: "60px" }}
                                >
                                {rating
                                    ? rating?.rating
                                    : 0}
                                /5
                                </Typography>
                                <Rating
                                    name="simple-controlled"
                                    value={
                                        rating
                                        ? rating?.rating
                                        : 0
                                    }
                                    readOnly
                                    size="small"
                                />
                            </div>
                        </Grid>
                    </Grid>
                </div>

                {/* view details button */}
                <div
                    style={{
                        margin: "20px 0",
                        display: "flex",
                        justifyContent: "center",
                    }}
                >
                    <Button
                        variant="outlined"
                        onClick={() => handleShowReviews("all")}
                    >
                        {showReview == false
                        ? "View Details"
                        : "Hide Details"}
                    </Button>
                </div>

                {/* review details section */}
                {showReview && (
                    <div>
                        <ReviewDetailCard
                            isHelpfull={(val) => handleIsReViewUseFull(val)}
                        />
                    </div>
                )}
            </div>
        </TabPanel>
    );
}

export default ReviewsPanel;