/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 15/03/2020
 */

import { Button, Grid, Rating, Typography } from "@mui/material";
import { useState } from "react";

const ReviewDetailCard = (props) => {
  // title = string, name of rating
  // rate = number, 0 - 100 value rating presentage
  const { isHelpfull } = props;

  const [qty, setQty] = useState(1);

  return (
    <Grid container spacing={2}>
      <Grid item xs={1} sm={1} md={1} lg={1} xl={1}>
        <div>
          <img
            alt="image"
            style={{ width: "50px", height: "50px" }}
            src={`https://d2qp0siotla746.cloudfront.net/img/use-cases/profile-picture/template_3.jpg`}
          />
        </div>
        <Typography
          variant="h6"
          gutterBottom
          component="div"
          style={{ color: "#bfbfbf" }}
        >
          {"Dwayne Johnson"}
        </Typography>
      </Grid>
      <Grid item xs={11} sm={11} md={11} lg={11} xl={11}>
        <Rating
          name="simple-controlled"
          max={6}
          value={3}
          readOnly
          size="small"
        />
        <Typography variant="body1" gutterBottom style={{ color: "#bfbfbf" }}>
          Colour: Pixel emoji pink
        </Typography>

        <Typography variant="body1" align="justify" gutterBottom>
          Received in 22 days in France. Complies with the description. The
          night light is a little too bright I think, even set to a minimum. The
          display turns on when you touch it or make noise, otherwise it remains
          black, it is practical. The night light does not bad the battery.
          <span style={{ marginLeft: "10px", color: "#bfbfbf" }}>
            05 Oct 2021 00:37
          </span>
        </Typography>

        <Grid container spacing={2}>
          <Grid item xs={12} sm={9} md={9} lg={9} xl={9} style={{ display: "flex" }}>
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                flexWrap: "wrap",
                width: "50px",
                height: "60px",
                border: "1px solid #808080",
                borderRadius: "5px",
                marginRight: "5px",
                overflow: "hidden",
              }}
            >
              <img
                alt="image"
                style={{ height: "100%" }}
                src={`https://ae01.alicdn.com/kf/U45a7de42fb9b4b6393ad2fdb7d42f7d7Z.jpg`}
              />
            </div>

            <div
              style={{
                display: "flex",
                justifyContent: "center",
                flexWrap: "wrap",
                width: "50px",
                height: "60px",
                border: "1px solid #808080",
                borderRadius: "5px",
                marginRight: "5px",
                overflow: "hidden",
              }}
            >
              <img
                alt="image"
                style={{ height: "100%" }}
                src={`https://ae01.alicdn.com/kf/Uff06cb7a50bd4a21ada96ea4bb05b43dY.jpg`}
              />
            </div>

            <div
              style={{
                display: "flex",
                justifyContent: "center",
                flexWrap: "wrap",
                width: "50px",
                height: "60px",
                border: "1px solid #808080",
                borderRadius: "5px",
                marginRight: "5px",
                overflow: "hidden",
              }}
            >
              <img
                alt="image"
                style={{ height: "100%" }}
                src={`https://ae01.alicdn.com/kf/U353938d1ddac410cb32425582089c0c9P.jpg`}
              />
            </div>
          </Grid>
          <Grid item xs={12} sm={3} md={3} lg={3} xl={3}
            style={{
              display: "flex",
              justifyContent: "flex-end",
              alignItems: "center",
            }}
          >
            helpfull?
            <Button
              variant="outlined"
              style={{
                marginLeft: "5px",
                color: "#000",
                borderColor: "#000",
              }}
              onClick={()=> isHelpfull(true)}
            >{`Yes (${2})`}</Button>
            <Button
              variant="outlined"
              style={{
                marginLeft: "5px",
                color: "#000",
                borderColor: "#000",
              }}
              onClick={()=> isHelpfull(false)}
            >{`No (${5})`}</Button>
          </Grid>
        </Grid>

        <hr
          style={{
            margin: "15px 0",
            border: "none",
            height: "1px",
            backgroundColor: "#ccc",
          }}
        />

        <Typography variant="body1" gutterBottom style={{ color: "#bfbfbf" }}>
          Additional Feedback
        </Typography>

        <Typography variant="body1" align="justify" gutterBottom>
          The clock came in good condition.
        </Typography>
      </Grid>
    </Grid>
  );
};
export default ReviewDetailCard;
