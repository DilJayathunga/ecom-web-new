/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 26/7/2022
 */

const ProductBrands = (props) => {

    const { brand } = props;

    return (
        <div style={{ display: "flex" }}>
            <div
                style={{
                    maxWidth: "200px",
                    backgroundColor: "#d9d9d9",
                    padding: "3px 10px",
                    borderRadius: "5px",
                    marginRight: "5px",
                    cursor: "pointer",
                }}
            >
                {brand}
            </div>
        </div>
    );
}

export default ProductBrands;