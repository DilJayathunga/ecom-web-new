/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 09/03/2020
 */

import { Remove, Add } from "@mui/icons-material";
import { useEffect, useState } from "react";

const QuantityPicker = (props) => {
  // data = array, variant option list
  // variantTitle = string, name of variant
  // stock = number , available stock
  // pickQuantity = function, return picked value
  const { pickQuantity, stock, qtyMsg } = props;

  const [qty, setQty] = useState(stock != 0 ? 1 : 0);

  const handelQtyIncrement = () => {
    console.log("++");
    if (stock > qty) {
      setQty(qty + 1);
    }
  };
  const handelQtyDecrement = () => {
    console.log("--");
    if (qty > 1) {
      setQty(qty - 1);
    }
  };

  // useEffect(() => {
  //   console.log("+/-", qty);
  //   pickQuantity(qty);
  // }, [qty]);

  useEffect(() => {
    pickQuantity(qty);
  }, [qty, pickQuantity]);

  return (
    <>
      <div style={{ display: "flex", marginTop: "10px" }}>
        <div style={{ width: "115px" }}>Quantity:</div>
        <div style={{ display: "flex", paddingLeft: '35px' }}>
          {/* Quantity: */}
          <div
            onClick={handelQtyDecrement}
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              width: "30px",
              height: "30px",
              borderRadius: "15px",
              backgroundColor: "#cccccc",
              cursor: (stock == 0 || qty == 1) ? 'no-drop' :  "pointer",
            }}            
          >
            <Remove />
          </div>

          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              width: "30px",
              height: "30px",
            }}
          >
            {qty}
          </div>

          <div
            onClick={handelQtyIncrement}
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              width: "30px",
              height: "30px",
              borderRadius: "15px",
              backgroundColor: "#cccccc",
              cursor: (stock == 0) ? 'no-drop' :  "pointer",
            }
          }
            
          >
            <Add />
          </div>

          <div
            style={{
              display: "flex",
              justifyContent: "flex-start",
              alignItems: "center",
              width: "300px",
              height: "30px",
              marginLeft: "10px",
            }}
          >
            {qtyMsg}
          </div>
        </div>
      </div>
    </>
  );
};
export default QuantityPicker;
