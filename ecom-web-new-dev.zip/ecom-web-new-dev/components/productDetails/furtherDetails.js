/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 27/7/2022
 */

import { Grid, Typography } from "@mui/material";

const FurtherDetails = () => {
    return (  
        <Grid item xs={6} sm={6} md={12} lg={12} xl={12}>
            <div style={{ display: "flex" }}>
                <Typography
                    variant="body1"
                    gutterBottom
                    style={{ width: "100px" }}
                >
                    Shipping*:
                </Typography>
                <Typography variant="body1" gutterBottom>
                    $2.93 Shipping
                </Typography>
            </div>

            <div style={{ display: "flex" }}>
                <Typography
                    variant="body1"
                    gutterBottom
                    style={{ width: "100px" }}
                >
                    Delivery*:
                </Typography>
                <Typography variant="body1" gutterBottom>
                    February 11 - 22
                </Typography>
            </div>

            <div style={{ display: "flex" }}>
                <Typography
                    variant="body1"
                    gutterBottom
                    style={{ width: "100px" }}
                >
                    Returns*:
                </Typography>
                <Typography variant="body1" gutterBottom>
                    Eligible for Return, Refund or Replacement
                </Typography>
            </div>

            <div style={{ display: "flex" }}>
                <Typography
                    variant="body1"
                    gutterBottom
                    style={{ width: "100px" }}
                >
                    Warranty*:
                </Typography>
                <Typography variant="body1" gutterBottom>
                    1 Year Brand Warranty
                </Typography>
            </div>
        </Grid>
    );
}

export default FurtherDetails;