/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 26/7/2022
 */

import { Button } from "@mui/material";
import { FavoriteBorder } from "@mui/icons-material";

function ButtonSet(props) {

    const { handleBuyNow, handleAddToCart, handleAddToWishList, isAllVariantsSelected } = props;

    return (  
        <div style={{ display: "flex" }}>
            <Button
                variant="contained"
                size="small"
                style={{ flex: 1, marginRight: "10px" }}
                onClick={handleBuyNow}
                disabled={!isAllVariantsSelected}
            >
                {" "}
                Buy Now{" "}
            </Button>
            <Button
                variant="outlined"
                size="small"
                style={{ flex: 1, marginRight: "10px" }}
                onClick={handleAddToCart}
                disabled={!isAllVariantsSelected}
            >
                {" "}
                Add to cart{" "}
            </Button>
            <Button
                variant="outlined"
                size="small"
                startIcon={<FavoriteBorder />}
                onClick={handleAddToWishList}
                disabled={!isAllVariantsSelected}
            >
                {" "}
                8.6k*{" "}
            </Button>
        </div>
    );
}

export default ButtonSet;