/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 27/7/2022
 */

import { Typography } from "@mui/material";
import TabPanel from "./tabPanel";
import parse from 'html-react-parser';

const DescriptionPanel = (props) => {

    const { tabIndex, description } = props;

    return (  
        <TabPanel value={tabIndex} index={0}>
            {/* 
            --- for HTML viewer
            https://www.npmjs.com/package/react-render-html - not working

            --- for HTML editor
            @progress/kendo-react-editor
            */}
            {/* <div>
                <img
                style={{ width: "100%" }}
                src={
                    "https://ae01.alicdn.com/kf/H2417c43ff0ef49c59ab48caca7e3da83X.jpg"
                }
                />
                <img
                style={{ width: "100%" }}
                src={
                    "https://ae01.alicdn.com/kf/Hf8cabd1667714d7b9719e60adec310aaB.jpg"
                }
                />
                <img
                style={{ width: "100%" }}
                src={
                    "https://ae01.alicdn.com/kf/H1137715852974bb9982436a6e0b1b315n.jpg"
                }
                />
            </div> */}

            <div>
                {/* section title */}
                <div>
                    <Typography variant="h6" gutterBottom component="div">
                        {`Description`}
                    </Typography>
                </div>

                {/* Description render area */}
                {/* {parse(datax.overview)} */}
                {parse(description?description:'<></>')}
            </div>
        </TabPanel>
    );
}

export default DescriptionPanel;

const datax = {
    
    overview:
      '<p style="text-align: center;"><img src="https://ae01.alicdn.com/kf/S8c1a65b224174803b187010fd8f8061b5.jpg"></p><p style="text-align: center;"><img src="https://gist.github.com/simonssspirit/0db46d4292ea8e335eb18544718e2624/raw/8d771bb7f397ca89fe55671b7fc3664e41828e92/kendoka.png" alt="KendoReact logo" title="KendoReact" width="100" height="100"></p><p><strong>KendoReact Editor</strong> allows your users to edit HTML in a familiar, user-friendly way.<br>In this version, the Editor provides the core HTML editing engine, which includes basic text formatting, hyperlinks, lists, and image handling. The widget <strong>outputs identical HTML</strong> across all major browsers, follows accessibility standards and provides <a href="https://www.telerik.com/kendo-react-ui/components/editor/tools/" target="_blank" title="https://www.telerik.com/kendo-react-ui/components/editor/tools/">multiple tools</a> for content manipulation.</p><p style="text-align: center;"><img src="https://ae01.alicdn.com/kf/H339f743e1a1e43fe92b8d76a0dd740f5I.jpg"></p><p style="text-align: center;"><img src="https://ae01.alicdn.com/kf/Hfaef0bcc374c4d64aa5dcad1c25ad7fdF.jpg"></p><p>Features include:</p><ul><li><p>Text formatting &amp; alignment</p></li><li><p>Bulleted and numbered lists</p></li><li><p>Hyperlink and image dialogs</p></li><li><p>Identical HTML output across modern browsers</p></li><li><p><a href="https://www.telerik.com/kendo-react-ui/knowledge-base/add-custom-tools-to-the-editor-and-customize-built-in-tools/" target="_blank" title="Customize tools">Highly customizable tools</a></p></li></ul><p></p><p>The Editor has a table option as well, allowing to add and edit tabular data.<br></p><table><tbody><tr><td><p style="text-align: center;"><strong>Product Id</strong></p></td><td><p style="text-align: center;"><strong>Product Name</strong></p></td><td><p style="text-align: center;"><strong>Price</strong></p></td></tr><tr><td><p>1</p></td><td><p>Chai</p></td><td><p style="text-align: right;">18</p></td></tr><tr><td><p>2</p></td><td><p>Chang</p></td><td><p style="text-align: right;">19</p></td></tr><tr><td><p>3</p></td><td><p>Aniseed Syrup</p></td><td><p style="text-align: right;">10</p></td></tr></tbody></table><p style="text-align: center;"><img src="https://ae01.alicdn.com/kf/H339ff6b0c0d44e3cacf16f1599c0b1cbd.jpg"></p><p></p><p style="text-align: left;"><img src="https://ae03.alicdn.com/kf/Sdcb5919dcf3e4c9b82dfea2484a02c41s.jpg"></p><p style="text-align: right;"><img src="https://ae03.alicdn.com/kf/Hc8dcb84487854790b3992ed216474527K.jpg"></p>',
    
};