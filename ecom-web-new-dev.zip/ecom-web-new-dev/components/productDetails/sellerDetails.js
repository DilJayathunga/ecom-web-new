/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 27/7/2022
 */

import { Button, Grid, Typography } from "@mui/material";

const SellerDetails = (props) => {

    const { seller } = props;

    return (  
        <Grid item xs={6} sm={6} md={12} lg={12} xl={12}>
            <hr/>
            <Typography variant="h6" gutterBottom style={{}}>
                Seller: {seller}
            </Typography>
            <Typography variant="body1" gutterBottom style={{}}>
                90.9% Positive Feedback*
            </Typography>

            <div style={{ display: "flex" }}>
                <div>140 ratings*</div>
                <span style={{
                        width: "1px",
                        backgroundColor: "#000000",
                        margin: "2px 5px",
                        height: "20px",
                    }}
                />
                <div>30 reviews*</div>
            </div>

            <div>Contact</div>

            <div style={{ display: "flex", marginTop: "1rem" }}>
                <Button
                    variant="outlined"
                    size="small"
                    style={{ flex: 1, marginRight: "10px" }}
                >
                    Follow store
                </Button>
                <Button
                    variant="contained"
                    size="small"
                    style={{ flex: 1, marginRight: "10px" }}
                >
                    Visit store
                </Button>
            </div>
        </Grid>
    );
}

export default SellerDetails;