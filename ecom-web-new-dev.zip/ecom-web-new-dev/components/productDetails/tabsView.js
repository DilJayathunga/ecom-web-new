/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 27/7/2022
 */

import { Box, Grid, Tab, Tabs } from "@mui/material";
import { useState } from "react";
import DescriptionPanel from "./descriprionPanel";
import ReviewsPanel from "./reviewsPanel";
import SpecificationPanel from "./specificationPanel";

const TabsView = (props) => {

    const { prodDet } = props;
    console.log('detail', prodDet)

    const [tabIndex, setTabIndex] = useState(0);

    const handleTabChange = (event, newValue) => {
        setTabIndex(newValue);
    };

    return (  
        <Grid container spacing={10}>
            <Grid item xs={12} sm={12} md={12} lg={12} xl={12}>
                <Box sx={{ width: "100%", bgcolor: "background.paper" }}>
                    <Tabs value={tabIndex} onChange={handleTabChange} centered>
                        <Tab label="Description" />
                        <Tab label="Specification" />
                        <Tab label={`Customer Reviews (${30})`} />
                    </Tabs>

                    {/* Description panel */}
                    <DescriptionPanel tabIndex={tabIndex} description={prodDet.prodDesc}/>

                    {/* Specification panel */}
                    <SpecificationPanel 
                        tabIndex={tabIndex} 
                        catAttribute={prodDet.attributes} 
                    />

                    {/* Customer Reviews panel */}
                    <ReviewsPanel 
                        tabIndex={tabIndex}
                        rating={prodDet.rating}
                    />
                </Box>
            </Grid>
        </Grid>
    );
}

export default TabsView;