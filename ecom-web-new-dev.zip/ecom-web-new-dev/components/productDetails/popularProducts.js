/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 27/7/2022
 */

import { Box, Container, Grid, Paper, Typography } from "@mui/material";
import SingleItemCardOne from "../shared/SingleItemCardOne";

const PopularProducts = (props) => {

    const { recommendList } = props;

    return (  
        <Container maxWidth="xl" style={{ marginTop: "50px" }}>
            <Paper style={{ marginBottom: "50px" }}>
                <Container style={{ padding: "20px 0 20px 0" }} >
                    <div>
                        <Typography variant="h6" gutterBottom component="div">
                            Popular Products
                        </Typography>
                    </div>
                    <Grid
                        container
                        spacing={1}
                        style={{ display: "flex", justifyContent: "space-around" }}
                    >
                        {recommendList?.map((item, index) => (
                            <SingleItemCardOne itemData={item} key={index} />
                        ))}
                    </Grid>
                </Container>
            </Paper>
        </Container>
    );
}

export default PopularProducts;