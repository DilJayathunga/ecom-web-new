/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 09/03/2020
 */

import { LinearProgress, Typography } from "@mui/material";
import { useState } from "react";


const DetailRating = (props) => {
  // title = string, name of rating
  // rate = number, 0 - 100 value rating presentage
  // onShowReview = function, review filter by stars
  const { title, rate, onShowReview } = props;

  const [qty, setQty] = useState(1);


  return (
    <>
      <div style={{ display: "flex", alignItems: "center", marginTop:'5px' }}>
        <Typography
          variant="p"
          gutterBottom
          component="div"
          style={{ width: "60px" }}
        >
          {title}
        </Typography>

        <LinearProgress
          style={{ flex: 1, margin: "0 10px 0 20px" }}
          variant="determinate"
          value={rate}
        />

        <div
          style={{
            width: "50px",
            border: "1px solid #11aaff",
            borderRadius: "3px",
            padding: "5px",
            textAlign: "center",
            cursor:'pointer'
          }}
          onClick={() => onShowReview(title)}
        >
          {`${rate} %`}
        </div>
      </div>
    </>
  );
};
export default DetailRating;
