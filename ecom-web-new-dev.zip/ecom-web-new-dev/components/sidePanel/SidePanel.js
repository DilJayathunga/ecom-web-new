/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 1/7/2022
 */

import { List, ListItem, Paper, Typography } from "@mui/material";
import { Box } from "@mui/system";

import Link from "next/link";

const SidePanelComp = (props) => {
  
console.log(props, "pro")
  const {name,list} = props

    return (
      <>
        <Paper style={{
            // width: '270px',
            // height: '700px',
            margin: '10px',
            // backgroundColor: '#93c1d3',
            padding:'10px 0 147px 10px'
        }}>
          <Typography sx={{
                  padding: '32px 0 0 28px',
                  fontSize: '28px',
                  fontWeight: 'bold',
                  fontStretch: 'normal',
                  textAlign: 'left',
                  color: '#3a3a3a',
                  width: '275px'
              }}>
                 {name}
              </Typography>
            <Box sx={{padding: '30px 0 0 0'}}>
            <List dense={false}>
          
            {list.map((item) => (
              <ListItem key={item.id} sx={{
                padding: '12px 18px 12px 28px', 
                '&:active, &:hover, &:focus': {
                    // backgroundColor: '#f2f2f2',
                    color: '#4caf50',
            }}}>
                <Link                  
                  sx={{
                    color: '#3a3a3a',
                    fontSize: '20px',
                    // textDecoration: 'none',
                    '&:active, &:hover, &:focus': {
                            color: '#4caf50',
                    }
                  }}
                  href={item.link} 
                  >
                    <a>
                        <Typography sx={{fontSize: '20px',}}>
                            {item.name}
                        </Typography>
                    </a>
                </Link>
              </ListItem>
            ))}
          </List>
          </Box>
        </Paper>
      </>
    );
};


   

export const SidePanel = SidePanelComp;