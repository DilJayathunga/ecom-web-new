/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 28/04/2020
 */

import { makeStyles } from "@mui/material";

export const useStyles = makeStyles({
        container: {
                width: '270px',
                height: '700px',
                margin: '50px 25px 86px 50px',
                backgroundColor: '#fff',
                padding:'10px 0 0 10px'
        },
        listItem: {
                // padding: '12px 18px 12px 18px',
                '&:active, &:hover, &:focus': {
                        backgroundColor: '#f2f2f2',
                        color: '#4caf50',
                }
        },
        link: {
                color: '#3a3a3a',
                fontSize: '20px',
                textDecoration: 'none',
                '&:active, &:hover, &:focus': {
                        color: '#4caf50',
                }
        },
});
