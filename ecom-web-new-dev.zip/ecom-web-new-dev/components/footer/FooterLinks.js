import { Grid, ListSubheader, MenuItem, Typography } from "@mui/material"
import { useState } from "react";

const FooterLinks =() => {

    const [value, setValue] = useState([]);

    const names = [
        "Link 1 ",
        "Link 2",
        "Link 3",
    ];
  
    const names2 = [
        "Link 1 ",
        "Link 2",
        "Link 3",
    ];
  
    const names3 = [
        "Link 1 ",
        "Link 2",
        "Link 3",
    ];
  
    const names4 = [
        "Link 1 ",
        "Link 2",
        "Link 3",
    ];
  
    const handleChange = (value) => {
      setValue([value]);
    };
  
    const [anchorEl, setAnchorEl] = useState(null);

    const open = Boolean(anchorEl);

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    return(
        <Grid container style={{ width: "100%" }}>
            <Grid item xs={3} md={3}>
              <ListSubheader style={{backgroundColor:'#004763',color:'white'}}>About Us</ListSubheader>
              {names.map((name) => (
                <MenuItem
                  key={name}
                  value={name}
                  onClick={() => handleChange(name)}
                >
                  <Typography noWrap>{name}</Typography>
                </MenuItem>
              ))}
            </Grid>

            <Grid item xs={3} md={3}>
            <ListSubheader style={{backgroundColor:'#004763',color:'white'}}>Customer Services</ListSubheader>
              {names2.map((name) => (
                <MenuItem
                  key={name}
                  value={name}
                  onClick={() => console.log("on selected ", name)}
                >
                  {name}
                </MenuItem>
              ))}
            </Grid>

            <Grid item xs={3} md={3}>
            <ListSubheader style={{backgroundColor:'#004763',color:'white'}}>Sell With Us</ListSubheader>
              {names3.map((name) => (
                <MenuItem
                  key={name}
                  value={name}
                  onClick={() => console.log("on selected ", name)}
                >
                  {name}
                </MenuItem>
              ))}
            </Grid>
  
            <Grid item xs={3} md={3}>
            <ListSubheader style={{backgroundColor:'#004763', color:'white'}}>Helpful Links</ListSubheader>
              {names4.map((name) => (
                <MenuItem
                  key={name}
                  value={name}
                  onClick={() => handleChange(name)}
                >
                  {name}
                </MenuItem>
              ))}
            </Grid>
        </Grid>        
    );
}

export default FooterLinks;