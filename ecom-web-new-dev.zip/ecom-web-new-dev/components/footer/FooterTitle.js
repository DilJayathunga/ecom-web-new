import { Typography } from "@mui/material";

const FooterTitle = () => {
    return (
        <>
            <Typography variant='inherit' style={{paddingTop:40,}}>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras maximus enim a neque porttitor, quis malesuada eros congue. Curabitur rutrum ligula at urna tincidunt.
            </Typography>
        </>
    );
}

export default FooterTitle;