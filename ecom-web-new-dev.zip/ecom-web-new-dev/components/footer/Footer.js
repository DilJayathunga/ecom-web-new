/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 20/01/2020
 */

import { Container, Toolbar } from "@mui/material";
import React, { useState, useEffect } from "react";
import FooterLinks from "./FooterLinks";
import FooterLogo from "./footerLogo";
import FooterTitle from "./FooterTitle";

const Footer = () => {
  return (
    
    <>
      {/* <div style={{ backgroundColor: "#004763", color: "white", position: "inherit", bottom: 0, width: "100%" }}> */}
        <div style={{backgroundColor: "#004763", color: "white", bottom: 0, width: "100%" }}>
        <Container style={{ paddingTop: 40, }}>
          <FooterLinks />
          <FooterTitle />
          <Toolbar>
            <FooterLogo />
          </Toolbar>
        </Container>
      </div>
    </>
  );
};
export default Footer;
