/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 25/8/2022
 */

import { Delete, Edit, Visibility } from "@mui/icons-material";
import { Box, ButtonGroup, IconButton, Pagination, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material";
import { useState } from "react";
import { useDispatch } from "react-redux";
import usePagination from "../../hooks/usePagination";
import { openPolicyForm, setSelectedPolicy, setStatus } from "../../store/slices/policySlice";

const PolicyTable = ({ policies }) => {

    const dispatch = useDispatch();

    let [page, setPage] = useState(1);
    const PER_PAGE = 8;

    const count = Math.ceil(policies.length / PER_PAGE);
    const _DATA = usePagination(policies, PER_PAGE);

    const handleChange = (e, p) => {
        setPage(p);
        _DATA.jump(p);
    }

    const handleEditClick = (id) => {
        dispatch(openPolicyForm(true)); 
        dispatch(setSelectedPolicy(id)); 
        dispatch(setStatus('edit'))
    };

    const handleDeleteClick = (id) => {
        dispatch(openPolicyForm(true)); 
        dispatch(setSelectedPolicy(id)); 
        dispatch(setStatus('delete'))
    };

    return (  
        <>
            <TableContainer sx={{ height: '400px' }}>
                <Table stickyHeader aria-label="simple table" sx={{ height: "max-content" }}>
                    <TableHead>
                        <TableRow>
                            <TableCell width={50}>Policy Number</TableCell>
                            <TableCell width={200}>Policy Name</TableCell>
                            <TableCell width={50}>Policy Type</TableCell>
                            <TableCell width={50}>Allowed Days</TableCell>
                            <TableCell align="center" width={'30%'}>Action</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {_DATA.currentData().map((policy) => (
                            <TableRow sx={{ height: '30px' }} key={policy.policyId}>
                                <TableCell component="th" scope="row" sx={{ borderBottom: "none", fontWeight: 'bold', width: 100, height: 'auto !important' }}>
                                    #{policy.policyId}
                                </TableCell>
                                <TableCell sx={{ borderBottom: "none", width: 50, height: 'auto !important' }}>{policy.policy}</TableCell>
                                <TableCell sx={{ borderBottom: "none", width: 50, height: 'auto !important' }}>{policy.typeName}</TableCell>
                                {/* <TableCell sx={{ borderBottom: "none", width: 50, height: 'auto !important' }}>{policy.policyType}</TableCell> */}
                                <TableCell align="center" sx={{ borderBottom: "none", width: 50, height: 'auto !important' }}>{policy.allowedDays}</TableCell>
                                <TableCell align="center" sx={{ borderBottom: "none", width: '30%', height: 'auto !important' }}>
                                    <ButtonGroup variant="text" aria-label="text button group">
                                        {/* <IconButton aria-label="view" onClick={() => { handleEditClick(policy.policyId) }}>
                                            <Visibility />
                                        </IconButton> */}
                                        <IconButton aria-label="edit" onClick={() => { handleEditClick(policy.policyId) }}>
                                            <Edit />
                                        </IconButton>
                                        <IconButton aria-label="delete" onClick={() => { handleDeleteClick(policy.policyId) }}>
                                            <Delete />
                                        </IconButton>
                                    </ButtonGroup>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
            <Box my={2} display="flex" justifyContent="center">
                <Pagination
                    count={count}
                    size="large"
                    page={page}
                    variant="outlined"
                    color="primary"
                    onChange={handleChange}
                    style={{ justifyContent: 'center', right: 0 }}
                />
            </Box>
        </>
    );
}

export default PolicyTable;