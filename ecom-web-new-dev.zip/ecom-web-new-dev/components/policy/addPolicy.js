/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 26/8/2022
 */

import { yupResolver } from '@hookform/resolvers/yup';
import { Button, FormControl, InputLabel, MenuItem, Select, TextField, Typography } from '@mui/material';
import { useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { toast } from 'react-toastify';
import { object, string } from 'yup';
import { useGetOrganizationsQuery } from '../../store/services/orgService';
import { useCreatePolicyMutation, useGetAllPolicyTypesQuery } from '../../store/services/policyService';

import { openPolicyForm } from '../../store/slices/policySlice';
import styles from '../../styles/util.module.css';

const schema = object().shape({
    orgId: string().required(),
    policyType: string().required(),
    policy: string().required(),

    allowedDays: string().required(),
});

const AddPolicy = () => {

    const dispatch = useDispatch();

    const { register, handleSubmit, getValues, setValue, formState: { errors } } = useForm({
        // defaultValues: {
        //     orgId: "init",

        //     allowedDays: "",
        // },
        resolver: yupResolver(schema),
    });

    const { data: orgData } = useGetOrganizationsQuery();
    const orgs = orgData?.list?.map(org => (
        <MenuItem key={org.orgId} value={org.orgId}>{org.orgName}</MenuItem>
    ));

    const { data: policyTypeData } = useGetAllPolicyTypesQuery();
    const types = policyTypeData?.policyTypes?.map(type => (
        <MenuItem key={type.policyTypeId} value={type.policyTypeId}>{type.policyType}</MenuItem>
    ));

    const [createPolicy] = useCreatePolicyMutation();


    const submit = async (data) => {
        console.log(data);
        try {
            await createPolicy(data).unwrap();
            toast.success("Policy successfully added!");
        } catch (err) {
            console.error(err);
            toast.error("Erorr, something went wrong!");
        } finally {
            dispatch(openPolicyForm(false));
        }
    }

    return (
        <>
            <Typography my={3} variant="h5" textAlign="center" fontWeight="bold">
                Policy Creation
            </Typography>

            <form onSubmit={handleSubmit(submit)}>
                <div className={styles.formItem}>
                    <label className={styles.formLabel}>Organization:</label>
                    {errors.orgId && errors.orgId.type === "required" && <span style={{color: 'red'}}> *</span>}
                    <FormControl fullWidth>
                        {/* <InputLabel shrink={false}>{getValues('orgId') === undefined ? 'Select Organization': ''}</InputLabel> */}
                        <Select 
                            onChange={(e) => setValue('orgId', e.target.value, { shouldValidate: true })}
                            {...register("orgId")} size="small" 
                            fullWidth className={styles.formText} 
                            defaultValue=""
                        >
                            {orgs}
                        </Select>
                    </FormControl>
                </div>
                <div className={styles.formItem}>
                    <label className={styles.formLabel}>Policy Type:</label>
                    {errors.policyType && errors.policyType.type === "required" && <span style={{color: 'red'}}> *</span>}
                    <FormControl fullWidth>
                        {/* <InputLabel shrink={false}>{getValues('policyType') !== undefined ? '' : 'Select Policy Type'}</InputLabel> */}
                        <Select 
                            onChange={(e) => setValue('policyType', e.target.value, { shouldValidate: true })}
                            {...register("policyType")} size="small" 
                            fullWidth className={styles.formText} 
                        >
                            {types}
                        </Select>
                    </FormControl>
                </div>
                <div className={styles.formItem}>
                    <label className={styles.formLabel}>Name:</label>
                    {errors.policy && errors.policy.type === "required" && <span style={{color: 'red'}}> *</span>}
                    <TextField {...register("policy")} size="small" fullWidth placeholder='Enter Policy name' className={styles.formText} />

                </div>
                <div className={styles.formItem}>
                    <label className={styles.formLabel}>Allowed Days:</label>
                    {errors.allowedDays && errors.allowedDays.type === "required" && <span style={{color: 'red'}}> *</span>}
                    <TextField {...register("allowedDays")} size="small" fullWidth placeholder='Enter Allowed Days' className={styles.formText} />
                </div>
                {/* Submit Button */}
                <div style={{ marginTop: "2rem", marginBottom: '1rem', display: 'flex', justifyContent: 'center' }}>
                    <Button type="submit" style={{width: "10rem"}} variant="contained">Save</Button>
                </div>
            </form>
        </>
    )
}

export default AddPolicy;