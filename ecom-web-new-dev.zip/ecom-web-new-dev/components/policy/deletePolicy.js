/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 30/8/2022
 */


import { Button, Container, Typography } from "@mui/material";
import { useSelector, useDispatch } from "react-redux";
import { toast } from "react-toastify";
import { openPolicyForm } from "../../store/slices/policySlice";
import { useDeletePolicyMutation } from "../../store/services/policyService";

const DeletePolicy = () => {

    const dispatch = useDispatch();
    const policy = useSelector((state) => state.policy);

    const [deletePolicy, { isLoading }] = useDeletePolicyMutation();

    const onDeleteConfirm = async () => {
        console.log('Deleted...', policy.selectedPolicy);
        const id = policy.selectedPolicy;
        try {
            const deletedCat = await deletePolicy(id).unwrap();
            console.log('deleted policy', deletedCat)
            toast.success("Policy successfully deleted!");
        } catch (err) {
            console.error('Failed to delete the policy: ', err)
            toast.error("Erorr, something went wrong!");
        }
        dispatch(openPolicyForm(false));
    }

    return ( 
        <Container maxWidth="md">

            <Typography my={3} variant="h5" component="div" color="text.primary" textAlign="center" fontWeight="bold">
                Delete Policy?
            </Typography>

            <Typography my={3} component="div" color="text.primary" textAlign="center" fontWeight="400">
                Are you sure you want to delete this policy?
            </Typography>

            <div style={{ display: 'flex', justifyContent: 'center', marginTop: "1rem" }}>
                <Button onClick={() => dispatch(openPolicyForm(false))} style={{margin: '0.5rem', width: "10rem"}} fullWidth variant="contained">No</Button>
                <Button onClick={onDeleteConfirm} style={{margin: '0.5rem', width: "10rem"}} fullWidth variant="contained">Yes</Button>
            </div>
        
        </Container>
    );
}

export default DeletePolicy;