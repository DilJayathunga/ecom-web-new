/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 29/8/2022
 */

import { TextField, Typography } from '@mui/material';
import styles from '../../styles/util.module.css';

const ViewPolicy = () => {

    return (
        <>
            <Typography my={3} variant="h5" textAlign="center" fontWeight="bold">
                Policy Details
            </Typography>

            <div className={styles.formItem}>
                <label className={styles.formLabel}>Organization:</label>
                <TextField size="small" fullWidth className={styles.formText} disabled/>
            </div>
            <div className={styles.formItem}>
                <label className={styles.formLabel}>Policy Type:</label>
                <TextField size="small" fullWidth className={styles.formText} disabled/>
            </div>
            <div className={styles.formItem}>
                <label className={styles.formLabel}>Name:</label>
                <TextField size="small" fullWidth className={styles.formText} disabled/>
            </div>
            <div className={styles.formItem}>
                <label className={styles.formLabel}>Allowed Days:</label>
                <TextField size="small" fullWidth className={styles.formText} disabled/>
            </div>
        </>
    )
}

export default ViewPolicy;
