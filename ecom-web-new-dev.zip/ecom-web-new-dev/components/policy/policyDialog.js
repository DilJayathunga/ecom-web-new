/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 26/8/2022
 */

import { useDispatch, useSelector } from "react-redux";
import { Dialog, DialogContent } from "@mui/material";
import { openPolicyForm } from "../../store/slices/policySlice";
import AddPolicy from "./addPolicy";
import EditPolicy from "./editPolicy";
import DeletePolicy from "./deletePolicy";

const PolicyDialog = () => {
    const dispatch = useDispatch();
    const policy = useSelector((state) => state.policy);
    
    let content;
    const deleteView = false
  
    if (policy.status === "add") {
      content = <AddPolicy/>;
    } else if (policy.status === "view") {
    //   content = <ViewPolicy/>;
    } else if (policy.status === "edit") {
      content = <EditPolicy/>;
    } else if (policy.status === "delete") {
      deleteView = true
      content = <DeletePolicy/>;
    } 
  
    return (
        <>
            <Dialog
                fullWidth={true}
                maxWidth={deleteView ? "xs" : "sm"}
                open={policy.policyPageOpen}
                onClose={() => dispatch(openPolicyForm(false))}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogContent>{content}</DialogContent>
            </Dialog>
        </>
    );
};
  
export default PolicyDialog;