


import React from "react";
import { useState } from "react";

import { ButtonGroup , IconButton, Pagination} from "@mui/material";
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';


function OrderTable(props) {


    return ( 
        <>
            <TableContainer sx={{height: '500px'}}>
                <Table stickyHeader aria-label="simple table" sx={{height: "max-content"}}>
                    <TableHead>
                        <TableRow>
                            <TableCell width={25}>Order Number</TableCell>
                            <TableCell width={50}>Order</TableCell>
                            <TableCell width={50}>Date</TableCell>
                            <TableCell align="right" width={25}>Price</TableCell>
                            <TableCell align="right" width={25}>Quantity</TableCell>
                            <TableCell align="right" width={50}>Status</TableCell>
                            <TableCell align="right" width={50}>Payment Method</TableCell>
                            <TableCell align="center" width={'5%'}></TableCell>
                        </TableRow>
                    </TableHead>
                    {/* <TableBody>
                        {_DATA.currentData().map(function(order) {
                            const dateCreated = new Date(order.dateCreated);
                            var date = ('0'+ dateCreated.getDate()) + '-' + ('0'+(dateCreated.getMonth()+1)) + '-' + dateCreated.getFullYear();
                            return(
                            <TableRow sx={{height: '30px'}}>
                                <TableCell component="th" scope="row" sx={{borderBottom: "none", fontWeight: 'bold'}}>
                                    #{order.orderHeadId}
                                </TableCell>
                                <TableCell sx={{borderBottom: "none"}}>{order.title}</TableCell>
                                <TableCell sx={{borderBottom: "none"}}>{date}</TableCell>
                                <TableCell align="right" sx={{borderBottom: "none"}}>{order.totalAmount}</TableCell>
                                <TableCell align="right" sx={{borderBottom: "none"}}>{order.quantity}</TableCell>
                                <TableCell align="right" sx={{borderBottom: "none"}}>{order.remark}</TableCell>
                                <TableCell align="right" sx={{borderBottom: "none"}}>{order.paymentMethod}</TableCell>
                                <TableCell align="center" sx={{borderBottom: "none", width: '10%', height: 'auto !important'}}>
                                    <ButtonGroup variant="text" aria-label="text button group">
                                        <IconButton aria-label="view" onClick={() => {handleViewClick(order.orderHeadId)}}>
                                            <Visibility />
                                        </IconButton>
                                    </ButtonGroup>
                                </TableCell>
                            </TableRow>
                            );
                        })}
                    </TableBody> */}
                </Table>            
            </TableContainer>

        </>
    );
}

export default OrderTable;