import { Edit } from "@mui/icons-material";
import { Avatar, Badge, Button, Container, OutlinedInput, TextField, Typography } from "@mui/material";

import { useSelector, useDispatch } from "react-redux";
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from "yup";
import styles from '../../styles/profile.module.css';

import { toast } from 'react-toastify';
import { useForm } from "react-hook-form";
import { useEffect, useState } from "react";

// import { openProfileEditForm } from "../../../../Redux/siteAttributesSlice";
// import { useGetUserByIdQuery } from "../../../../Redux/services/userService";
// import { useUpdateUserMutation } from "../../../../Redux/services/userService";


// const useStyles = makeStyles({
//   avatar: {
//     width :'110px',
//     height: '110px',
//     border: 'solid 1px #707070',
//   },
//   formItem: {
//     display: "flex",
//     justifyContent: "center",
//     marginTop: "30px",
//   },
//   formText: {
//     width: "100%"
//   },
// });

const schema = yup.object({
  userName: yup.string().trim().required(),
  customerFirstName: yup.string().trim().required(),
  customerLastName: yup.string().trim().required(),
  custAdd1: yup.string().trim().required(),
  custAdd2: yup.string().trim().required(),
  custAdd3: yup.string().trim().required(),
  custAdd4: yup.string().trim().required(),
  customerMobile: yup.string().trim().required(),
}).required()

const EditProfile = () => {

  // Form submit...
  const { register, handleSubmit, reset, formState:{ errors } } = useForm({
    resolver: yupResolver(schema)
  });

  // const [data, setData] = useState([])
  // console.log(data)

  const dispatch = useDispatch();
  
  // const [updateUser, {isLoading}] = useUpdateUserMutation();

  const onFormSubmit = async (data) => {
    console.log(data);
    const dataSet = {
      userId: user.userId,
      ...data
    }
    console.log(dataSet);

      // try {
      //   const userUpdate = await updateUser(dataSet).unwrap();
      //   toast.success("Item successfully updated!");
      // } catch (err) {
      //   console.error('Failed to edit user details: ', err)
      //   toast.error("Erorr, something went wrong!");
      // }
    dispatch(openProfileEditForm(false))
  }

  //API Connection to get data...
  const siteAttributes = useSelector((state) => state.siteAttributes);

  // const {
  //     data: userDetails,
  //     isLoading: userLoading,
  //     isSuccess,
  //     isError,
  //     error
  // } = useGetUserByIdQuery();

  let user = {};

  // if(isLoading){
  //     // content = <div>Loading...</div>
  // }else if(isSuccess){
  //     user = userDetails.cutomers[0];
      
  // }else if(isError){
  //     // content = <div>{error}</div>
  // }

  useEffect(() => {
    reset({
      userName: user.userName, 
      customerFirstName: user.customerFirstName, 
      customerLastName: user.customerLastName,
      custAdd1: user.custAdd1,
      custAdd2: user.custAdd2,
      custAdd3: user.custAdd3,
      custAdd4: user.custAdd4,
      customerMobile: user.mobileNumber,
    });
  }, [user, reset]);

  return (
    <>            
      <Container sx={{justifyContent: 'center', display: 'flex'}}>
          <Badge
            color="success"
            overlap="circular" 
            badgeContent={<Edit sx={{width: '10px', height: '10px'}}/>}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'right',
            }}>
            <Avatar 
              style={{
                width :'110px',
                height: '110px',
                border: 'solid 1px #707070',
                
              }}
              src={'https://familywing.com/wp-content/uploads/2019/09/no-image-baby.png'}
            /> 
          </Badge>
      </Container>

      <form onSubmit={handleSubmit(onFormSubmit)}>

        {/* User Name */}
        <div className={styles.formItem}>
          <TextField {...register("userName")} style={{marginTop:40, width:"100%"}} className={styles.formText} label="User Name" size="small" error={!!errors.userName}/>
        </div>

        {/* First Name */}
        <div className={styles.formItem}>
          <TextField {...register("customerFirstName")} style={{marginTop:10, width:"100%"}} className={styles.formText} label="First Name" size="small" error={!!errors.customerFirstName}/>
        </div>

        {/* Last Name */}
        <div className={styles.formItem}>
          <TextField {...register("customerLastName")} style={{marginTop:10, width:"100%"}} className={styles.formText} size="small" label="Last Name" error={!!errors.customerLastName}/>
        </div>

        {/* Address Line */}
        <div className={styles.formItem}>
          <TextField {...register("custAdd1")} style={{marginTop:10, width:"100%"}} className={styles.formText} size="small" label="Address Line" error={!!errors.custAdd1}/>
        </div>

        {/* Address Line 2 */}
        <div className={styles.formItem}>
          <TextField {...register("custAdd2")} style={{marginTop:10, width:"100%"}} className={styles.formText} size="small" label="Address Line 2" error={!!errors.custAdd2} />
        </div>

        {/* City */}
        <div className={styles.formItem}>
          <TextField {...register("custAdd3")} style={{marginTop:10, width:"100%"}} className={styles.formText} size="small" label="City" error={!!errors.custAdd3} />
        </div>

        {/* State */}
        <div className={styles.formItem}>
          <TextField {...register("custAdd4")}  style={{marginTop:10, width:"100%"}}className={styles.formText} size="small" label="State" error={!!errors.custAdd4} />
        </div>

        {/* Zip Code */}
        {/* <div className={styles.formItem}>
          <TextField {...register("zipCode")} className={styles.formText} size="small" label="Zip Code" error={!!errors.zipCode} />
        </div> */}

        {/* Phone Number */}
        <div className={styles.formItem}>
          <TextField {...register("customerMobile")} style={{marginTop:10, width:"100%"}} className={styles.formText} size="small" label="Phone Number" error={!!errors.mobileNumber} />
        </div>

        {/* save button */}
        <div style={{textAlign:'center', marginTop:30}} className={styles.formItem}>
          <Button type="submit" variant="contained">Save</Button>
        </div>
                
      </form>
    </>
  )
}

export default EditProfile;
