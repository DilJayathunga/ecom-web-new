/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 12/8/2022
 */

import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";

import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import { ArrowBackIos, Edit } from "@mui/icons-material";
import { Grid } from "@mui/material";
import { openProfileEditForm } from "../../store/slices/profileSlice";
import EditProfile from "./editProfile";
import styles from '../../styles/profile.module.css';

const ProfileDialog = () => {
  const dispatch = useDispatch();
  const profile = useSelector((state) => state.profile);

  return (
    <>
      <Dialog
        fullWidth={true}
        maxWidth={"md"}
        open={profile.profileEditPageOpen}
        onClose={() => dispatch(openProfileEditForm(false))}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >

        <DialogContent>
          <Grid container xs={12}>
            <Grid item xs={2}>
              <Button onClick={() => dispatch(openProfileEditForm(false))}>
                <ArrowBackIos sx={{width: '20px', height: '20px', color: '#707070'}}/>
                <Typography sx={{textTransform: 'none', color: '#707070'}}>Overview</Typography>
              </Button>
            </Grid>
            <Grid item xs={8} justifyContent='center'>
              <EditProfile />
            </Grid>
            <Grid item xs={2}/>
          </Grid>
                
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ProfileDialog;