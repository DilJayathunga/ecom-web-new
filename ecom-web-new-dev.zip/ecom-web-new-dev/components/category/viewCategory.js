/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 12/7/2022
 */

import { Backdrop, CircularProgress, Container, List, ListItem, OutlinedInput, Table, TableBody, TableCell, TableHead, TableRow, Typography } from "@mui/material"
import { useDispatch, useSelector } from "react-redux";
import { openCategoryForm } from "../../store/slices/categorySlice";
import { useGetCategoryByIdQuery } from "../../store/services/categoryService";

const ViewCategory = () => {

    const dispatch = useDispatch();
    const category = useSelector((state) => state.category);

    const { data: catDetails, isSuccess: catSuccess, isLoading: catLoading } = useGetCategoryByIdQuery(category.selectedCategory);
    
    let catData = {}

    if(catSuccess) {
        catData = catDetails.category
    }

    console.log(catData)

    return(
        <Container maxWidth="md">

            {catLoading && (
                <Backdrop
                    sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
                    open={catLoading}
                >
                    <CircularProgress color="inherit" />
                </Backdrop>
            )}
            
            {/* topic */}
            <Typography my={3} variant="h5" component="div" color="text.primary" textAlign="center" fontWeight="bold">
                Category Details
            </Typography>

            <div style={{marginTop: "1rem"}}>
                <label style={{fontWeight: 600}}>Organization:</label>
                <OutlinedInput style={{marginTop: "0.3rem"}} size="small" fullWidth disabled='true' value={catData.orgName}/>
            </div>

            <div style={{marginTop: "1rem"}}>
                <label style={{fontWeight: 600}}>Category Name:</label>
                <OutlinedInput style={{marginTop: "0.3rem"}} size="small" fullWidth disabled='true' value={catData.catName}/>
            </div>

            <div style={{marginTop: "1rem"}}>
                <label style={{fontWeight: 600}}>Category Dispaly Name:</label>
                <OutlinedInput style={{marginTop: "0.3rem"}} size="small" fullWidth disabled='true' value={catData.catDisplayName}/>
            </div>

            {(catData.catParent !== -1) ? (
                <div style={{marginTop: "1rem"}}>
                    <label style={{fontWeight: 600}}>Parent Category:</label>
                    <OutlinedInput style={{marginTop: "0.3rem"}} size="small" fullWidth disabled='true' value={catData.parentName}/>
                </div>
            ) : null}

        {/* Attributes Table */}

            {(catData.attributes?.length!==0 )? (          
            <div style={{marginTop: "1rem"}}>
                <label style={{fontWeight: 600}}>Attributes:</label>
                <div style={{borderStyle: 'solid', borderColor: '#c1c1c1', borderWidth: '1px', marginTop: '1rem', padding: '0.5rem'}}>
                    <Table>
                        <TableHead>                
                            <TableCell align="center" width={50}>Index</TableCell>
                            <TableCell align="center" width={200}>Name</TableCell>
                            <TableCell align="center" width={50}>Is mandatory</TableCell>                
                        </TableHead>
                        <TableBody>
                            {catData.attributes?.map((attr) =>{
                                console.log()
                                return (
                                    <TableRow key={attr.attributeIndex}>
                                        <TableCell align="center">
                                            {attr.attributeIndex}
                                        </TableCell>
                                        <TableCell align="center">
                                            {attr.attributeName}
                                        </TableCell>
                                        <TableCell align="center">
                                            {attr.mandatory === true ? 'Yes' : 'No'}
                                        </TableCell>
                                    </TableRow>
                                );
                            })}
                        </TableBody>
                    </Table>
                </div>
            </div>
            ) : null}

        {/* Variants Table */}

            {(catData.variants?.length!==0)? (          
            <div style={{marginTop: "1rem"}}>
                <label style={{fontWeight: 600}}>Variants:</label>
                
                <div style={{borderStyle: 'solid', borderColor: '#c1c1c1', borderWidth: '1px', marginTop: '1rem', padding: '0.5rem'}}>                       
                    <Table>
                        <TableHead>                
                            <TableCell align="center" width={100}>Name</TableCell>
                            <TableCell align="center" width={100}>Picker Type</TableCell>               
                            <TableCell align="center" width={'40%'}>Variant Values</TableCell>               
                        </TableHead>
                        <TableBody>
                            {catData?.variants?.map((variant, index) => {
                                return (
                                    <TableRow key={index}>
                                        <TableCell style={{padding: '0'}} align="center">
                                            {variant.catVar}
                                        </TableCell>
                                        <TableCell style={{padding: '0'}}  align="center">
                                            {variant.pickerType}
                                        </TableCell>
                                        <TableCell style={{padding: '0'}}  align="right">
                                            {variant?.variantValues.map((value) => {
                                                return (        
                                                    <List key={value.variantValId} style={{paddingLeft: '6rem'}}>
                                                        <ListItem>{value.variantValue}</ListItem>
                                                    </List>
                                                );
                                            })}                                            
                                        </TableCell>
                                    </TableRow>
                                );
                            })}
                        </TableBody>
                    </Table>
                </div>
            </div>
            ) : null}

        </Container>
    );
}

export default ViewCategory