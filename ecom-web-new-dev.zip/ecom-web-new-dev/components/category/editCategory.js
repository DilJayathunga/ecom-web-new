/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 14/7/2022
 */

import { Backdrop, Button, CircularProgress, FormControl, InputLabel, MenuItem, OutlinedInput, Select, Typography } from "@mui/material";
import { Container } from "@mui/system";
import { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { FormProvider, useForm } from "react-hook-form";
import { useGetAllCategoriesQuery, useGetCategoryByIdQuery, useUpdateCategoryMutation } from "../../store/services/categoryService";
import { useGetOrganizationsQuery } from "../../store/services/orgService";
import AttributeTable from "./attributeTable";
import VariantsTable from "./variantsTable";
import { openCategoryForm } from "../../store/slices/categorySlice";

import { toast } from "react-toastify";
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';

const schema = yup.object().shape({
    orgId: yup.string().required(),
    catName: yup.string().required(),
    catDisplayName: yup.string().required(),
    attributes: yup.array().of(
        yup.object().shape({
            attributeIndex: yup.string().required(),
            attributeName: yup.string().required()
        }).required()
    ),
    variants: yup.array().of(
        yup.object().shape({
            catVar: yup.string().required(),
            pickerType: yup.string().required(),
            variantValues: yup.array().of(
                // yup.string().required()
                yup.object().shape({
                    variantValue: yup.string().required()
                }).required()
            ).required()
        }).required()
    )
}).required()

const EditCategory = () => {

    const dispatch = useDispatch();
    const category = useSelector((state) => state.category);

    const [deletedAttributes, setDeletedAttributes] = useState([]);
    const [deletedVariants, setDeletedVariants] = useState([]);
    const [deletedVariantValues, setDeletedVariantValues] = useState([]);
    
    let catData = useMemo(() => {
        return({attributes: [], variants: []})
    }, []);   
    
    // Form Validation
    const methods = useForm({
        resolver: yupResolver(schema),
        defaultValues: {
            attributes: catData.attributes,
            variants: catData.variants
        }
    });
    
    let parentContent, orgContent

    const { data: patentCat, isSuccess: parentSuccess, isLoading: parentLoading } = useGetAllCategoriesQuery();
    const { data: Organizations, isSuccess: orgSuccess, isLoading: orgLoading } = useGetOrganizationsQuery();
    const { data: catDetails, isSuccess: catSuccess, isLoading: catLoading } = useGetCategoryByIdQuery(category.selectedCategory);

    console.log('category API---------------->',catDetails)
    if(catSuccess) {
        catData = catDetails.category
        console.log(catDetails)

        if(orgSuccess){
            orgContent = <FormControl fullWidth>
                            <Select 
                                {...methods.register("orgId")} 
                                style={{marginTop: "0.3rem"}} 
                                onChange={(e) => methods.setValue('orgId', e.target.value, { shouldValidate: true })}
                                defaultValue={catData.orgId}
                                size="small" fullWidth>
                                {Organizations.list?.map((org) => (
                                    <MenuItem key={org.orgId} value={org.orgId}>{org.orgName}</MenuItem>
                                ))}
                            </Select> 
                        </FormControl> 
        } 

        if(parentSuccess){
            console.log(methods.getValues('catParent'))
            // console.log(patentCat)
            parentContent = <Select 
                                    {...methods.register("catParent")} 
                                    style={{marginTop: "0.3rem"}} 
                                    onChange={(e) => methods.setValue('catParent', e.target.value)}
                                    defaultValue={catData.catParent}
                                    // defaultValue='-1'
                                    size="small" 
                                    fullWidth
                                >
                                    <MenuItem value="-1">No Parent Category</MenuItem>
                                    {patentCat.list?.map((cat) => (
                                        <MenuItem key={cat.catId} value={cat.catId}>{cat.catDisplayName}</MenuItem>
                                    ))}
                                </Select>
        }
    }
    
    useEffect(() => {
        methods.reset({
            orgId: catData.orgId,
            catName: catData.catName,
            catDisplayName: catData.catDisplayName,
            catParent: catData.catParent,
            attributes: catData.attributes,
            variants: catData.variants
        });
    }, [catData, methods]);

    const [updateCategory, { isLoading }] = useUpdateCategoryMutation();

    const onCategorySubmit = async (data) => {
        console.log('called............!')
        const dataSet = {
            catId: catData.catId,
            ...data,
            deleted: {
                attributes: deletedAttributes,
                variants: deletedVariants,
                variantValues: deletedVariantValues
            }
        }
        console.log('category form data: ', dataSet)

        try {
            const updateCat = await updateCategory(dataSet).unwrap();
            console.log("add item", updateCat);
            toast.success("Category successfully updated!");
        } catch (err) {
            console.error("Failed to save the item: ", err);
            toast.error("Erorr, something went wrong!");
        }

        dispatch(openCategoryForm(false));
    }

    return (
        <Container maxWidth="md">
            {catLoading && orgLoading && parentLoading && (
                <Backdrop
                    sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
                    open={catLoading && orgLoading && parentLoading}
                >
                    <CircularProgress color="inherit" />
                </Backdrop>
            )}
            <FormProvider {...methods}>
                <form onSubmit={methods.handleSubmit(onCategorySubmit)}>
                    {/* topic */}
                    <Typography my={3} variant="h5" component="div" color="text.primary" textAlign="center" fontWeight="bold">
                        Edit Category 
                    </Typography>

                    <div style={{marginTop: "1rem"}}>
                        <label style={{fontWeight: 600}}>Organization:</label>
                        {methods.formState.errors.orgId && methods.formState.errors.orgId.type === "required" && <span style={{color: 'red'}}> *</span>}
                        {orgContent}
                    </div>

                    <div style={{marginTop: "1rem"}}>
                        <label style={{fontWeight: 600}}>Name:</label>
                        {methods.formState.errors.catName && methods.formState.errors.catName.type === "required" && <span style={{color: 'red'}}> *</span>}
                        <OutlinedInput
                            {...methods.register("catName")}
                            style={{marginTop: "0.3rem"}}
                            placeholder="Enter Category Name"
                            size="small"
                            fullWidth
                        />
                    </div>

                    <div style={{marginTop: "1rem"}}>
                        <label style={{fontWeight: 600}}>Dispaly Name:</label>
                        {methods.formState.errors.catDisplayName && methods.formState.errors.catDisplayName.type === "required" && <span style={{color: 'red'}}> *</span>}
                        <OutlinedInput
                            {...methods.register("catDisplayName")}
                            style={{marginTop: "0.3rem"}}
                            placeholder="Enter Display Name"
                            size="small"
                            fullWidth
                        />
                    </div>

                    <div style={{marginTop: "1rem"}}>
                        <label style={{fontWeight: 600}}>Parent Category:</label>
                        {parentContent}
                    </div>

                    <div style={{marginTop: "1rem"}}>
                        <label style={{fontWeight: 600}}>Attributes:</label>
                        <hr />
                        <AttributeTable from="edit" deletedAttributes={deletedAttributes} setDeletedAttributes={setDeletedAttributes} />
                    </div>

                    <div style={{marginTop: "1rem"}}>
                        <label style={{fontWeight: 600}}>variants:</label>
                        <hr />
                        <VariantsTable from="edit" deletedVar={deletedVariants} setDeletedVar={setDeletedVariants} varVal={deletedVariantValues} setVarVal={setDeletedVariantValues} />
                        {/* {(variants.length === 0)?(<hr />):null} */}
                    </div>

                    {/* Submit Button */}
                    <div style={{ marginTop: "2rem", marginBottom: '1rem', display: 'flex', justifyContent: 'center' }}>
                        <Button type="submit" style={{width: "10rem"}} variant="contained">Save</Button>
                    </div>
                </form>
            </FormProvider>
        </Container>
    );
}


const catData1 ={
    "orgId": 1,    
    "catName": "Dresses",    
    "catDisplayName": "Dresses",    
    "catParent": 15,    
    "attributes": [    
        {    
            "attributeIndex": 1,    
            "attributeName": "color",    
            "mandatory": true    
        },    
        {    
            "attributeIndex": 2,    
            "attributeName": "size",    
            "mandatory": false   
        }    
    ],    
    "variants": [    
        {    
            "catVar": "color",    
            "pickerType": "color",    
            "variantValues": [    
                "red",    
                "blue",    
                "green"    
            ]    
        },    
        {    
            "catVar": "size",    
            "pickerType": "text",    
            "variantValues": [    
                "small",    
                "large",    
                "medium"    
            ]    
        }    
    ]    
}


export default EditCategory;