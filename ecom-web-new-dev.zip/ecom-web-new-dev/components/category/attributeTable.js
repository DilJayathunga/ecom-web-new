/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 5/7/2022
 */

import { Delete } from "@mui/icons-material";
import { Button, Checkbox, IconButton,  OutlinedInput, Table, TableBody, TableCell, TableHead, TableRow } from "@mui/material";
import { useFormContext, useFieldArray } from "react-hook-form";

const AttributeTable = (props) => {
    const { from, deletedAttributes, setDeletedAttributes } = props;

    // const {attributeData} = props;
    // console.log(attributeData)
    const { register, control, formState: { errors }, getValues, setValue } = useFormContext();

    const { fields, append, remove, replace } = useFieldArray({
        control,
        name: "attributes"
    });

    const deleteRow = (item, index) => {
        if (from === "edit") {
            let attr = item.attributeId
            // console.log(attr)
            setDeletedAttributes([...deletedAttributes, attr])            
        }   
        remove(index);     
    }

    return(
        <Table>
            {(fields.length !== 0)?
                (
            <TableHead>                
                <TableCell align="center" width={50}>Index</TableCell>
                <TableCell align="center" width={200}>Name</TableCell>
                <TableCell align="center" width={50}>Is Mandatory</TableCell>
                <TableCell align="center" width={'25%'}>
                    {/* {attributeIndex || attributeName ? 
                    ( */}
                        <Button type="button" variant="contained" onClick={() => append({ attributeIndex: '', attributeName: '', mandatory: false })}>Add Attribute</Button>
                    {/* ) : <Button type="button" variant="contained" dissabled>Add Attribute</Button>} */}
                </TableCell>
            </TableHead>):(              
                <div style={{borderBottom: "none", display: 'flex', justifyContent: 'right'}}>
                    <Button type="button" variant="contained" onClick={() => append({ attributeIndex: '', attributeName: '', mandatory: false })}>Add Attribute</Button>
                </div>
            )}
            <TableBody>
                {fields.map((item, index) =>{
                    return( 
                        <TableRow key={item.id}>
                            <TableCell align="center">
                                {errors.attributes?.[index]?.attributeIndex && <span style={{color: 'red'}}> * </span>}
                                <OutlinedInput
                                    {...register(`attributes.${index}.attributeIndex`, {required: true})}
                                    placeholder="Index"
                                    defaultValue={item.attributeIndex}
                                    // fullWidth
                                    size="small"
                                    style={{width: '4.5rem'}}
                                    align="right"
                                />
                            </TableCell>
                            <TableCell align="center">
                                {errors.attributes?.[index]?.attributeName && <span style={{color: 'red'}}> * </span>}
                                <OutlinedInput 
                                    {...register(`attributes.${index}.attributeName`, {required: true})}
                                    placeholder="Attribute Name"  
                                    defaultValue={item.attributeName}
                                    // fullWidth
                                    size="small" 
                                    // control={control}
                                />
                            </TableCell>
                            <TableCell align="center">
                                <Checkbox 
                                    {...register(`attributes.${index}.mandatory`)}
                                    value={'true'}
                                    defaultChecked={item.mandatory}
                                    size="medium"
                                />
                            </TableCell>
                            <TableCell align="center">
                                <IconButton type="button" onClick={() => deleteRow(item, index)}>
                                    <Delete/>
                                </IconButton>
                            </TableCell>
                        </TableRow>
                    );
                })}
                                
            </TableBody>
            {(fields.length === 0)?(<hr />):null}

        </Table>
    );
}

export default AttributeTable;