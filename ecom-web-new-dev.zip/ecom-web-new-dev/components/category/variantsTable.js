/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 8/7/2022
 */


import { Delete } from "@mui/icons-material";
import { Button, IconButton, OutlinedInput, Table, TableBody, TableCell, TableHead, TableRow } from "@mui/material";
import { useState } from "react";
import VariantValuesTable from "./variantValuesTable";
import { useFormContext, useFieldArray } from "react-hook-form";

const VariantsTable = (props) => {

    const { from, deletedVar, setDeletedVar, varVal, setVarVal } = props;

    const { register, control, formState: { errors } } = useFormContext();
    
    const { fields, append, remove } = useFieldArray({
        // control,
        name: "variants"
    });

    const deleteVariant = (item, index) => {
        if (from === "edit") {
            let variant = item.variantId
            // console.log(attr)
            setDeletedVar([...deletedVar, variant])            
        }  
        remove(index)
    }   

    return(
        <>
            <Table>
                {(fields.length !== 0)?
                    (
                <TableHead>                
                    <TableCell align="center" width={100}>Name</TableCell>
                    <TableCell align="center" width={100}>Picker Type</TableCell>
                    <TableCell align="center" width={'25%'}>
                        <Button type="button" variant="contained" onClick={() => append({ catVar: '', pickerType: '', variantValues: [] })}>Add Variant</Button>
                    </TableCell>
                </TableHead>):(              
                    <div style={{borderBottom: "none", display: 'flex', justifyContent: 'right'}}>
                        <Button type="button" variant="contained" onClick={() => append({ catVar: '', pickerType: '', variantValues: [] })}>Add Variant</Button>
                    </div>
                )}
                <TableBody>
                    {fields?.map((variant, index) =>{
                        return (
                            <>
                            <TableRow key={variant.id}>
                                <TableCell style={{borderBottom: "none"}} align="center">
                                    {errors.variants?.[index]?.catVar && <span style={{color: 'red'}}> * </span>}
                                    <OutlinedInput
                                        {...register(`variants.${index}.catVar`)}
                                        placeholder="Variant Name"
                                        defaultValue={variant.catVar}
                                        size="small"
                                    />
                                </TableCell>
                                <TableCell style={{borderBottom: "none"}} align="center">
                                    {errors.variants?.[index]?.pickerType && <span style={{color: 'red'}}> * </span>}
                                    <OutlinedInput 
                                        {...register(`variants.${index}.pickerType`)}
                                        placeholder="Picker Type"   
                                        defaultValue={variant.pickerType}
                                        size="small" 
                                    />
                                </TableCell>
                                <TableCell style={{borderBottom: "none"}} align="center">
                                    {/* <div style={{display: 'flex', flexDirection:'row'}}> */}
                                        <IconButton type="button" onClick={() => deleteVariant(variant, index)}>
                                            <Delete/>
                                        </IconButton>
                                        
                                    {/* </div> */}
                                </TableCell>
                                
                            </TableRow>
                            <VariantValuesTable 
                                variantIndex={index} 
                                from={from} 
                                deletedVal={varVal} 
                                setDeletedVal={setVarVal} 
                                {...{ control, register, errors}} 
                            />
                                
                            </>
                        );
                    })}
                                    
                </TableBody>
                {(fields.length === 0)?(<hr />):null}
            </Table>
        </>
    );
}

export default VariantsTable;