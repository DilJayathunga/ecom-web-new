/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 14/7/2022
 */

import { Button, Container, Typography } from "@mui/material";
import { openCategoryForm } from "../../store/slices/categorySlice";
import { useSelector, useDispatch } from "react-redux";
import { useDeleteCategoryMutation } from "../../store/services/categoryService";
import { toast } from "react-toastify";

const DeleteCategory = () => {

    const dispatch = useDispatch();
    const category = useSelector((state) => state.category);

    const [deleteCat, { isLoading }] = useDeleteCategoryMutation();

    const onDeleteConfirm = async () => {
        console.log('Deleted...', category.selectedCategory);
        const id = category.selectedCategory;
        try {
            const deletedCat = await deleteCat(id).unwrap();
            console.log('deleted category', deletedCat)
            toast.success("Category successfully deleted!");
        } catch (err) {
            console.error('Failed to delete the category: ', err)
            toast.error("Erorr, something went wrong!");
        }
        dispatch(openCategoryForm(false));
    }

    return ( 
        <Container maxWidth="md">

            <Typography my={3} variant="h5" component="div" color="text.primary" textAlign="center" fontWeight="bold">
                Delete Category?
            </Typography>

            <Typography my={3} component="div" color="text.primary" textAlign="center" fontWeight="400">
                Are you sure you want to delete this category?
            </Typography>

            <div style={{ display: 'flex', justifyContent: 'center', marginTop: "1rem" }}>
                <Button onClick={() => dispatch(openCategoryForm(false))} style={{margin: '0.5rem', width: "10rem"}} fullWidth variant="contained">No</Button>
                <Button onClick={onDeleteConfirm} style={{margin: '0.5rem', width: "10rem"}} fullWidth variant="contained">Yes</Button>
            </div>
        
        </Container>
    );
}

export default DeleteCategory