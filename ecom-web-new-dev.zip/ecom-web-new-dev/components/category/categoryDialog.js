/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 4/7/2022
 */

import { useDispatch, useSelector } from "react-redux";
import { openCategoryForm } from "../../store/slices/categorySlice";
import { Dialog, DialogContent } from "@mui/material";
import { AddCategory } from "./addCategory";
import ViewCategory from "./viewCategory";
import EditCategory from "./editCategory";
import DeleteCategory from "./deleteCategory";

const CategoryDialog = () => {
    const dispatch = useDispatch();
    const category = useSelector((state) => state.category);
    
    let content;
    const deleteView = false
  
    if (category.status === "add") {
      content = <AddCategory/>;
    } else if (category.status === "view") {
      content = <ViewCategory/>;
    } else if (category.status === "edit") {
      content = <EditCategory/>;
    } else if (category.status === "delete") {
      deleteView = true
      content = <DeleteCategory/>;
    } 
  
    return (
      <>
        <Dialog
          fullWidth={true}
          maxWidth={deleteView ? "xs" : "md"}
          open={category.CategoryPageOpen}
          onClose={() => dispatch(openCategoryForm(false))}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogContent>{content}</DialogContent>
        </Dialog>
      </>
    );
  };
  
  export default CategoryDialog;