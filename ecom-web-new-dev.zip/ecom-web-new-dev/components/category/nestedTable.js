/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 7/7/2022
 */

import { Delete, Edit, ExpandLess, ExpandMore, GirlSharp, Visibility } from "@mui/icons-material";
import { Backdrop, ButtonGroup, CircularProgress, Collapse, IconButton, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from "@mui/material";
import { Container } from "@mui/system";
import { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useGetAllCatWithSubCatQuery } from "../../store/services/categoryService";
import { openCategoryForm, setStatus, setSelectedCategory } from "../../store/slices/categorySlice";





function RenderSubNode (props){

    const {nodes} = props
    const {level} = props
    const [expand, setExpand] = useState(true)
    
    const dispatch = useDispatch();

    let space = 30 * level;

    const handleViewClick = (id) => {
        dispatch(openCategoryForm(true)); 
        dispatch(setSelectedCategory(id)); 
        dispatch(setStatus('view'))
    };

    const handleEditClick = (id) => {
        dispatch(openCategoryForm(true)); 
        dispatch(setSelectedCategory(id)); 
        dispatch(setStatus('edit'))
    };

    const handleDeleteClick = (id) => {
        dispatch(openCategoryForm(true)); 
        dispatch(setSelectedCategory(id)); 
        dispatch(setStatus('delete'))
    };

    return (
        <>           
            <TableRow  style={{display: 'flex', justifyContent: 'space-between'}}>
                {
                    (nodes.subCategoryList && Array.isArray(nodes.subCategoryList))? (
                        <TableCell style={{paddingLeft: `${space}px`, borderBottom: 'none', display: 'flex', alignItems: 'center'}}>
                            <IconButton onClick={() => setExpand(!expand)}>
                                {expand ? <ExpandLess/> : <ExpandMore/>}
                            </IconButton>
                            {nodes.catDisplayName}
                        </TableCell>
                    ): (<TableCell style={{paddingLeft: `${space+40}px`, borderBottom: 'none', display: 'flex', alignItems: 'center'}}>{nodes.catDisplayName}</TableCell>)
                }
                <TableCell style={{paddingLeft: `${500-space+ 40}px`, borderBottom: 'none'}}>
                    <ButtonGroup>
                        <IconButton onClick={() => {handleViewClick(nodes.catId)}}>
                            <Visibility/>
                        </IconButton>
                        <IconButton onClick={() => {handleEditClick(nodes.catId)}}>
                            <Edit/>
                        </IconButton>
                        <IconButton onClick={() => {handleDeleteClick(nodes.catId)}}>
                            <Delete/>
                        </IconButton>
                    </ButtonGroup>
                </TableCell>
                
                
            </TableRow>
            <hr style={{borderTop: '0.1px solid #e0e0e0'}}/>
            <Collapse in={expand} timeout="auto" unmountOnExit>

                {/* <TableRow> */}
                    {nodes.subCategoryList && Array.isArray(nodes.subCategoryList)
                        ? nodes.subCategoryList.map((node) => <RenderSubNode key={node.catId} nodes={node} level={level+1}/>)
                        : null}
                {/* </TableRow> */}
            </Collapse>

                    
        </>
    );
};


const NestedTable = () => {

    const { data: categories, isLoading: catLoading } = useGetAllCatWithSubCatQuery();


    // console.log(categories, "catergory")
    
    const [level, setLevel] = useState(1)
    
    return(
        <>
            {catLoading && (
                <Backdrop
                    sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
                    open={catLoading}
                >
                    <CircularProgress color="inherit" />
                </Backdrop>
            )}
            <Container style={{padding: '50px 50px 50px 28px'}}>
                <TableContainer sx={{height: '500px', }}>
                    <Table sx={{height: "max-content", width: '100%', display: 'flex'}} size='small'>
                        {/* <TableHead>
                            <TableRow>
                                <TableCell style={{borderBottom: "none"}}></TableCell>
                                <TableCell width={50} style={{borderBottom: "none"}}></TableCell>
                                <TableCell  align="center" width={'50%'} style={{borderBottom: "none"}}></TableCell>
                            </TableRow>
                        </TableHead> */}
                        <TableBody>
                            {categories?.list[0].map((item) => <RenderSubNode key={item.catId} nodes={item} level={level}/>)}
                        </TableBody>
                    </Table>
                </TableContainer>
            </Container>
        </>
    );
}


export default NestedTable;