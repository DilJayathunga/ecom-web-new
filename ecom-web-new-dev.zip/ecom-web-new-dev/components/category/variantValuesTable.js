/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 8/7/2022
 */


import { Delete } from "@mui/icons-material";
import { Button, IconButton,  OutlinedInput, TableCell, TableRow } from "@mui/material";
import { useFieldArray } from "react-hook-form";

const VariantValuesTable = (props) => {

    const {variantIndex, register, errors, from, deletedVal, setDeletedVal} = props

    const { fields, remove, append } = useFieldArray({
        // control,
        name: `variants[${variantIndex}].variantValues`
    });

    const deleteValue = (item, k) => {
        if (from === "edit") {
            let val = item.variantValId
            console.log(item)
            setDeletedVal([...deletedVal, val])            
        }   
        remove(k)
    }

    return(
        <>
            <TableRow>
                <TableCell style={(fields.length !== 0) ? {padding: 0, borderBottom: "none"} : null}></TableCell>
                <TableCell style={(fields.length !== 0) ? {padding: 0, borderBottom: "none"} : null}></TableCell>
                <TableCell style={(fields.length !== 0) ? {padding: '0 0 0 50px', borderBottom: "none"} : {padding: '0 0 10px 50px'}}>
                    <Button type="button" variant="contained" onClick={() => append("")}>
                        Add Value
                    </Button>
                </TableCell>
            </TableRow>

            {fields.map((item, k) => {
                return(
                    <TableRow key={item.id}>
                        <TableCell style={(fields.length !== (k+1)) ? { borderBottom: "none"} : null} align="right">
                            {k+1}
                        </TableCell>
                        {from==="edit" ? (
                            <TableCell>
                                {errors.variants?.[variantIndex]?.variantValues?.[k]?.variantValue && <span style={{color: 'red'}}> * </span>}
                                <OutlinedInput 
                                    {...register(`variants[${variantIndex}].variantValues[${k}].variantValue`)}
                                    // fullWidth
                                    placeholder="Variant Value"   
                                    defaultValue={item.variantValue}
                                    size="small" 
                                />
                            </TableCell>
                        ) : ( 
                            <TableCell>
                                {errors.variants?.[variantIndex]?.variantValues?.[k] && <span style={{color: 'red'}}> * </span>}
                                <OutlinedInput 
                                    {...register(`variants[${variantIndex}].variantValues[${k}]`)}
                                    // fullWidth
                                    placeholder="Variant Value"   
                                    defaultValue={item.variantValues}
                                    size="small" 
                                />
                            </TableCell>
                        )}
                        <TableCell align="center">
                            <IconButton aria-label="delete" onClick={() => deleteValue(item, k)}>
                                <Delete/>
                            </IconButton>
                        </TableCell>
                    </TableRow>
                );
            })}
        </>
    );
}

export default VariantValuesTable;