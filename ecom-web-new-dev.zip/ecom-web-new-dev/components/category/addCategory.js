/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 4/7/2022
 */

import { Backdrop, Button, CircularProgress, FormControl, InputLabel, MenuItem, OutlinedInput, Select, Typography } from "@mui/material";
import { Container } from "@mui/system";
import { useState } from "react";
import { useDispatch } from "react-redux";
import { FormProvider, useForm } from "react-hook-form";
import { useCreateCategoryMutation, useGetAllCategoriesQuery } from "../../store/services/categoryService";
import { useGetOrganizationsQuery } from "../../store/services/orgService";
import AttributeTable from "./attributeTable";
import VariantsTable from "./variantsTable";
import { openCategoryForm } from "../../store/slices/categorySlice";

import { toast } from "react-toastify";
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';

const schema = yup.object().shape({
    orgId: yup.string().required(),
    catName: yup.string().required(),
    catDisplayName: yup.string().required(),
    attributes: yup.array().of(
        yup.object().shape({
            attributeIndex: yup.string().required(),
            attributeName: yup.string().required()
        }).required()
    ),
    variants: yup.array().of(
        yup.object().shape({
            catVar: yup.string().required(),
            pickerType: yup.string().required(),
            variantValues: yup.array().of(
                yup.string().required()
            ).required()
        }).required()
    )
}).required()

export const AddCategory = () => {

    const dispatch = useDispatch();
       
    // Form Validation
    const methods = useForm({
        resolver: yupResolver(schema)
    });

    // const [parentCategory, setParentCategory] = useState("");

    let parentContent, orgContent

    const { data: patentCat, isSuccess: catSuccess, isLoading: catLoading } = useGetAllCategoriesQuery();
    const { data: Organizations, isSuccess: orgSuccess, isLoading: orgLoading } = useGetOrganizationsQuery();

    if(catSuccess){
        console.log(methods.getValues('catParent'))
        // console.log(patentCat)
        parentContent = <Select 
                                {...methods.register("catParent")} 
                                style={{marginTop: "0.3rem"}} 
                                onChange={(e) => methods.setValue('catParent', e.target.value)}
                                defaultValue="-1" 
                                size="small" 
                                fullWidth
                            >
                                <MenuItem value="-1" style={{display: 'none'}}>Select Parent Category</MenuItem>
                                {patentCat.list?.map((cat) => (
                                    <MenuItem key={cat.catId} value={cat.catId}>{cat.catDisplayName}</MenuItem>
                                ))}
                            </Select>
    }
    

    if(orgSuccess){
        orgContent = <FormControl fullWidth>
                        <InputLabel shrink={false}>{methods.getValues('orgId') !== undefined ? '' : 'Select Organization'}</InputLabel>
                        <Select 
                            {...methods.register("orgId")} 
                            style={{marginTop: "0.3rem"}} 
                            onChange={(e) => methods.setValue('orgId', e.target.value, { shouldValidate: true })}
                            defaultValue="" size="small" fullWidth>
                        {Organizations.list?.map((org) => (
                            <MenuItem key={org.orgId} value={org.orgId}>{org.orgName}</MenuItem>
                        ))}
                    </Select> 
                </FormControl> 
    }    
    
    const [createCategory, {isLoading}] = useCreateCategoryMutation();
    
    const onCategorySubmit = async (data) => {
        console.log('category form data: ', JSON.stringify(data))
        try {
            const addItem = await createCategory(data).unwrap();
            console.log('add item', addItem)
            toast.success("Category successfully added!");
        } catch (err) {
            console.error('Failed to save the item: ', err)
            toast.error("Erorr, something went wrong!");
        }
        dispatch(openCategoryForm(false))
    }
                 
    return (
        <Container maxWidth="md">
            {catLoading && orgLoading && (
                <Backdrop
                    sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
                    open={catLoading && orgLoading}
                >
                    <CircularProgress color="inherit" />
                </Backdrop>
            )}
            <FormProvider {...methods}>
                <form onSubmit={methods.handleSubmit(onCategorySubmit)}>
                    {/* topic */}
                    <Typography my={3} variant="h5" component="div" color="text.primary" textAlign="center" fontWeight="bold">
                        Category Creation
                    </Typography>

                    <div style={{marginTop: "1rem"}}>
                        <label style={{fontWeight: 600}}>Organization:</label>
                        {methods.formState.errors.orgId && methods.formState.errors.orgId.type === "required" && <span style={{color: 'red'}}> *</span>}
                        {orgContent}
                    </div>

                    <div style={{marginTop: "1rem"}}>
                        <label style={{fontWeight: 600}}>Name:</label>
                        {methods.formState.errors.catName && methods.formState.errors.catName.type === "required" && <span style={{color: 'red'}}> *</span>}
                        <OutlinedInput
                            {...methods.register("catName")}
                            style={{marginTop: "0.3rem"}}
                            placeholder="Enter Category Name"
                            size="small"
                            fullWidth
                        />
                    </div>

                    <div style={{marginTop: "1rem"}}>
                        <label style={{fontWeight: 600}}>Dispaly Name:</label>
                        {methods.formState.errors.catDisplayName && methods.formState.errors.catDisplayName.type === "required" && <span style={{color: 'red'}}> *</span>}
                        <OutlinedInput
                            {...methods.register("catDisplayName")}
                            style={{marginTop: "0.3rem"}}
                            placeholder="Enter Display Name"
                            size="small"
                            fullWidth
                        />
                    </div>

                    <div style={{marginTop: "1rem"}}>
                        <label style={{fontWeight: 600}}>Parent Category:</label>
                        {parentContent}
                    </div>

                    <div style={{marginTop: "1rem"}}>
                        <label style={{fontWeight: 600}}>Attributes:</label>
                        <hr />
                        <AttributeTable />
                    </div>

                    <div style={{marginTop: "1rem"}}>
                        <label style={{fontWeight: 600}}>variants:</label>
                        <hr />
                        <VariantsTable />
                    </div>

                    {/* Submit Button */}
                    <div style={{ marginTop: "2rem", marginBottom: '1rem', display: 'flex', justifyContent: 'center' }}>
                        <Button type="submit" style={{width: "10rem"}} variant="contained">Save</Button>
                    </div>
                </form>
            </FormProvider>
        </Container>
    );
}