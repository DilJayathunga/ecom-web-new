/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 20/01/2020
 */

const NavLogo = (props) => {
  return (
    <>
      <div>
        <img
          alt="navLogo"
          src="/logo-e-commerce.png"
          height={30}
          style={{}}
        />
      </div>
    </>
  );
};
export default NavLogo;
