/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 20/01/2020
 */

import {
  ArrowDropDownOutlined,
  BookmarkBorder,
  Dashboard,
  Face,
  FavoriteBorder,
  Logout,
} from "@mui/icons-material";
import {
  Divider,
  IconButton,
  ListItemIcon,
  Menu,
  MenuItem,
} from "@mui/material";
import { Container } from "@mui/system";
import { useDispatch } from "react-redux";
import { useState } from "react";
import Link from "next/link";
import { toggleLoginDialog, toggleRegisterDialog } from "../../store/slices/userSlice";

const NavUser = () => {
  const dispatch = useDispatch();

  const [anchorEl, setAnchorEl] = useState(null);

  const open = Boolean(anchorEl);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleOpenLoginDialog = () => {
    console.log("login true");
    dispatch(toggleLoginDialog());
  };

  const handleOpenRegistrationDialog = () => {
    dispatch(toggleRegisterDialog());
  };

  return (
    <>
      <a
        style={{ textAlign: "center" }}
        onClick={handleClick}
        size="small"
        sx={{ ml: 2 }}
      >
        {/* profile pick or icon */}
        <div>
          <IconButton>
            {/* <AccountCircleOutlined style={{ color: "white", width: "35px", height: "35px"}} /> */}
            <img
              alt="profile picture"
              style={{ width: "35px", height: "35px", borderRadius: "20px" }}
              src={`https://www.youloveit.com/uploads/posts/2021-08/1628604849_youloveit_com_frozen_cute_profile_pictures_elsa_and_anna04.jpg`}
            />
          </IconButton>
        </div>

        {/* User name and|or prof links */}
        <Container style={{ alignItems: "center", cursor: "pointer" }}>
          <div
            style={{
              display: "flex",
              // alignItems: "center",
              justifyContent: "center",
              fontSize: 12,
            }}
          >
            Sign In
            <ArrowDropDownOutlined
              style={{ color: "white", height: "22px", width: "22px" }}
            />
          </div>
        </Container>
      </a>

      <Menu
        anchorEl={anchorEl}
        id="account-menu"
        open={open}
        onClose={handleClose}
        onClick={handleClose}
        PaperProps={{
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            "& .MuiAvatar-root": {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        transformOrigin={{ horizontal: "right", vertical: "top" }}
        anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <div style={{ display: "flex", justifyContent: "space-around" }}>
          <MenuItem onClick={handleOpenRegistrationDialog}> Sign up</MenuItem>
          <MenuItem onClick={handleOpenLoginDialog}> Sign in</MenuItem>
        </div>

        <Divider />

        <MenuItem>
          <ListItemIcon>
            <BookmarkBorder fontSize="small" />
          </ListItemIcon>
          My Orders
        </MenuItem>
        <MenuItem>
          <ListItemIcon>
            <FavoriteBorder fontSize="small" />
          </ListItemIcon>
          Wish List
        </MenuItem>
        <MenuItem>
          <Link href="/profile/overview">
            <a>
              <ListItemIcon>
                <Face fontSize="small" />
              </ListItemIcon>
              Profile
            </a>
          </Link>
        </MenuItem>
        <MenuItem>
          <Link href="/admin/user">
            <a>
              <ListItemIcon>
                <Dashboard fontSize="small" />
              </ListItemIcon>
              Admin Dashboard
            </a>
          </Link>
        </MenuItem>

        <MenuItem>
          <ListItemIcon>
            <Logout fontSize="small" />
          </ListItemIcon>
          Logout
        </MenuItem>
      </Menu>
    </>
  );
};

export default NavUser;
