import { Card, Button, MenuItem, Grid, Toolbar, Paper } from "@mui/material";
import { useState, useEffect, useRef } from "react";
import { useGetAllCatWithSubCatQuery } from "../../store/services/categoryService";
import { useRouter } from "next/router";

function useComponentVisible(initialIsVisible) {
  const [isComponentVisible, setIsComponentVisible] =
    useState(initialIsVisible);
  const ref = useRef(null);

  const handleClickOutside = (event) => {
    if (ref.current && !ref.current.contains(event.target)) {
      setIsComponentVisible(false);
    }
  };

  useEffect(() => {
    document.addEventListener("click", handleClickOutside, true);
    return () => {
      document.removeEventListener("click", handleClickOutside, true);
    };
  }),
    [];

  return { ref, isComponentVisible, setIsComponentVisible };
}

function CategoryDropdown() {
  const { data: categories, isSuccess: catSuccess } =
    useGetAllCatWithSubCatQuery();

  const [level, setLevel] = useState(1);
  const [expand, setExpand] = useState(true);

  const [show, setShow] = useState(false);

  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
    setIsComponentVisible(true);
  };

  const { ref, isComponentVisible, setIsComponentVisible } =
    useComponentVisible(false);
  const [style, setStyle] = useState();

  //hover main
  const [itemHover, setitemHover] = useState(0);
  useEffect(() => {}, [itemHover]);

  const [itemHover1, setitemHover1] = useState(1);
  useEffect(() => {}, [itemHover1]);
  
  const [itemHover2, setitemHover2] = useState(1);
  useEffect(() => {}, [itemHover2]);

  const [selectedCategory, setSelectedCategory] = useState(null);
  const router = useRouter();

  const handleSearch = (catId) => {
    const query = {};

    // setSelectedCategory = categories;
    // if (selectedCategory) {
    //   query.Category = categories?.list[0][itemHover]?.subCategoryList[itemHover1]?.catId;
    // }
    query.Category = catId
    router.push({ pathname: "/search", query });
  };
// console.log(categories.list[0][itemHover].subCategoryList[itemHover1].catId, "cat")
//console.log(selectedCategory, "select cat");
  return (
    <>
      <div>
        <Button
          onClick={handleClick}
          style={{
            textTransform: "none",
            fontWeight: "initial",
            padding: 5,
          }}
        >
          Categories
        </Button>
        <div ref={ref}>
          {/* <div onClick={() => setIsComponentVisible(true)}></div> */}
          {isComponentVisible && (
            <span>
              <Card
                style={{
                  position: "absolute",
                  backgroundColor: "white",
                  width: 200,
                  zIndex: 1,
                  boxShadow: "rgb(158 158 158) 1px 1px 15px 1px",
                }}
              >
                <div>
                  <div>
                    {categories?.list[0].map((item, index) => (
                      <div
                        key={item.catId}
                        onMouseOver={() => setitemHover(index)}
                      >
                        <RenderSubNode key={item.catId} nodes={item} />
                      </div>
                    ))}
                  </div>
                </div>
              </Card>
            </span>
          )}
          {isComponentVisible && (
            <Card>
              <div
                style={{
                  minHeight: 200,
                  backgroundColor: "white",
                  marginLeft: 200,
                  position: "absolute",
                  zIndex: 1,
                  boxShadow: "rgb(158 158 158) 1px 1px 15px 1px",
                }}
                onMouseOut={() => setShow(false)}
              >
                <Toolbar>
                  <Grid>
                    <div ref={ref} style={style}>
                      {categories?.list[0][itemHover].subCategoryList.map(
                        (sub, index) => (
                          <div
                            key={index}
                            style={{ textAlign: "start", minWidth: 140 }}
                            onMouseOver={() => setitemHover1(index)}
                          >
                            <MenuItem onClick={() => handleSearch(sub.catId)} >
                              {sub.catDisplayName}
                            </MenuItem>
                          </div>
                        )
                      )}
                    </div>
                  </Grid>
                </Toolbar>
              </div>
            </Card>
          )}
        </div>
        <div ref={ref} onClick={handleClick}>
          {isComponentVisible && (
            <Paper
              style={{
                backgroundColor: "white",
                marginLeft: 385,
                position: "absolute",
                zIndex: 1,
                boxShadow: "rgb(158 158 158) 1px 1px 15px 1px",
              }}
            >
              <div>
                {categories?.list[0][itemHover]?.subCategoryList[
                  itemHover1
                ]?.subCategoryList?.map((sub, index) => (
                  <div
                    key={index}
                    style={{ textAlign: "start", minWidth: 140 }}
                    onMouseOver={() => setitemHover2(index)}
                  >
                    <MenuItem onClick={handleSearch(sub.catId)}>
                      {sub.catDisplayName}
                    </MenuItem>
                  </div>
                ))}
              </div>
            </Paper>
          )}
        </div>
      </div>
    </>
  );
}

export default CategoryDropdown;

function RenderSubNode(props) {
  const { nodes } = props;

  const handleSearch = () => {
    const query = {};
    if (selectedCategory) {
      query.Category = selectedCategory.catId;
    } else if (searchText) {
      query.SearchText = searchText;
    }
    router.push({ pathname: "/search", query });
  };
  return (
    <>
      <MenuItem>
        {nodes.subCategoryList && Array.isArray(nodes.subCategoryList) ? (
          <div style={{ fontWeight: 600 }} fontWeight={100}>
            {nodes.catDisplayName}
          </div>
        ) : (
          <div></div>
        )}
      </MenuItem>
    </>
  );
}
