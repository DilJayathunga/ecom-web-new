/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 25/01/2020
 */
import { Autocomplete, Button, TextField } from "@mui/material";
import { useRouter } from "next/router";
import { useState } from "react";
import { useGetAllTopCategoriesQuery } from "../../store/services/categoryService";

const NavSearch = () => {
    const router = useRouter();

    const [selectedCategory, setSelectedCategory] = useState(null);
    const [suggestionValue, setSuggestionValue] = useState(null);
    const [searchText, setSearchText] = useState("");

    //fetching keywords
    const keywordList = ["rattle", "shoes", "shirt"];

    // fetching top category list
    const { data : topCats } = useGetAllTopCategoriesQuery();

    // const handleSuggetionOnChange = (keyword) => {
    //     setSuggestionValue(keyword);
    //     const query = {}
    //     if (selectedCategory) {
    //         query.Category = selectedCategory.catId;
    //     }
    //     query.SearchText = suggestionValue;
    //     router.push({ pathname: "/search", query });
    // }
    
    const handleSearch = () => {
        const query = {}
        if (selectedCategory) {
            query.Category = selectedCategory.catId;
            
        }
        if (searchText) {
            query.SearchText = searchText;
        } else if (suggestionValue) {
            query.SearchText = suggestionValue;
        }
        router.push({ pathname: "/search", query });
    }
   
    return (
        <>
            <div style={{
                backgroundColor: "white",
                height: "40px",
                display: "inline-block",
                borderRadius: "5px",
                display: "flex",
                flexDirection: " row",
                justifyContent: "space-between",
                alignItems: "center",
                marginLeft: 30,
                marginRight: 30,
            }}>
                <Autocomplete
                    options={topCats?.list || []}
                    getOptionLabel={(option) => option.catDisplayName}
                    value={selectedCategory}
                    onChange={(_event, newValue) => {
                        setSelectedCategory(newValue);
                    }}
                    renderInput={(params) => (
                        <TextField
                            {...params}
                            placeholder="All"
                            variant="standard"
                            style={{ paddingLeft: 15 }}
                            InputProps={{ ...params.InputProps, disableUnderline: true }}
                        />
                    )}
                    disablePortal
                    style={{ overflow: "hidden", width: 140 }}
                />

                {/* divider */}
                <div style={{
                    marginRight: 10,
                    marginLeft: 10,
                    height: 40,
                    width: 0.5,
                    backgroundColor: " #dadada",
                }}></div>

                <Autocomplete
                    options={keywordList}
                    value={suggestionValue}
                    onChange={(_event, newValue) => {
                        setSuggestionValue(newValue);
                    }}
                    // onChange={(_event ,newValue) => handleSuggetionOnChange(newValue)}
                    inputValue={searchText}
                    onInputChange={(_event, newInputValue) => {
                        setSearchText(newInputValue);
                    }}
                    renderInput={(params) => (
                        <TextField
                            {...params}
                            placeholder="Search something"
                            variant="standard"
                            style={{ backgroundColor: "white", fontSize: 10, marginLeft: 1 }}
                            InputProps={{ ...params.InputProps, disableUnderline: true }}
                            fullWidth
                        />
                    )}
                    freeSolo
                    style={{ backgroundColor: 'white', fontSize: 10, flex: 1 }}
                />

                {/* divider */}
                <div style={{
                    marginRight: 10,
                    marginLeft: 10,
                    height: 40,
                    width: 0.5,
                    backgroundColor: " #dadada",
                }}></div>

                {/* search button */}
                <Button
                    style={{
                        paddingRight: 30,
                        width: 80,
                        color: " #747474",
                        border: "none",
                        backgroundColor: "white",
                        Icon: "none",
                        textTransform: "none",
                        color: "gray",
                        fontWeight: "initial",
                    }}
                    onClick={handleSearch}
                    variant="text"
                >
                    Search
                </Button>
            </div>
        </>
    );
}

export default NavSearch;