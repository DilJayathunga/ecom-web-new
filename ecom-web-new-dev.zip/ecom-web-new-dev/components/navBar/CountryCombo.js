/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 27/01/2020
 */

import { FormControl, MenuItem, Select } from "@mui/material";
import { useState } from "react";
import { Countries } from "./Countries";

const CountryCombo = () => {

    const [country, setCountry] = useState("AE");
    // const countries = Countries;

    const handleChange = (event) => {
        setCountry(event.target.value);
    };

    return(
        <div>
            {/* <FormControl sx={{ m: 1, width: 200, maxHeight: 500 }}> */}
                <Select
                    id="demo-simple-select-autowidth"
                    style={{ m: 1, width: 200, height: 30 }}
                    value={country}
                    onChange={handleChange}
                    // MenuProps={{ classes: { paper: classesx.menuPaper } }}
                    variant="standard"
                    disableUnderline={true}
                >
                    {Countries.map((c) => (
                        <MenuItem key={c.code} value={c.code}>
                            <img
                                loading="lazy"
                                width="20"
                                src={`https://flagcdn.com/w20/${c.code.toLowerCase()}.png`}
                                srcSet={`https://flagcdn.com/w40/${c.code.toLowerCase()}.png 2x`}
                                alt={`${c.code}`}
                                style={{marginRight:10}}
                            />
                            {c.label}
                        </MenuItem>
                    ))}
                </Select>
            {/* </FormControl> */}
        </div>
    );
}

export default CountryCombo;
