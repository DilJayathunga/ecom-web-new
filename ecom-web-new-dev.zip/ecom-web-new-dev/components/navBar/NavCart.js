/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 20/01/2020
 */

import React, { useEffect } from "react";
import { IconButton, Badge} from "@mui/material";
import { ShoppingCart, ShoppingCartSharp } from "@mui/icons-material";
import { useCookies } from "react-cookie"

const NavCart = () => {
  const [itemCount, setItemCount] = React.useState();
  const [cookies, setCookie] = useCookies(["cartItems"])

  useEffect(() => {
    setItemCount(cookies.cartItems || 0)
  }, [cookies])
  

  return (
    <div style={{
      display:'flex',
      flexDirection:'column', 
      textAlign:'center',
    }}>
      <div>
        <Badge color="error" badgeContent={itemCount} fontSize="1">
          {/* <div style={{color: "white",}}> */}
            <IconButton style={{height: '25px', width: '25px'}} >
              <ShoppingCart style={{color:'white'}}/>
            </IconButton>
          {/* </div> */}
                {/* {" "} */}
        </Badge>
      </div>
      <div style={{
        fontSize: 12,
        paddingBottom: 5,
        color: 'white',
        textalign: 'center',
        textDecoration: 'none',
        display: 'inline-block'
      }}>
        {/* <a className="navitemtext" href="#">Cart</a> */}
        Cart
      </div>
    </div>
  );
};

export default NavCart;
