/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 20/01/2020
 */

import { AppBar, Toolbar } from "@mui/material";
import { Container } from "@mui/system";
import Link from "next/link";
import React, { useState, useEffect } from 'react';
import NavCart from "./NavCart";
import NavGoToMobileApp from "./NavGoToMobileApp";
import NavLogo from "./NavLogo";
import NavSearch from "./NavSearch";
import NavUser from "./NavUser";
import SubNavBar from "./SubNavBar";

const Navbar = () => {
  return (
    <>
      <div >
      {/* <Container maxWidth="xl"> */}
        <Toolbar style={{backgroundColor:'#00719C', display:"flex", justifyContent:"space-between", alignItems:'center'}}>
          <div style={{flexGrow:1 }}>
            <Link href="/">
              <a>
                <NavLogo/>
                </a>
            </Link> 
          </div>
          <div style={{flexGrow:200 }}>
            <NavSearch />
          </div>
          <div style={{flexGrow:1 }}>
            <NavGoToMobileApp/>
          </div>
          <div style={{flexGrow:1, }}><NavUser /></div>
          <div style={{flexGrow:1, }}>
            <Link href="/cart">
              <a>
                <NavCart/>
              </a>
            </Link>            
          </div>
        </Toolbar>
        <SubNavBar/>
        {/* </Container> */}
      </div>
    </>
  );
};
export default Navbar;
