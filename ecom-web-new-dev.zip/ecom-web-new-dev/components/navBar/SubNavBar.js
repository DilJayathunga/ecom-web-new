/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 26/01/2020
 */

import { Box, createTheme, ThemeProvider, Toolbar } from "@mui/material";
import CategoryDropdown from "./CategoryDropdown";
import CountryCombo from "./CountryCombo";
import SubHelp from "./SubHelp";
import SubNavLanguage from "./SubNavlanguage";
import SubTodayDeals from "./SubTodayDeals";


const SubNavBar = () => {
    
    return (
        <div>
            <Box style={{ height: 35, backgroundColor: '#ffffff' }}>
                <Toolbar
                    style={{ 
                        minHeight: 35,
                        display:"flex", 
                        justifyContent:"space-between",
                        textAlign:'center',
                        height:"25px",                       
                    }}
                    sx={{ boxShadow: 1}}
                >
                    <div style={{ flexGrow: 1 }}>
                        <CategoryDropdown />
                       
                    </div>
                    <div style={{ flexGrow: 1 }}>
                        <SubTodayDeals/>
                    </div>
                
                    <div style={{ flexGrow: 1 }}>
                        <SubHelp/>
                    </div>
                    <div style={{ flexGrow: 10 }}></div>
                    <div style={{ flexGrow: 1 }}>
                        <CountryCombo />
                    </div>
                    <div style={{ flexGrow: 1 }}>
                        <SubNavLanguage/>
                    </div>
                </Toolbar>
            </Box>
        </div>
    );
}

export default SubNavBar;
