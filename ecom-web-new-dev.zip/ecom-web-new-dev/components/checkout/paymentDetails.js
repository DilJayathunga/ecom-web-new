import { Paper, Typography } from "@mui/material";
import Image from "next/image";
import { useContext } from "react";
import checkoutContext from "../../context/checkoutContext";
import { SET_PAYMENT_TYPE } from "../../pages/checkout";
import cardPayment from '../../public/payment_methods/card_payment.svg';
import cashPayment from '../../public/payment_methods/cash_payment.svg';
import SavedCards from "./savedCards";

const PaymentMethodButton = ({ title, image, selected, onClick }) => (
  <Paper elevation={5} onClick={onClick} style={{ paddingBlock: "0.5rem", paddingInline: "2rem", outline: selected ? "3px solid #3f51b5" : "", cursor: "pointer" }}>
    <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: "0.5rem" }}>
      <Image src={image} alt={title} width={30} height={30} />
      <Typography fontWeight="bold" textAlign="center">{title}</Typography>
    </div>
  </Paper>
)

const PaymentDetails = () => {
  const { checkoutData, dispatch } = useContext(checkoutContext);

  const handleClick = (type) => () => {
    dispatch({ type: SET_PAYMENT_TYPE, payload: type });
  }

  return (
    <Paper variant="outlined" square style={{ padding: "1rem" }}>
      <Typography variant="h6" fontWeight="bold" style={{ color: "#707070" }}>Payment Method</Typography>
      <hr />
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: "2.5rem", marginTop: "1rem" }}>
        <PaymentMethodButton title="Pay with card" image={cardPayment} selected={checkoutData.payment.type === "card"} onClick={handleClick("card")} />
        <PaymentMethodButton title="Pay with cash" image={cashPayment} selected={checkoutData.payment.type === "cash"} onClick={handleClick("cash")} />
      </div>
      <div style={{ marginTop: "2rem" }}>
        {checkoutData.payment.type === "card" &&
          <SavedCards />
        }
      </div>
    </Paper>
  )
}

export default PaymentDetails;