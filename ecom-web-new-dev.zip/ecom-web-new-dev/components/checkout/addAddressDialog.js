import { Button, Dialog, DialogContent, DialogTitle, OutlinedInput } from "@mui/material";
import styles from "../../styles/util.module.css";

const AddAddressDialog = ({ open, onClose }) => {
  return (
    <Dialog open={open} onClose={onClose} maxWidth="xs">
      <DialogTitle>Add new address</DialogTitle>
      <DialogContent>
        <form>
          <div className={styles.formText}>
            <label className={styles.formLabel}>Name</label>
            <OutlinedInput fullWidth size="small" />
          </div>
          <div className={styles.formText}>
            <label className={styles.formLabel}>Address</label>
            <OutlinedInput fullWidth size="small" />
          </div>
          <div className={styles.formText}>
            <label className={styles.formLabel}>Phone Number</label>
            <OutlinedInput fullWidth size="small" />
          </div>
          <Button className={styles.formItem} variant="contained" type="submit" fullWidth>Save</Button>
        </form>
      </DialogContent>
    </Dialog>
  )
}

export default AddAddressDialog;