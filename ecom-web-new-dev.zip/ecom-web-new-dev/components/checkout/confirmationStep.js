import { Grid } from "@mui/material";
import { useContext } from "react";
import checkoutContext from "../../context/checkoutContext";
import ItemDetails from "./itemDetails";
import PaymentSummery from "./paymentSummery";
import StepNavigationButton from "./stepNavigationButton";

const ConfirmationStep = () => {
  const { handleBack } = useContext(checkoutContext);

  return (
    <>
      <div style={{ width: "80%", margin: "0 auto" }}>
        <Grid container spacing={6}>
          {/* Item Details */}
          <Grid item xs={12} md={7}>
            <ItemDetails />
          </Grid>

          {/* Summery */}
          <Grid item xs={12} md={5}>
            <PaymentSummery displayCard card={{ title: "Card ending in 5432", type: "VISA" }} enableDelivery />
          </Grid>
        </Grid>
      </div>
      <StepNavigationButton text="CONFIRM" />
    </>
  )
}

export default ConfirmationStep;