import { Button, Divider, Paper, Radio, Typography } from "@mui/material";
import { useContext, useState } from "react";
import checkoutContext from "../../context/checkoutContext";
import { SET_DELIVERY_OPTION, SET_SHIPPING_ADDRESS } from "../../pages/checkout";
import AddAddressDialog from "./addAddressDialog";
import StepNavigationButton from "./stepNavigationButton";

const addresses = [
  { id: 1, name: "John Doe", address: "185, High Level Rd, Maharagama.", number: "+94715487901" },
  { id: 2, name: "Jane Doe", address: "185, High Level Rd, Maharagama.", number: "+94715487901" },
]

const deliveryOptions = [
  { title: "Get it Together", description: "Available when you spend AED 500 with select cards from the banks below.", price: "Free" },
  { title: "Leave At My Door", description: "Available when you spend AED 500 with select cards from the banks below.", price: "Free" },
  { title: "Get it Tomorrow", description: "Available when you spend AED 500 with select cards from the banks below.", price: "+AED 10.00" },
]

const ShippingAddressStep = () => {
  const [openAddAddressDialog, setOpenAddAddressDialog] = useState(false);

  const handleDialogOpen = () => {
    setOpenAddAddressDialog(true);
  }

  const handleDialogClose = () => {
    setOpenAddAddressDialog(false);
  }

  const { checkoutData, dispatch } = useContext(checkoutContext);

  const handleShippingAddressChange = (id) => () => {
    dispatch({ type: SET_SHIPPING_ADDRESS, payload: id });
  }

  const handleDeliveryOptionChange = (e) => {
    dispatch({ type: SET_DELIVERY_OPTION, payload: e.target.value });
  }

  return (
    <>
      <div style={{ display: "flex", gap: "1.5rem" }}>
        {addresses.map((address, index) => (
          <Paper
            key={address.id}
            onClick={handleShippingAddressChange(address.id)}
            variant="outlined"
            square
            style={{
              padding: "0.8rem",
              width: "40ch",
              paddingBottom: "2rem",
              outline: checkoutData.shippingAddress === address.id ? "2px solid #3f51b5" : "",
              cursor: "pointer",
            }}
          >
            <Typography variant="h6" fontWeight="bold" style={{ color: "#707070" }}>Address {index + 1}</Typography>
            <Divider />
            <div style={{ display: "flex", gap: "0.8rem", marginTop: "1rem" }}>
              <div style={{ flexGrow: 1 }}>
                <Typography fontWeight="bold" style={{ color: "#707070", marginTop: "1rem" }}>Name</Typography>
                <Typography fontWeight="bold" style={{ color: "#707070", marginTop: "1rem" }}>Address</Typography>
                <Typography fontWeight="bold" style={{ color: "#707070", marginTop: "1rem" }}>Phone Number</Typography>
              </div>
              <div>
                <Typography fontStyle="italic" color="text.secondary" style={{ marginTop: "1rem" }}>{address.name}</Typography>
                <Typography fontStyle="italic" color="text.secondary" style={{ marginTop: "1rem" }}>{address.address}</Typography>
                <Typography fontStyle="italic" color="text.secondary" style={{ marginTop: "1rem" }}>{address.number}</Typography>
              </div>
            </div>
          </Paper>
        ))}
      </div>
      <div style={{ display: "flex", justifyContent: "end", marginBlock: "1rem" }}>
        <Button style={{ fontWeight: "bold" }} onClick={handleDialogOpen}>Add Address</Button>
      </div>
      <Paper variant="outlined" square style={{ padding: "0.8rem", paddingBottom: "2rem", width: "fit-content" }}>
        <Typography variant="h6" fontWeight="bold" style={{ color: "#707070" }}>Delivery Options</Typography>
        <Divider />
        {deliveryOptions.map(option => (
          <div key={option.title} style={{ display: "flex", gap: "0.6rem", marginTop: "1rem" }}>
            <Radio style={{ alignSelf: "start" }} value={option.title} checked={checkoutData.deliveryOption === option.title} onChange={handleDeliveryOptionChange} color="secondary" />
            <div style={{ width: "50ch" }}>
              <Typography fontWeight="bold" style={{ color: "#707070" }}>{option.title}</Typography>
              <Typography color="text.secondary" fontStyle="italic">{option.description}</Typography>
            </div>
            <Typography fontWeight="bold" textAlign="end" style={{ color: "#3f51b5", flexGrow: 1 }}>{option.price}</Typography>
          </div>
        ))}
      </Paper>
      <AddAddressDialog open={openAddAddressDialog} onClose={handleDialogClose} />
      <StepNavigationButton text="PAYMENT" disabled={!checkoutData.shippingAddress || !checkoutData.deliveryOption} />
    </>
  )
}

export default ShippingAddressStep;