import { Button } from "@mui/material";
import { useContext } from "react";
import checkoutContext from "../../context/checkoutContext";

const StepNavigationButton = ({ text, ...other }) => {
  const { handleNext } = useContext(checkoutContext);

  return (
    <Button
      onClick={handleNext}
      variant="contained"
      size="large"
      style={{
        display: "block",
        borderRadius: 0,
        marginBlock: "2rem",
        marginLeft: "auto",
        marginRight: "auto",
        width: "30ch"
      }}
      {...other}
    >
      {text}
    </Button>
  )
}

export default StepNavigationButton;