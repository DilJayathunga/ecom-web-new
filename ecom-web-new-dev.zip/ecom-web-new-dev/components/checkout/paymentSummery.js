import { Button, Paper, Typography } from "@mui/material";
import Image from "next/image";
import { useContext } from "react";
import checkoutContext from "../../context/checkoutContext";
import { SummeryPaper, Total } from "../cart/orderSummery";
import { displayCardImage } from "./savedCards";

const items = [
  { id: 1, title: "Lenovo Legion 5 Pro 16 165Hz QHD IPS G-Sync Ryzen 7 16GB RAM 1TB SSD RTX 3070", qty: 1, price: "528.00", img: "https://a2zlaptop.com/product_images/jpeg/Lenovo-Legion-5-Pro.jpg" },
  { id: 2, title: "Lenovo Legion 5 Pro 16 165Hz QHD IPS G-Sync Ryzen 7 16GB RAM 1TB SSD RTX 3070", qty: 1, price: "528.00", img: "https://a2zlaptop.com/product_images/jpeg/Lenovo-Legion-5-Pro.jpg" },
  { id: 3, title: "Lenovo Legion 5 Pro 16 165Hz QHD IPS G-Sync Ryzen 7 16GB RAM 1TB SSD RTX 3070", qty: 1, price: "528.00", img: "https://a2zlaptop.com/product_images/jpeg/Lenovo-Legion-5-Pro.jpg" },
]

const PaymentSummery = ({ displayCard = false, card, ...other }) => {
  const { handleBack } = useContext(checkoutContext);

  return (
    <>
      <SummeryPaper items={items} disableCoupon {...other} />
      <Total />
      {displayCard &&
        <Paper variant="outlined" square style={{ padding: "1rem" }}>
          <div style={{ display: "flex", gap: "0.5rem", alignItems: "center" }}>
            <div style={{ flexGrow: 2 }}>
              <Typography fontWeight="bold" style={{ color: "#707070" }}>PAYING WITH</Typography>
              <Typography style={{ color: "#707070" }}>{card.title}</Typography>
            </div>
            <Image src={displayCardImage(card.type)} alt={card.type} width={50} height={50} />
          </div>
        </Paper>
      }
      <Paper variant="outlined" square style={{ padding: "1rem", marginTop: "2rem" }}>
        <Typography variant="h6" fontWeight="bold" style={{ color: "#707070" }}>Ship To</Typography>
        <hr />
        <div style={{ marginTop: "1rem" }}>
          <Typography fontWeight="bold">Name</Typography>
          <Typography color="text.secondary">185, High Level Rd, Maharagama</Typography>
          <Typography color="text.secondary">+94 771 582 288</Typography>
        </div>
        <Button style={{ fontWeight: "bold", display: "block", marginLeft: "auto", padding: 0 }} onClick={() => handleBack(0)}>EDIT</Button>
      </Paper>
    </>
  )
}

export default PaymentSummery;