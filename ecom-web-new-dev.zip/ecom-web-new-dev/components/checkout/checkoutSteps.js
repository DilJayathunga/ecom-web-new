import { Step, StepLabel, Stepper, Typography } from "@mui/material";

const CheckoutSteps = ({ activeStep, steps }) => {
  return (
    <div style={{paddingBlock: "1rem"}}>
      <Typography variant="h5" fontWeight="bold" textAlign="center" color="secondary">Secure Checkout</Typography>
      <Stepper alternativeLabel activeStep={activeStep} style={{ width: "80%", margin: "0 auto" }}>
        {steps.map(step => (
          <Step key={step}>
            <StepLabel>{step}</StepLabel>
          </Step>
        ))}
      </Stepper>
    </div>
  )
}

export default CheckoutSteps;