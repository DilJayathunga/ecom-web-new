import { Button, Checkbox, FormControlLabel, OutlinedInput, Paper, Radio, Typography } from "@mui/material";
import Image from "next/image";
import { useState, useContext } from "react";
import checkoutContext from "../../context/checkoutContext";
import { SET_PAYMENT_DETAILS } from "../../pages/checkout";
import americanExpress from '../../public/cards/american-express.svg';
import mastercard from '../../public/cards/mastercard.svg';
import visa from '../../public/cards/visa.svg';

const cards = [
  { id: 1, title: "Card ending in 5432", subTitle: "Monthly installment plans available", type: "VISA" },
  { id: 2, title: "Card ending in 5432", subTitle: "Monthly installment plans available", type: "MASTERCARD" },
  { id: 3, title: "Card ending in 5432", subTitle: "Monthly installment plans available", type: "VISA" },
]

const AMERICAN_EXPRESS = "AMERICAN_EXPRESS";
const MASTERCARD = "MASTERCARD";
const VISA = "VISA";

export const displayCardImage = (cardType) => {
  switch (cardType) {
    case AMERICAN_EXPRESS:
      return americanExpress;
    case MASTERCARD:
      return mastercard;
    case VISA:
      return visa;
    default:
      break;
  }
}

const SavedCards = () => {
  const [newCard, setNewCard] = useState(false);
  const { checkoutData, dispatch } = useContext(checkoutContext);

  const handleChange = (e) => {
    dispatch({ type: SET_PAYMENT_DETAILS, payload: e.target.value });
  }

  return (
    <>
      {!newCard ?
        <>
          <Typography variant="subtitle1" fontWeight="bold" style={{ color: "#707070" }}>SELECT A SAVED CARD</Typography>
          <hr />
          <div style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>
            {cards.map(card => (
              <Paper key={card.id} elevation={4} style={{ padding: "0.5rem" }}>
                <div style={{ display: "flex", gap: "0.5rem", alignItems: "center" }}>
                  <Radio value={card.id} checked={card.id.toString() === checkoutData.payment.details} onChange={handleChange} color="secondary" />
                  <div style={{ flexGrow: 2 }}>
                    <Typography fontWeight="bold" style={{ color: "#707070" }}>{card.title}</Typography>
                    <Typography style={{ color: "#707070" }}>{card.subTitle}</Typography>
                  </div>
                  <Image src={displayCardImage(card.type)} alt={card.type} width={50} height={50} />
                </div>
              </Paper>
            ))}
          </div>
          <Button style={{ fontWeight: "bold", display: "block", marginLeft: "auto", marginTop: "1rem", padding: 0 }} onClick={() => setNewCard(true)}>Add a New Card</Button>
        </>
        :
        <>
          <Typography variant="subtitle1" fontWeight="bold" style={{ color: "#707070" }}>Add you Card Details</Typography>
          <hr />
          <div style={{ width: "60%" }}>
            <div>
              <label style={{ fontWeight: "bold" }}>Card Number</label>
              <OutlinedInput size="small" fullWidth />
            </div>
            <div style={{ display: "flex", gap: "4rem", marginTop: "1rem" }}>
              <div>
                <label style={{ fontWeight: "bold" }}>Expiry Date</label>
                <div>
                  <OutlinedInput size="small" />
                </div>
              </div>
              <div>
                <label style={{ fontWeight: "bold" }}>CVV</label>
                <div>
                  <OutlinedInput size="small" />
                </div>
              </div>
            </div>
            <FormControlLabel control={<Checkbox />} label="Save card for next time" />
          </div>
          <Button style={{ fontWeight: "bold", display: "block", marginLeft: "auto", marginTop: "1rem", padding: 0 }} onClick={() => setNewCard(false)}>Select a saved card instead</Button>
        </>
      }
    </>
  )
}

export default SavedCards;