import { Button, Typography } from '@mui/material';
import Image from 'next/image';
import Link from 'next/link';
import orderPlaced from '../../public/checkout/order_placed.svg';

const CheckoutFinished = () => {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", flexDirection: "column", marginBlock: "2rem" }}>
      <Image src={orderPlaced} alt="order placed" width={300} height={300} />
      <Typography variant='h6' fontWeight="bold" textAlign="center" style={{ color: "#707070" }}>Your order has been placed successfully.</Typography>
      <Link href="/">
        <Button
          variant="contained"
          size="large"
          style={{
            display: "block",
            fontWeight: "bold",
            borderRadius: 0,
            width: "30ch"
          }}
        >
          Back to Shop
        </Button>
      </Link>
    </div>
  )
}

export default CheckoutFinished;