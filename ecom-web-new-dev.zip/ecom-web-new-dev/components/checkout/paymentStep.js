import { Grid } from "@mui/material";
import { useContext } from "react";
import checkoutContext from "../../context/checkoutContext";
import PaymentDetails from "./paymentDetails";
import PaymentSummery from "./paymentSummery";
import StepNavigationButton from "./stepNavigationButton";

const PaymentStep = () => {
  const { checkoutData } = useContext(checkoutContext);

  return (
    <>
      <div style={{ width: "80%", margin: "0 auto" }}>
        <Grid container spacing={6}>
          {/* Payment Details */}
          <Grid item xs={12} md={7.5}>
            <PaymentDetails />
          </Grid>

          {/* Summery */}
          <Grid item xs={12} md={4.5}>
            <PaymentSummery />
          </Grid>
        </Grid>
      </div>
      <StepNavigationButton text="PLACE ORDER" disabled={checkoutData.payment.type !== "cash" && !checkoutData.payment.details} />
    </>
  )
}

export default PaymentStep;