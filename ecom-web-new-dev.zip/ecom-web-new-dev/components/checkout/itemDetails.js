import { Divider, Paper, Typography } from "@mui/material";
import { useTheme } from '@mui/material/styles';

const items = [
  { id: 1, title: "Lenovo Legion 5 Pro 16 165Hz QHD IPS G-Sync Ryzen 7 16GB RAM 1TB SSD RTX 3070", qty: 1, price: "528.00", img: "https://a2zlaptop.com/product_images/jpeg/Lenovo-Legion-5-Pro.jpg" },
  { id: 2, title: "Lenovo Legion 5 Pro 16 165Hz QHD IPS G-Sync Ryzen 7 16GB RAM 1TB SSD RTX 3070", qty: 1, price: "528.00", img: "https://a2zlaptop.com/product_images/jpeg/Lenovo-Legion-5-Pro.jpg" },
  { id: 3, title: "Lenovo Legion 5 Pro 16 165Hz QHD IPS G-Sync Ryzen 7 16GB RAM 1TB SSD RTX 3070", qty: 1, price: "528.00", img: "https://a2zlaptop.com/product_images/jpeg/Lenovo-Legion-5-Pro.jpg" },
]

const ItemDetails = () => {
  const theme = useTheme();

  return (
    <Paper variant="outlined" square style={{ padding: "1rem", paddingBottom: "2rem" }}>
      <Typography variant="h6" fontWeight="bold" style={{ color: "#707070" }}>Items</Typography>
      <hr />
      {items.map(item => (
        <>
          <div key={item.id} style={{ display: "flex", gap: "1rem", marginTop: "1rem" }}>
            <img src="https://a2zlaptop.com/product_images/jpeg/Lenovo-Legion-5-Pro.jpg" alt="Hipp" width={160} height={100} style={{ alignSelf: "center" }} />
            <div>
              <Typography fontWeight="bold">{item.title}</Typography>
              <Typography color="text.secondary">Item Price: ${item.price}</Typography>
              <Typography color="text.secondary">Qty: {item.qty}</Typography>
            </div>
            <Typography fontWeight="bold" style={{ alignSelf: "end", marginLeft: "auto" }} color="primary"><span style={{ color: theme.palette.secondary.main }}>$</span>528.00</Typography>
          </div>
          <Divider style={{ marginTop: "1rem" }} />
        </>
      ))}
    </Paper>
  )
}

export default ItemDetails;