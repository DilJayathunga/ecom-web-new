/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 1/7/2022
 */

import { Grid, Paper } from "@mui/material";
import ProfileDialog from "../components/profile/profileDialog";
import { SidePanel } from "../components/sidePanel/SidePanel";

const ProfileLayout = ({ children }) => (
    <>
      <Grid container spacing={0}>
        <Grid item xs={12} md={3}>
        <SidePanel name = " Profile Dashboard "  list = {list}/>
        </Grid>
        <Grid item xs={12} md={9}>
          <Paper style={{
                  flex: 1,
                  margin: '10px',
                  padding: '12px 0 20px 28px',
                  height: '654px'
              }}>
            {children}
          </Paper>
        </Grid>
      </Grid>
      <ProfileDialog />
    </>
);

const list = [
    {
      id: 1,
      name: 'Overview',
      link: '/profile/overview'
    },    
    {
      id: 2,
      name: 'Orders',
      link: '/profile/orders'
    },
    {
      id: 3,
      name: 'Refunds and Returns',
      link: '/profile/refundsAndReturns'
    },
  ];

export const getLayout = (page) => <ProfileLayout>{page}</ProfileLayout>;

export default ProfileLayout;