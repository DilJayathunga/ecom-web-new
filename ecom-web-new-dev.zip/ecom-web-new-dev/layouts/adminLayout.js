/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 1/7/2022
 */

import { Grid, Paper } from "@mui/material";
import CategoryDialog from "../components/category/categoryDialog";
import OrgDialogs from "../components/org/orgDialogs";
import { SidePanel } from "../components/sidePanel/SidePanel";
import UserDialog from "../components/user/UserDialog";

const AdminLayout = ({ children }) => (
  <>
    <Grid container spacing={0}>
      <Grid item xs={12} md={3}>
        <SidePanel name=" Admin Dashboard " list={list} />
      </Grid>
      <Grid item xs={12} md={9}>
        <Paper style={{
          flex: 1,
          margin: '10px',
          padding: '12px 28px 20px 28px',
          // backgroundColor: '#e6eff5',
          height: '707px'
        }}>
          {children}
        </Paper>
      </Grid>
    </Grid>
    <CategoryDialog />
    <UserDialog />
    <OrgDialogs />
  </>
);

const list = [
  {
    id: 1,
    name: 'User Management',
    link: '/admin/user'
  },
  {
    id: 2,
    name: 'Category Management',
    link: '/admin/category'
  },
  {
    id: 3,
    name: 'Item Management',
    link: '/admin/item'
  },
  {
    id: 4,
    name: 'Order Management',
    link: '/admin/order'
  },
  {
    id: 5,
    name: 'Organization Management',
    link: '/admin/organization'
  },
  {
    id: 6,
    name: 'Policy Management',
    link: '/admin/policy'
  },
  {
    id: 7,
    name: 'Seller Management',
    link: '/admin/seller'
  },
  {
    id: 8,
    name: 'Brand Management',
    link: '/admin/brand'
  }
];

export const getLayout = (page) => <AdminLayout>{page}</AdminLayout>;


export default AdminLayout;

