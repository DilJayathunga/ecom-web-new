import { getLayout } from "../../layouts/profileLayout";
import {
  Grid,
  Typography,
  Button,
  Paper,
  Avatar,
  List,
  ListItem,
  Box,
  InputBase,
  Link,
} from "@mui/material";
import { Edit } from "@mui/icons-material";
import Head from "next/head";
import { openProfileEditForm } from "../../store/slices/profileSlice";
import { useDispatch } from "react-redux";

function Overview() {

  const dispatch = useDispatch();

  return (
    <>
      <Head>
        <title>E-COM | Overview</title>
      </Head>

      <div>
        <Grid container xs={12}>
          <Grid item xs={9}>
            {/* Topic */}
            <Typography
              sx={{
                padding: "32px 0 0 28px",
                fontSize: "28px",
                fontWeight: "bold",
                fontStretch: "normal",
                textAlign: "left",
                color: "#3a3a3a",
              }}
            >
              Overview
            </Typography>
          </Grid>
        </Grid>
        <div>
  
            <Box
              sx={{
                padding: "14px 0 0 28px",
                width: "-webkit-fill-available",
                position: "relative",
              }}
            >
              <div style={{ width: "20%" }}>
                {/* User Avatar */}
                <Avatar
                  sx={{
                    width: "80px",
                    height: "80px",
                    border: "solid 1px #707070",
                    margin: "0 auto",
                  }}
                  src="https://familywing.com/wp-content/uploads/2019/09/no-image-baby.png"
                />

                {/* User Name */}
                <Typography
                  sx={{
                    fontSize: "16px",
                    fontWeight: "bold",
                    color: "#3a3a3a",
                    display: "flex",
                    justifyContent: "center",
                  }}
                >
                  User Name
                  {/* {user.userName} */}
                </Typography>
              </div>

              <Grid container xs={12}>
                <Grid item xs={12} md={5} sx={{ padding: "70px 0 5px 0" }}>
                  <Typography
                    sx={{
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "#3a3a3a",
                    }}
                  >
                    Delivery Location
                  </Typography>

                  {/* Delivery Address */}
                  <List>
                    <ListItem sx={{ paddingLeft: "0" }}>
                      Address 1{/* {user.custAdd1} */}
                    </ListItem>
                    <ListItem sx={{ paddingLeft: "0" }}>
                      Address 2{/* {user.custAdd2} */}
                    </ListItem>
                    <ListItem sx={{ paddingLeft: "0" }}>
                      Address 3{/* {user.custAdd3} */}
                    </ListItem>
                    <ListItem sx={{ paddingLeft: "0" }}>
                      Address 4{/* {user.custAdd4} */}
                    </ListItem>
                  </List>
                </Grid>
                <Grid item xs={12} md={7} sx={{ padding: "70px 0 5px 0" }}>
                  <Typography
                    sx={{
                      fontSize: "20px",
                      fontWeight: "bold",
                      color: "#3a3a3a",
                    }}
                  >
                    Mobile Number
                  </Typography>

                  {/* Enter mobile number */}
                  <Grid container xs={12}>
                    <Grid item xs={6}>
                      <InputBase
                        placeholder="Enter Number"
                        // defaultValue={user.mobileNumber}
                        sx={{
                          width: "280px",
                          maxHeight: "40px",
                          margin: "19px 2px 8px 0",
                          padding: "11px 0 7px 10px",
                          borderRadius: "5px",
                          border: "solid 1px #707070",
                        }}
                      />
                    </Grid>
                    <Grid item xs={6}>
                      <Button
                        variant="contained"
                        color="success"
                        sx={{
                          width: "123px",
                          height: "40px",
                          margin: "18px 0 0 40px",
                          // padding: '9px 41px',
                          borderRadius: "5px",
                          backgroundColor: "#4caf50",
                        }}
                      >
                        <Typography
                          align={"center"}
                          sx={{
                            fontSize: "18px",
                            textTransform: "none",
                            color: "#fff",
                          }}
                        >
                          Send
                        </Typography>
                      </Button>
                    </Grid>
                  </Grid>

                  {/* verify Number */}
                  <Link
                    href="#"
                    underline="none"
                    sx={{
                      fontSize: "18px",
                      color: "#646464",
                    }}
                  >
                    Verify Number
                  </Link>
                </Grid>
              </Grid>

              <Box sx={{ display: "flex", justifyContent: "right" }}>
                <Link
                  onClick={() => {
                    dispatch(openProfileEditForm(true));
                  }}
                  underline="none"
                  style={{ cursor: "pointer",  }}
                >
                  <Grid container xs={12} style={{marginBottom:200}}>
                    <Typography
                      sx={{
                        
                        textTransform: "none",
                        fontSize: "18px",
                        color: "#4caf50",
                        margin: "150px 0 0px 0",
                      }}
                    >
                      Edit Profile
                    </Typography>
                    <Edit
                      sx={{
                        height: "20px",
                        width: "20px",
                        margin: "150px 33px 0 12px",
                        color: "#4caf50",
                        align: "right",
                      }}
                    />
                  </Grid>
                </Link>
              </Box>
            </Box>

        </div>
      </div>
    </>
  );
}

Overview.getLayout = getLayout;

export default Overview;
