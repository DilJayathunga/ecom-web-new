import { getLayout } from "../../layouts/profileLayout";
import { Typography } from "@mui/material";
// import OrderTable from "./orderTable";

function Refunds$Returnd() {
  return (
    <>
      <Typography
        sx={{
          padding: "32px 0 0 28px",
          fontSize: "28px",
          fontWeight: "bold",
          fontStretch: "normal",
          textAlign: "left",
          color: "#3a3a3a",
        }}
      >
        Refunds And Returns
      </Typography>
      {/* <OrderTable /> */}
    </>
  );
}

Refunds$Returnd.getLayout = getLayout;

export default Refunds$Returnd;
