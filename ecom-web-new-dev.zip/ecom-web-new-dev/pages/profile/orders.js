import { getLayout } from "../../layouts/profileLayout";
import { Paper, Typography, Container } from "@mui/material";
import OrderTable from "../../components/profile/orderTable";


function Orders() {
    return ( <>
 
                {/* Topic */}
                <Typography

                    sx={{                        
                        padding: '32px 0 0 28px',
                        fontSize: '28px',
                        fontWeight: 'bold',
                        fontStretch: 'normal',
                        textAlign: 'left',
                        color: '#3a3a3a',
                    }}>
                    Orders
                </Typography>

                {/* Table */}
                {/* <Container className={tableContainer}>
                       {content}
                </Container> */}
                <OrderTable />
    </>  );
}
Orders.getLayout = getLayout;

export default Orders;