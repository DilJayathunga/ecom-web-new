import { Container } from "@mui/material";
import { useState, useReducer } from "react";
import CheckoutSteps from "../components/checkout/checkoutSteps";
import ShippingAddressStep from "../components/checkout/shippingAddressStep";
import CheckoutContext from '../context/checkoutContext';
import PaymentStep from "../components/checkout/paymentStep";
import ConfirmationStep from "../components/checkout/confirmationStep";
import CheckoutFinished from "../components/checkout/checkoutFinished";

const steps = ["Shipping Address", "Payment", "Confirmation"]

const init = (initialState) => {
  return initialState;
}

export const SET_CHECKOUT_TYPE = "SET_CHECKOUT_TYPE";
export const SET_SHIPPING_ADDRESS = "SET_SHIPPING_ADDRESS";
export const SET_DELIVERY_OPTION = "SET_DELIVERY_OPTION";
export const SET_PAYMENT_TYPE = "SET_PAYMENT_TYPE";
export const SET_PAYMENT_DETAILS = "SET_PAYMENT_DETAILS";

const reducer = (state, action) => {
  switch (action.type) {
    case SET_CHECKOUT_TYPE:
      return { ...state, guest: true }
    case SET_SHIPPING_ADDRESS:
      return { ...state, shippingAddress: action.payload }
    case SET_DELIVERY_OPTION:
      return { ...state, deliveryOption: action.payload }
    case SET_PAYMENT_TYPE:
      return { ...state, payment: { type: action.payload } }
    case SET_PAYMENT_DETAILS:
      return { ...state, payment: { ...state.payment, details: action.payload } }
    default:
      return state;
  }
}

const initialState = {
  checkoutType: "user",
  shippingAddress: null,
  payment: {
    type: "card",
  },
  deliveryOption: null,
}

const Checkout = () => {
  const [checkoutData, dispatch] = useReducer(reducer, initialState, init);

  const [activeStep, setActiveStep] = useState(0);

  const handleNext = () => {
    setActiveStep(currentStep => currentStep + 1);
  }

  const handleBack = (step) => {
    if (step !== undefined) {
      return setActiveStep(step);
    }
    setActiveStep(currentStep => currentStep - 1);
  }

  const renderStep = (step) => {
    switch (step) {
      case 0:
        return <ShippingAddressStep />
      case 1:
        return <PaymentStep />
      case 2:
        return <ConfirmationStep />
      default:
        break;
    }
  }

  return (
    <Container maxWidth="xl">
      {/* <CheckoutNavbar /> */}
      <CheckoutSteps activeStep={activeStep} steps={steps} />
      <CheckoutContext.Provider value={{ checkoutData, dispatch, handleNext, handleBack }}>
        {activeStep === steps.length ?
          <CheckoutFinished />
          :
          <div style={{ marginBlock: "2rem" }}>
            {renderStep(activeStep)}
          </div>
        }
      </CheckoutContext.Provider>
    </Container>
  )
}

export default Checkout;