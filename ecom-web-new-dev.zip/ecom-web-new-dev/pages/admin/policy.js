/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 25/8/2022
 */

import { Backdrop, Button, CircularProgress, Container, Grid, Typography } from "@mui/material";
import Head from "next/head";
import { getLayout } from "../../layouts/adminLayout";
import { useDispatch } from 'react-redux';
import { useState } from "react";
import SearchBar from "../../components/shared/SearchBar";
import { useGetAllPoliciesQuery } from "../../store/services/policyService";
import PolicyTable from "../../components/policy/policyTable";
import { openPolicyForm, setStatus } from "../../store/slices/policySlice";
import PolicyDialog from "../../components/policy/policyDialog";

const Policy = () => {
  const dispatch = useDispatch();

  const { data, isSuccess, isLoading } = useGetAllPoliciesQuery();
  const [searchData, setSearchData] = useState([]);

  let tableContent, searchContent;

  if (isSuccess) {
    console.log("SearchData", searchData);
    tableContent = <PolicyTable policies={searchData} />
    searchContent = <SearchBar data={data.policyList || []} setSearchData={setSearchData} text="Search Policies" search="policy" />
  }
  
  return (
    <>
      <Head>
        <title>E-COM | Policy Management</title>
      </Head>

      {isLoading && (
        <Backdrop
          sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
          open={isLoading}
        >
          <CircularProgress color="inherit" />
        </Backdrop>
      )}

      <Grid container xs={12}>
        <Grid Item xs={9}>
          <Typography
            sx={{
              padding: '32px 0 0 28px',
              fontSize: '28px',
              fontWeight: 'bold',
              fontStretch: 'normal',
              textAlign: 'left',
              color: '#3a3a3a',
            }}>
            Policy Management
          </Typography>
        </Grid>
        <Grid Item xs={3}>
          <Button
            onClick={() => {dispatch(openPolicyForm(true)); dispatch(setStatus("add"))}}
            variant="contained"
            style={{ right: 0, marginTop: '32px', marginLeft: '75px' }}
          >
            Add New Policy
          </Button>
        </Grid>
      </Grid>

      <Container>
        {searchContent}
      </Container>

      <Container>
        {tableContent}
      </Container>

      <PolicyDialog/>
    </>
  )
}

Policy.getLayout = getLayout;

export default Policy;
