/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 26/8/2022
 */

import { Backdrop, Button, CircularProgress, Container, Grid, Typography } from "@mui/material";
import Head from "next/head";
import { getLayout } from "../../layouts/adminLayout";
import { useDispatch } from 'react-redux';
import { useState } from "react";
import SearchBar from "../../components/shared/SearchBar";
import SellerTable from "../../components/seller/sellerTable";
import { useGetAllSellersQuery } from "../../store/services/sellerService";
import { openSellerForm, setStatus } from "../../store/slices/sellerSlice";
import SellerDialog from "../../components/seller/sellerDialog";

const Seller = () => {
  const dispatch = useDispatch();

  const { data, isSuccess, isLoading, isError } = useGetAllSellersQuery();
  const [searchData, setSearchData] = useState([]);

  let tableContent, searchContent;

  if (isError) {
    tableContent = <div>Error...</div>
  }

  if (isSuccess) {
    console.log("SearchData", searchData);
    tableContent = <SellerTable sellers={searchData} />
    searchContent = <SearchBar data={data.list || []} setSearchData={setSearchData} text="Search Sellers" search="seller" />
  }

  return (
    <div>
      <Head>
        <title>E-COM | Seller Management</title>
      </Head>

      {isLoading && (
        <Backdrop
          sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
          open={isLoading}
        >
          <CircularProgress color="inherit" />
        </Backdrop>
      )}
      <div>
        <Grid container xs={12}>
          <Grid Item xs={9}>
            <Typography
              sx={{
                padding: '32px 0 0 28px',
                fontSize: '28px',
                fontWeight: 'bold',
                fontStretch: 'normal',
                textAlign: 'left',
                color: '#3a3a3a',
              }}>
              Seller Management
            </Typography>
          </Grid>
          <Grid Item xs={3}>
            <Button
              onClick={() => {dispatch(openSellerForm(true)); dispatch(setStatus('add'))}}
              variant="contained"
              style={{ right: 0, marginTop: '32px', marginLeft: '75px' }}
            >
              Add New Seller
            </Button>
          </Grid>
        </Grid>

        <Container>
          {searchContent}
        </Container>

        <Container>
          {tableContent}
        </Container>
      </div>
      <SellerDialog/>
    </div>
  )
}

Seller.getLayout = getLayout;

export default Seller;