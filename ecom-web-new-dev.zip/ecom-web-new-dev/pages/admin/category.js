/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 1/7/2022
 */

import { Button, Grid, Paper, Typography } from "@mui/material";
import Head from "next/head";
import { getLayout } from "../../layouts/adminLayout";
import { useDispatch } from "react-redux";
import { openCategoryForm, setStatus } from "../../store/slices/categorySlice";
import NestedTable from "../../components/category/nestedTable";

// import { wrapper } from "../../store/rootStore"
// import { getAllCategories, getRunningOperationPromises } from "../../store/services/categoryService";

const Category = () => {

    const dispatch = useDispatch();

    return (
        <div>
            <Head>
                <title>E-COM | Category Management</title>
            </Head>
            <div>
                <Grid container xs={12}>
                    
                    <Grid item xs={9}>                        
                        {/* Topic */}
                        <Typography
                            sx={{                        
                                padding: '32px 0 0 28px',
                                fontSize: '28px',
                                fontWeight: 'bold',
                                fontStretch: 'normal',
                                textAlign: 'left',
                                color: '#3a3a3a',
                            }}>
                            Category Management
                        </Typography>
                    </Grid>

                    <Grid item xs={3}>
                        {/* Add Category Button */}
                        <Button 
                            onClick={() => {dispatch(openCategoryForm(true)); dispatch(setStatus('add'))}}
                            variant="contained" 
                            style={{right: 0, marginTop: '32px', marginLeft: '32px' }}                            
                            >
                                Add New Category
                        </Button>
                    </Grid>

                </Grid>

                {/* Nested Table view */}
                <NestedTable/>

            </div>            
        </div>
    )
}

Category.getLayout = getLayout;

export default Category;

// export const getServerSideProps = wrapper.getServerSideProps(
//     (store) => async (context) => {
        
//         const data = await store.dispatch(getAllCategories.initiate());
//         await Promise.all(getRunningOperationPromises());
    
//         return {
//             props: {
//                 categories: data
//             }
//         };
//     }
//   );

// export async function getStaticProps() {
//     const store = rootStore()
//     // const dispatch = useDispatch()
//     // const response = store.dispatch(api.endpoints.getTodosList)
//     const data = await store.dispatch(getAllCategories.initiate());

//     await Promise.all(getRunningOperationPromises());

//     console.log(data)

//     return{
//         props: {
//             categories: data,
//         },
//     }
// }