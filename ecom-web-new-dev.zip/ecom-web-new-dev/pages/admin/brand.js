/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 26/8/2022
 */

import { Backdrop, Button, CircularProgress, Container, Grid, Typography } from "@mui/material";
import Head from "next/head";
import { getLayout } from "../../layouts/adminLayout";
import { useDispatch } from 'react-redux';
import { useState } from "react";
import SearchBar from "../../components/shared/SearchBar";
import BrandTable from "../../components/brand/brandTable";
import { useGetAllBrandsQuery } from "../../store/services/brandService";
import BrandDialog from "../../components/brand/brandDialog";
import { openBrandForm, setStatus } from "../../store/slices/brandSlice";

const Brand = () => {
  const dispatch = useDispatch();

  const { data, isSuccess, isLoading, isError } = useGetAllBrandsQuery();
  const [searchData, setSearchData] = useState([]);

  let tableContent, searchContent;

  if (isError) {
    tableContent = <div>Error...</div>
  }

  if (isSuccess) {
    console.log("SearchData", searchData);
    tableContent = <BrandTable brands={searchData} />
    searchContent = //complete search function...
        <SearchBar data={data.list || []} setSearchData={setSearchData} text="Search Brands" search="brand" />
  }

  return (
    <>
      <Head>
        <title>E-COM | Brand Management</title>
      </Head>

      {isLoading && (
        <Backdrop
          sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
          open={isLoading}
        >
          <CircularProgress color="inherit" />
        </Backdrop>
      )}

      <Grid container xs={12}>
        <Grid Item xs={9}>
          <Typography
            sx={{
              padding: '32px 0 0 28px',
              fontSize: '28px',
              fontWeight: 'bold',
              fontStretch: 'normal',
              textAlign: 'left',
              color: '#3a3a3a',
            }}>
            Brand Management
          </Typography>
        </Grid>
        <Grid Item xs={3}>
          <Button
            onClick={() => {dispatch(openBrandForm(true)); dispatch(setStatus("add"))}}
            variant="contained"
            style={{ right: 0, marginTop: '32px', marginLeft: '75px' }}
          >
            Add New Brand
          </Button>
        </Grid>
      </Grid>

      <Container>
        {searchContent}
      </Container>

      <Container>
        {tableContent}
      </Container>
      
      <BrandDialog/>
    </>
  )
}

Brand.getLayout = getLayout;

export default Brand;