/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 1/7/2022
 */

import { Button, Grid, Paper, Typography } from "@mui/material";
import Head from "next/head";
import { getLayout } from "../../layouts/adminLayout";

const Order = () => {
    console.log('Order')
    return (
        <div>
            <Head>
                <title>E-COM | Order Management</title>
            </Head>
            <div>
                <Grid container xs={12}>
                    <Grid Order xs={9}>
                        
                        {/* Topic */}
                        <Typography
                            sx={{                        
                                padding: '32px 0 0 28px',
                                fontSize: '28px',
                                fontWeight: 'bold',
                                fontStretch: 'normal',
                                textAlign: 'left',
                                color: '#3a3a3a',
                            }}>
                            Order Management
                        </Typography>
                    </Grid>
                    <Grid Order xs={3}>

                        {/* Add Order Button */}
                        
                        
                    </Grid>
                </Grid>
            </div>
            
        </div>
    )
}

Order.getLayout = getLayout;

export default Order;