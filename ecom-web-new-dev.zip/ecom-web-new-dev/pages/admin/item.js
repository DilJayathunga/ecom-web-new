/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 1/7/2022
 */

import { Backdrop, Button, CircularProgress, Container, Grid, Paper, Typography } from "@mui/material";
import Head from "next/head";
import AddItemDialog from "../../components/item/addItemDialog";
import ItemTable from "../../components/item/ItemTable";
import { getLayout } from "../../layouts/adminLayout";
import { openAddItemModal } from "../../store/slices/itemSlice";
import { useDispatch } from 'react-redux';
import { useGetAllItemsQuery } from "../../store/services/itemService";
import SearchBar from "../../components/shared/SearchBar";
import { useState } from "react";
import DeleteItemDialog from "../../components/item/deleteItemDialog";
import ViewItemDialog from "../../components/item/viewItemDialog";
import EditItemDialog from "../../components/item/editItemDialog";

const Item = () => {
    const dispath = useDispatch();

    const { data, isSuccess, isLoading, isError } = useGetAllItemsQuery();
    const [searchData, setSearchData] = useState([]);

    let tableContent, searchContent;

    if (isError) {
        tableContent = <div>Error...</div>
    }

    if (isSuccess) {
        tableContent = <ItemTable items={searchData} />
        searchContent = <SearchBar data={data.list || []} setSearchData={setSearchData} text="Search Items" search="title" />
    }

    return (
        <div>
            <Head>
                <title>E-COM | Item Management</title>
            </Head>

            {isLoading && (
                <Backdrop
                    sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
                    open={isLoading}
                >
                    <CircularProgress color="inherit" />
                </Backdrop>
            )}

            <Grid container>
                <Grid Item xs={9}>
                    <Typography
                        sx={{
                            padding: '32px 0 0 28px',
                            fontSize: '28px',
                            fontWeight: 'bold',
                            fontStretch: 'normal',
                            textAlign: 'left',
                            color: '#3a3a3a',
                        }}>
                        Item Management
                    </Typography>
                </Grid>
                <Grid Item xs={3}>
                    <Button
                        onClick={() => dispath(openAddItemModal())}
                        variant="contained"
                        style={{ right: 0, marginTop: '32px', marginLeft: '32px' }}
                    >
                        Add New Item
                    </Button>
                </Grid>
            </Grid>
            <Container>
                {searchContent}
            </Container>

            <Container>
                {tableContent}
            </Container>
            <AddItemDialog />
            <ViewItemDialog />
            <EditItemDialog />
            <DeleteItemDialog />
        </div>
    )
}

Item.getLayout = getLayout;

export default Item;