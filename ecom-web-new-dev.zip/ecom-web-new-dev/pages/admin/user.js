/*
 * Copyright (c) 2022 by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhari Jayathunga
 * @Date 1/7/2022
 */

import {
  Button,
  Grid,
  Typography,
  Container,
  Backdrop,
  CircularProgress,
} from "@mui/material";
import Head from "next/head";
import UserList from "../../components/user/UserList";
import { useState } from "react";
import { useDispatch } from "react-redux";
import { useGetOrganizationsQuery } from "../../store/services/orgService";

import OrgTable from "../../components/org/orgTable";
import SearchBar from "../../components/shared/SearchBar";
import { getLayout } from "../../layouts/adminLayout";
import { openUserForm, setStatus } from "../../store/slices/userSlice";
import { useGetAllUserQuery } from "../../store/services/userService";
const User = () => {
  const { data, isSuccess, isLoading, isError } = useGetAllUserQuery();
  let tableContent, searchContent;
  const [searchData, setSearchData] = useState([]);

  if (isError) {
    tableContent = <div>Error...</div>;
  }

  if (isSuccess) {
    tableContent = <UserList items={searchData} />;
    searchContent = (
      <SearchBar
        data={data.user || []}
        setSearchData={setSearchData}
        text="Search Organizations"
        search="org_name"
      />
    );
  }
  if (isLoading) {
    <div>Loading</div>;
  }

  const dispatch = useDispatch();

  return (
    <div>
      <Head>
        <title>E-COM | User Management</title>
      </Head>
      {isLoading && (
        <Backdrop
          sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
          open={isLoading}
        >
          <CircularProgress color="inherit" />
        </Backdrop>
      )}
      <div>
        <Grid container>
          <Grid item xs={9}>
            {/* Topic */}
            <Typography
              sx={{
                padding: "32px 0 0 0",
                fontSize: "28px",
                fontWeight: "bold",
                fontStretch: "normal",
                textAlign: "left",
                color: "#3a3a3a",
              }}
            >
              User Management
            </Typography>
          </Grid>
          <Grid item xs={0}></Grid>
          <Grid item xs={3} style={{ textAlign: "center" }}>
            {/* Add Category Button */}
            <Button
              onClick={() => {
                dispatch(openUserForm(true));
                dispatch(setStatus("addUser"));
              }}
              variant="contained"
              style={{ right: 0, marginTop: "32px" }}
            >
              Add New User
            </Button>
          </Grid>
          <Grid xs={11}>
            <Container>{searchContent}</Container>
            <Container>{tableContent}</Container>
          </Grid>

        </Grid>
      </div>
    </div>
  );
};

User.getLayout = getLayout;

export default User;
