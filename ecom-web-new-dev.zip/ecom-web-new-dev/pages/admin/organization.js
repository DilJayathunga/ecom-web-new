import { Backdrop, Button, CircularProgress, Container, Grid, Typography } from "@mui/material";
import Head from "next/head";
import { getLayout } from "../../layouts/adminLayout";
import { openAddOrgModal } from "../../store/slices/orgSlice";
import { useDispatch } from 'react-redux';
import AddOrgDialog from "../../components/org/addOrgDialog";
import { useGetOrganizationsQuery } from "../../store/services/orgService";
import { useState } from "react";
import OrgTable from "../../components/org/orgTable";
import SearchBar from "../../components/shared/SearchBar";
import DeleteOrgDialog from "../../components/org/deleteOrgDialog";

const Organization = () => {
  const dispath = useDispatch();

  const { data, isSuccess, isLoading, isError } = useGetOrganizationsQuery();
  const [searchData, setSearchData] = useState([]);

  let tableContent, searchContent;

  if (isError) {
    tableContent = <div>Error...</div>
  }

  if (isSuccess) {
    console.log("SearchData", searchData);
    tableContent = <OrgTable orgs={searchData} />
    searchContent = <SearchBar data={data.list || []} setSearchData={setSearchData} text="Search Organizations" search="org_name" />
  }

  return (
    <>
      <Head>
        <title>E-COM | Organization Management</title>
      </Head>

      {isLoading && (
        <Backdrop
          sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
          open={isLoading}
        >
          <CircularProgress color="inherit" />
        </Backdrop>
      )}

      <Grid container xs={12}>
        <Grid Item xs={9}>
          <Typography
            sx={{
              padding: '32px 0 0 28px',
              fontSize: '28px',
              fontWeight: 'bold',
              fontStretch: 'normal',
              textAlign: 'left',
              color: '#3a3a3a',
            }}>
            Organization Management
          </Typography>
        </Grid>
        <Grid Item xs={3}>
          <Button
            onClick={() => dispath(openAddOrgModal())}
            variant="contained"
            style={{ right: 0, marginTop: '32px', marginLeft: '32px' }}
          >
            Add New Organization
          </Button>
        </Grid>
      </Grid>

      <Container>
        {searchContent}
      </Container>

      <Container>
        {tableContent}
      </Container>

      {/* <AddOrgDialog />
      <DeleteOrgDialog /> */}
    </>
  )
}

Organization.getLayout = getLayout;

export default Organization;