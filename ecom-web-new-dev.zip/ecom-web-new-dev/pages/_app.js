// import '../styles/globals.css'

// function MyApp({ Component, pageProps }) {
//   return <Component {...pageProps} />
// }

// export default MyApp
/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 20/01/2020
 */

import React from "react";
import PropTypes from "prop-types";
import Head from "next/head";

import { wrapper } from "../store/rootStore";

import "../styles/globals.css";
import { basicTheme } from "../theme/basicTheme";

import MainLayout from "../layouts/mainLayout";

import { ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.min.css';

import { ThemeProvider } from "@mui/material";
import CssBaseline from "@mui/material/CssBaseline";

import { CookiesProvider } from 'react-cookie'

export function App({ Component, pageProps }) {
  
  React.useEffect(() => {
    const jssStyles = document.querySelector("#jss-server-side");
    if (jssStyles) {
      jssStyles.parentElement.removeChild(jssStyles);
    }
  }, []);

  const getLayout = Component.getLayout || ((page) => page);

  return (
    <>
        <Head>
          <title>E-COM | Home</title>
          <meta
            name="viewport"
            content="minimum-scale=1, initial-scale=1, width=device-width"
          />
        </Head>
        
        <ThemeProvider theme={basicTheme}>
          <CookiesProvider>
            <CssBaseline /> 
            <MainLayout>
              <ToastContainer />
              {/* <Component {...pageProps} /> */}
              {getLayout(<Component {...pageProps} />)}
            </MainLayout>
          </CookiesProvider>
        </ThemeProvider>
    </>
  );
}

// App.propTypes = {
//   Component: PropTypes.elementType.isRequired,
//   pageProps: PropTypes.object.isRequired,
// };

export default wrapper.withRedux(App);
