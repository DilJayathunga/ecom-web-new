/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 20/01/2020
 */

import { Backdrop, Button, CircularProgress, Container, Grid, Rating, Typography } from "@mui/material";
import Head from "next/head";
import QuantityPicker from "../../components/productDetails/quentityPicker";
import { useGetAllProductsQuery, getProductsById, getRunningOperationPromises } from "../../store/services/productService";
import { useRouter } from "next/router"
import { useDispatch } from "react-redux";
import ProductDetails from "../../components/productDetails/productDetails";
import FurtherDetails from "../../components/productDetails/furtherDetails";
import SellerDetails from "../../components/productDetails/sellerDetails";
import TabsView from "../../components/productDetails/tabsView";
import PopularProducts from "../../components/productDetails/popularProducts";
import { wrapper } from "../../store/rootStore";
import ImageCarousel from "../../components/productDetails/imageCarousel";

const images = [
    {id: 0, url: 'https://i.pinimg.com/474x/f4/17/91/f41791254509916ec4136614eeefa0e2.jpg'},
    {id: 1, url: 'https://media.karousell.com/media/photos/products/2020/11/15/in_stock_bnwb_authentic_adidas_1605465228_dd09a79d_progressive.jpg'},
    {id: 2, url: 'https://pbs.twimg.com/media/DgNBZs7XUAUQ-9V.jpg'},
    {id: 3, url: 'https://i.pinimg.com/originals/ba/36/6f/ba366f518dbbef771329b9a44598dd75.jpg'},
    {id: 4, url: 'https://5.imimg.com/data5/AD/AO/WB/ANDROID-50361426/1554790834323-jpg-500x500.jpg'},
    {id: 5, url: 'https://2app.kicksonfire.com/kofapp/upload/events_images/ipad_adidas-continental-80-footwear-white-hire-blue-6.jpg'},
]

const ProductId = ({ productDetails }) => {

    const router = useRouter();
    const dispatch = useDispatch();

    const { data: prodList, isSuccess: listSuccess } = useGetAllProductsQuery();

    console.log(router.query.productId)
    let recommendList = [];

    if(listSuccess){
        recommendList = prodList?.list?.slice(0, 8);
    }
    // console.log('list of products::::::::::::::::::::',recommendList)

    return (
        <>
            <Head>
                <title>E-COM | Product Detail </title>
            </Head>

            {router.isFallback && (
                <Backdrop
                sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
                open={router.isFallback}
                >
                    <CircularProgress color="inherit" />
                </Backdrop>
            )}

            <Container maxWidth="xl" style={{ marginTop: "100px" }}>
                <Grid container spacing={10}>
                    <Grid item xs={12} sm={12} md={6} lg={8} xl={8}>
                        <Grid container spacing={2}>
                            {/* product image slider */}
                            <Grid item xs={12} sm={12} md={12} lg={5} xl={5}>
                                <ImageCarousel images={images} />
                                {/* <img style={{ maxWidth: "100%", height: "300px" }} alt="image" src='https://5.imimg.com/data5/CF/YD/BL/SELLER-24989634/nike-air-max-270-sports-shoes-500x500.jpg' /> */}
                            </Grid>

                            <Grid item xs={12} sm={12} md={12} lg={7} xl={7} style={{paddingLeft: '50px'}}>
                                <ProductDetails
                                    prodDet = {productDetails}
                                />
                                

                            </Grid>
                        </Grid>
                    </Grid>

                    <Grid item xs={12} sm={12} md={6} lg={4} xl={4}>
                        <Grid container spacing={2}>
                            {/* futher details */}
                            <FurtherDetails />

                            {/* seller details */}
                            <SellerDetails 
                                seller = {productDetails.sellerName}
                            />
                        </Grid>
                    </Grid>
                </Grid>
            </Container>

            {/* Tab View */}
            <Container maxWidth="xl" style={{ marginTop: "50px" }}>
                <TabsView prodDet = {productDetails}/>
            </Container>

            {/* Popular Products */}
            <PopularProducts recommendList={recommendList} />
        </>
    );
}

export default ProductId;

export const getServerSideProps = wrapper.getServerSideProps(
    (store) => async (context) => {
        const id = context.params?.productId;
        const list = await store.dispatch(getProductsById.initiate(id));
    
        await Promise.all(getRunningOperationPromises());
    
        return {
            props: {
                productDetails: list.data.productDetails
            },
        };
    }
);