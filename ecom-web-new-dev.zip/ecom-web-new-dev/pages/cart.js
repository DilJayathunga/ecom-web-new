import { Backdrop, CircularProgress, Container, Grid } from "@mui/material";
import CartDetails from "../components/cart/cartDetails";
import OrderSummery from "../components/cart/orderSummery";
import { useCookies } from "react-cookie"
import { useGetAllCartItemsQuery } from "../store/services/cartService";

// const items = [
//   { id: 1, 
//     title: "Lenovo Legion 5 Pro 16 165Hz QHD IPS G-Sync Ryzen 7 16GB RAM 1TB SSD RTX 3070", 
//     qty: 1, price: "528.00", 
//     img: "https://a2zlaptop.com/product_images/jpeg/Lenovo-Legion-5-Pro.jpg" },
//   { id: 2, title: "Lenovo Legion 5 Pro 16 165Hz QHD IPS G-Sync Ryzen 7 16GB RAM 1TB SSD RTX 3070", qty: 1, price: "528.00", img: "https://a2zlaptop.com/product_images/jpeg/Lenovo-Legion-5-Pro.jpg" },
//   { id: 3, title: "Lenovo Legion 5 Pro 16 165Hz QHD IPS G-Sync Ryzen 7 16GB RAM 1TB SSD RTX 3070", qty: 1, price: "528.00", img: "https://a2zlaptop.com/product_images/jpeg/Lenovo-Legion-5-Pro.jpg" },
// ]

const Cart = () => {

  const [cookies, setCookie] = useCookies(["cartId"])

  console.log('from cookie:', cookies.cartId)

  let items = [], orderDet
  const { data, isSuccess, isLoading } = useGetAllCartItemsQuery(cookies.cartId);
  // const { data, isSuccess, isLoading } = useGetAllCartItemsQuery(5);
  if(isSuccess){
      items = data.orderDetails.items;
      orderDet = data.orderDetails;
  }
  console.log('cart items', data)

  return (
    <Container maxWidth="xl" style={{ paddingTop: "0.5rem", paddingBottom: "5rem" }}>
      {isLoading && (
          <Backdrop
          sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
          open={isLoading}
          >
              <CircularProgress color="inherit" />
          </Backdrop>
      )}
      <Grid container spacing={2}>
        {/* Cart Details */}
        <Grid item xs={12} md={8}>
          <CartDetails items={items} />
        </Grid>

        {/* Summery */}
        <Grid item xs={12} md={4}>
          <OrderSummery items={items} orderDet={orderDet}/>
        </Grid>
      </Grid>
    </Container>
  )
}

export default Cart;