/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasinghe
 * @Date 20/01/2020
 */

import { Backdrop, CircularProgress, Container, Grid } from "@mui/material";
import Carousel from "../components/Carousel";

import SingleItemCardOne from "../components/shared/SingleItemCardOne";

import { useGetAllProductsQuery } from "../store/services/productService";

const Home = () => {
  
  const { data: prodList, isSuccess: listSuccess, isLoading: listLoading } = useGetAllProductsQuery();

  let products = [];

  if(listSuccess){
    products = prodList?.list?.slice(0, 8);
  }
  
  return (
    <>    
      {/* Image Banner Here */}
      <Carousel/>
      <Container fixed>
        {listLoading && (
          <Backdrop
            sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
            open={listLoading}
          >
            <CircularProgress color="inherit" />
          </Backdrop>
        )}
        <Grid container spacing={1}>
          {products?.map((item, index) => (
            <SingleItemCardOne itemData={item} key={index} />
          ))}
        </Grid>
      </Container>
    </>
  );
};

export default Home;