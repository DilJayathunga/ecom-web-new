/*
 * Copyright (c) 2021. by N-Ach (Pvt) Ltd
 *
 * ╔═╗ ╔╗    ╔═══╗  ╔╗
 * ║║╚╗║║    ║╔═╗║  ║║
 * ║╔╗╚╝║    ║║ ║╠══╣╚═╗
 * ║║╚╗║║╔══╗║╚═╝║╔═╣╔╗║
 * ║║ ║║║╚══╝║╔═╗║╚═╣║║║
 * ╚╝ ╚═╝    ╚╝ ╚╩══╩╝╚╝
 *
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of N-Ach (Pvt) Ltd. ("Confidential Information"). You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with N-Ach (Pvt) Ltd.
 *
 *
 * @Author Dilhan Ranasingh
 * @Date 20/01/2020
 */

import { Backdrop, Box, CircularProgress, Grid, Pagination } from "@mui/material";
import Head from "next/head";
import { useRouter } from "next/router";
import Router from "next/router";
import { useEffect, useState } from "react";
import FilterPanel from "../../components/search/filterPanel";
import SearchTitleBar from "../../components/search/SearchTitleBar";
import SingleItemCardOne from "../../components/shared/SingleItemCardOne";
import SingleItemCardTwo from "../../components/shared/SingleItemCardTwo";
import { getAllSearchedProducts, getFilteredProducts, getRunningOperationPromises, useGetFilteredProductsMutation, useLazyGetAllSearchedProductsQuery } from "../../store/services/productService";
import { wrapper } from "../../store/rootStore";

const Search = (props) => {

    const { query } = useRouter();
    // console.log("props", props)

    const [getSearchProducts, { isLoading: filteredLoading }] = useLazyGetAllSearchedProductsQuery();

    const [showBy, setShowBy] = useState("list"); //'showBy' can be contain 'list', 'grid'
    const [filterObj, setFilterObj] = useState({});
    const [pageNumber, setPageNumber] = useState(1);
    const [pageSize, setPageSize] = useState(100);
    const [productList, setProductList] = useState();
    const [productCount, setProductCount] = useState(0);

    const handleShowBy = (viewType) => {
        console.log("handleViewBy", viewType);
        setShowBy(viewType);
    };

    const handleChanghePage = (pageNumber) => {
        let paraObj = {};
        paraObj = { ...query, ["pageNumber"]: pageNumber, ["pageSize"]: pageSize };
    
        setPageNumber(pageNumber);
        Router.push({
            pathname: "/search",
            query: paraObj,
        });
    };

    let queryString = ""

    if (typeof window !== "undefined") {
        queryString = window.location.search;
        console.log(queryString);
    }    

    useEffect(() => {
        setFilterObj(query);
        const fetchfilterProducts = async() => {
            try {
                const filteredProdList = await getSearchProducts(queryString).unwrap();
                console.log('add item', filteredProdList)
                await setProductList(filteredProdList?.list?.slice(0, 10));
                await setProductCount(filteredProdList?.list?.length);
            } catch (err) {
                console.error('Failed to save the item: ', err)
            }
        }
        fetchfilterProducts();
    }, [query, queryString, filterObj, getSearchProducts])
    console.log('product list:', productList)
    
    return (
        <>
            <Head>
                <title>E-COM | Search</title>
            </Head>

            <SearchTitleBar
                viewBy={showBy}
                handleViewBy={handleShowBy}
                style={{ zIndex: 0, height: 20 }}
            />

            <Grid container spacing={1} style={{ paddingTop: 10 }}>
                <Grid item md={2.5} id="Filterpanel">
                    {/* <FilterPanel category={filterObj.Category} /> */}
                    <FilterPanel category={filterObj.Category} />
                </Grid>
                <Grid item md={9.5}>
                    {filteredLoading && (
                        <Backdrop
                            sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
                            open={filteredLoading}
                        >
                            <CircularProgress color="inherit" />
                        </Backdrop>
                    )}
                    <div>
                        <div>
                            <Grid container spacing={1}>
                                {productList?.map((item, index) => (
                                    <>
                                        {showBy == "list" ? (
                                            <SingleItemCardTwo itemData={item} key={index} />
                                        ) : showBy == "grid" ? (
                                            <SingleItemCardOne itemData={item} key={index} />
                                        ) : null}
                                    </>
                                ))}
                            </Grid>
                        </div>
                        <Box my={2} display="flex" justifyContent="center">
                            <Pagination
                                count={productCount}
                                variant="outlined"
                                size="large"
                                // shape="rounded"
                                color="primary"
                                page={pageNumber}
                                style={{ margin: "10px 0 10px -3px" }}
                                // style={{justifyContent: 'center', right: 0}}
                                onChange={(e, page) => handleChanghePage(page)}
                            />
                        </Box>
                    </div>
                </Grid>
            </Grid>

        </>
    );
}

export default Search;

// export const getServerSideProps = wrapper.getServerSideProps(
//     (store) => async (context) => {
//         const param = context.query;
//         const list = await store.dispatch(getAllSearchedProducts.initiate(param));
    
//         await Promise.all(getRunningOperationPromises());
    
//         return {
//             props: {
//                 productList: list.data.list,
//                 param: param,
//             },
//         };
//     }
// );